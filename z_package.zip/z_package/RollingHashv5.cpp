#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
#include <atcoder/all>

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{m[0]+n*m[1],m[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0;}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }

#define check 1
using Hash = array<ll, (check+1)>;
const ll bases_num[3] = {10001LL, 10003LL, 10007LL};
const ll mods_num[3] = {999999937LL, 1000000007LL, 1000000009LL};
array<ll,check> bases, mods;
vector<vector<ll>> pows;
Hash operator* (const Hash &a, const Hash &b) {Hash res; res[check] = a[check] + b[check]; for (int i=0;i<check;i++) res[i] = a[i] * b[i] % mods[i]; return res;}

// arc181/b/main.cppより

ll mod_pow(ll x, ll n, ll mod) {
    ll res = 1;
    while (n > 0) {
        if (n & 1) res = res * x % mod;
        x = x * x % mod;
        n >>= 1;
    }
    return res;
}

ll mod_inv(ll x, ll mod) {
    return mod_pow(x, mod - 2, mod);
}

void rh_init(int N){
    pows.resize(check,vector<ll> (N + 1,1));
    for (int i=0;i<check;i++){
        bases[i] = bases_num[i];
        mods[i] = mods_num[i];
    }
    for (int i = 0; i < N; i++) {
        for (int j=0;j<check;j++){
            pows[j][i + 1] = pows[j][i] * bases[j] % mods[j];
        }
    }
}

Hash to_hash(const string &s){
    Hash res = {};
    res[check] = s.size();
    for (int i = 0; i < s.size(); i++) {
        for (int j=0;j<check;j++){
            res[j] = (res[j] * bases[j] + (s[i]-'0')) % mods[j];
        }
    }
    return res;
}

Hash concat(Hash h1, Hash h2) {
    
    Hash res={};
    
    res[check] = h1[check] + h2[check];
    bool ok = true;
    if (h2[check] >= pows[0].size()) {
        ok = false;
    }
    
    for (int i=0;i<check;i++){
        if (ok) res[i] = (h1[i] * pows[i][h2[check]] + h2[i]) % mods[i];
        else res[i] = (h1[i] * mod_pow(bases[i], h2[check], mods[i]) + h2[i]) % mods[i];
    }
    return res;
}

struct RollingHash {
    vector<vector<ll>> hashes;
    atcoder::segtree<Hash, concat, [](){return Hash{};}> seg;
    int siz;

    RollingHash (const string &s): seg(s.size()){
        siz = s.size();
        hashes.resize(check,vector<ll> (s.size() + 1,1));
        for (int i = 0; i < s.size(); i++) {
            for (int j=0;j<check;j++){
                hashes[j][i + 1] = (hashes[j][i] * bases[j] + (s[i]-'0')) % mods[j];
                pows[j][i + 1] = pows[j][i] * bases[j] % mods[j];
            }
        }
        rep(i,s.size()){
            seg.set(i,to_hash(s.substr(i,1)));
        }
    }
    // [l, r)
    Hash get(int l, int r) {
        Hash res={};
        res[check] = r - l;
        for (int i=0;i<check;i++){
            res[i] = hashes[i][r] + mods[i] - hashes[i][l] * pows[i][r - l] % mods[i];
            if (res[i] >= mods[i]) res[i] -= mods[i];
        }
        return res;
    }

    // 一点更新対応 遅いから注意
    // Hash get(int l, int r) {
    //     return seg.prod(l,r);
    // }

    // void set(int i, char h){
    //     seg.set(i,to_hash(string{h}));
    // }

    // 文字列を無限に連結したときの[l, r)のハッシュ値
    Hash get2(ll l, ll r) {
        Hash res={};
        for (int i=0;i<=check;i++) res[i] = 0;
        if (l >= siz) {
            ll minus = (l / siz) * siz;
            l -= minus;
            r -= minus;
        }
        if (r <= siz) {
            return get(l, r);
        } else {
            ll r_bound = (r / siz) * siz;
            res = concat(res, get(l, siz));
            
            ll nums = r / siz - 1;
            // 文字列をnums個連結したときのハッシュ値
            Hash tmp={};
            Hash now_hash = get(0, siz);
            for (int i=0;i<check;i++){
                tmp[i] = now_hash[i]*((mod_pow(pows[i][siz], nums, mods[i]) - 1) * mod_inv(pows[i][siz] - 1, mods[i]) % mods[i])%mods[i];
            }
            tmp[check] = siz * nums;
            res = concat(res, tmp);
            res = concat(res, get(0, r-r_bound));
            return res;
        }
    }

    // [l1, r1)と他のrhの[l2, r2)のLCP(Longest Common Prefix)の長さを求める
    ll LCP(RollingHash &rh1, int l1, int r1, RollingHash &rh2, int l2, int r2) {
        int len = min(r1 - l1, r2 - l2);
        int ok = -1, ng = len + 1;
        while (ng - ok > 1) {
            int mid = (ok + ng) / 2;
            if (rh1.get(l1, l1 + mid) == rh2.get(l2, l2 + mid)) {
                ok = mid;
            } else {
                ng = mid;
            }
        }
        return ok;
    }
};