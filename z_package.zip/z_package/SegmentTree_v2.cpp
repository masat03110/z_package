#include <bits/stdc++.h>

using namespace std;
using ll=long long;

// O(logN)

//change mono and func
// note: mono must be a value that func returns the other value of the two
struct mono{
        ll val=1e18;
        ll index=1e18;
};

mono func(mono a, mono b){
    if (a.val <= b.val) return a;
    else return b;
}

struct SegmentTree{
    int n;
    vector<mono> node;
    
    SegmentTree(vector<mono> v){
        int sz = v.size();
        n = 1; while(n < sz) n *= 2;
        node.resize(2*n-1,mono());
    
        for (int i=0;i<sz;i++){
        node[i+n-1] = v[i];
        }
        for (int i=n-2;i>=0;i--) node[i] = func(node[i*2+1],node[i*2+2]);
    }
    
    void update(int x, mono val){
        x += (n - 1);
        // change here
        node[x] = val;
        // until here
        while(x > 0){
        x = (x - 1) / 2;
        node[x] = func(node[2*x+1],node[2*x+2]);
        }
    }
    
    mono get(int a, int b, int k=0, int l=0, int r=-1){
        if (r < 0) r = n;
        if (r <= a || b <= l) return mono();
        if (a <= l && r <= b) return node[k];
        mono vl = get(a,b,2*k+1,l,(l+r)/2);
        mono vr = get(a,b,2*k+2,(l+r)/2,r);
        return func(vl,vr);
    }
};