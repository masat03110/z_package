// https://atcoder.jp/contests/abc197/submissions/me
// abc394 e
#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0;i<n;i++)
#define rep2(i,a,b) for (ll i=(a);i<b;i++)
#define repd(i,a,b) for (ll i=(a);i>=b;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
#define seg_RmaRmsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{(a[0]+b[0])%998244353ll,a[1]+b[1]};},[&](){return array<ll,2>{0,0};},array<ll,2>,[&](array<ll,2> m, array<ll,2> n){ return array<ll,2>{(m[0]*n[0]+m[1]*n[1])%998244353ll,n[1]};}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0]%998244353ll, (b[1]*a[0]+a[1])%998244353ll};},[&](){return array<ll,2>{1ll,0ll};}>
#define seg_Parentheses atcoder::segtree<array<int,3>, [&](array<int,3> a, array<int,3> b){ int m = min(a[1], b[2]);return array<int,3>{a[0]+b[0]+2*m, a[1]+b[1]-m, a[2]+b[2]-m};},[](){return array<int,3>{0,0,0};}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
template<typename T, typename F> T bs(T l, T r, F f) { for(int i=0;i<100;i++){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
template<typename T, typename F> T bs_fast(T l, T r, F f) { while(r-l>1){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}
ll stollmod(string S, ll mod) {ll ret = 0; rep(i,S.size()){ ret = (ret*10 + (S[i]-'0'))%mod; } return ret; }

// 二乗グラフを構築
// O(N^2 + M^2)
struct Graph_double{
    vector<vector<int>> G_double;
    vector<vector<int>> G;
    vector<vector<int>> G_rev; // 逆辺
    vector<int> length;
    int N;
    Graph_double(vector<vector<int>> _G): G(_G), N(_G.size()) {

        G_rev.resize(N);
        rep(i,N){
            for (int j: G[i]){
                G_rev[j].push_back(i); // 逆辺を追加
            }
        }

        G_double.resize(N*N+1);
        rep(i,N) {
            G_double[i*N+i].push_back(N*N); // ルートからの辺を追加
            G_double[N*N].push_back(i*N+i); // ルートからの辺を追加
        }
        rep(i,N){
            for (int j: G[i]) {
                G_double[i*N+j].push_back(N*N);
                G_double[N*N].push_back(i*N+j);
            }
        }

        rep(i,N){
            rep(j,N){
                for (int ni: G_rev[i]){
                    for (int nj: G[j]){
                        G_double[i*N+j].push_back(ni*N+nj);
                    }
                }
            }
        }

        rep(i,N*N+1){
            sortunique(G_double[i]);
        }
    }

    void palindorome_nodes(vector<int> &A){
        length.resize(N*N+1,-1);
        length[N*N] = 0;
        queue<int> que;
        rep(i,N){
            que.push(i*N+i);
            length[i*N+i] = 0;
        }
        rep(i,N) for (auto j: G[i]) {
            if (i <= j && A[i] == A[j]) {
                que.push(i*N+j);
                length[i*N+j] = 1;
            }
        }

        while (!que.empty()) {
            int v = que.front();
            que.pop();
            for (auto nv: G_double[v]) {
                int ni = nv / N;
                int nj = nv % N;
                if (length[nv] == -1 && A[ni] == A[nj]) {
                    length[nv] = length[v] + 2;
                    que.push(nv);
                }
            }
        }
    }


    void palindorome_edges(vector<array<int,3>> &E){

        vector<vector<int>> edge_to_char(N*N);
        queue<int> que;

        length.resize(N*N+1,-1);
        length[N*N] = 0;
        rep(i,N){
            que.push(i*N+i);
            length[i*N+i] = 0;
        }

        for (auto &e: E) {
            int u = e[0];
            int v = e[1];
            edge_to_char[u*N+v].push_back(e[2]);
            if (u != v) {
                length[u*N+v] = 1; // 自分自身の辺は長さ1
                que.push(u*N+v);
            }
        }

        rep(i,N*N){
            sortunique(edge_to_char[i]);
        }

        while (!que.empty()) {
            int v = que.front();
            que.pop();
            int i = v / N;
            int j = v % N;
            for (auto nv: G_double[v]) {
                if (length[nv] == -1) {
                    int ni = nv / N;
                    int nj = nv % N;
                    for (auto c: edge_to_char[ni*N+i]) {
                        for (auto nc: edge_to_char[j*N+nj]) {
                            if (c == nc) {
                                goto found_match; // 辺の文字が一致した場合はスキップ
                            }
                        }
                    }
                    continue; // 辺の文字が一致しない場合はスキップ
                    found_match:
                        length[nv] = length[v] + 2;
                        que.push(nv);
                }
            }
        }
    }

    int get_length(int u, int v) {
        return length[u*N+v];
    }
};

int main2() {

    cin(N);

    vector<vector<int>> G(N);
    vector<string> S(N);
    rep(i,N) cin >> S[i];
    vector<array<int,3>> E;

    rep(i,N){
        rep(j,N){
            if (S[i][j] == '-') continue;
            else{
                E.push_back({(int)i,(int)j,S[i][j]-'a'}); // 辺の文字を0-indexedに変換
                G[i].push_back(j);
            }
        }
    }

    Graph_double graph_double(G);

    graph_double.palindorome_edges(E);

    rep(i,N){
        vector<int> ans(N);
        rep(j,N){
            ans[j] = graph_double.get_length(i,j); // ルートからの距離を取得
        }
        outvec(ans);
    }
    
    return 0;
} 
