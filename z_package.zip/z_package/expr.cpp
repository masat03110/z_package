#include <bits/stdc++.h>
using namespace std;

int expr(string &s, int &i);
int term(string &s, int &i);
int factor(string &s, int &i);
int number(string &s, int &i);

int expr(string &s, int &i){
	int val = term(s,i);
	if (s[i] == '+'){
		i++;
		int val2 = expr(s,i);
		val += val2;
	}
	if (s[i] == '-'){
		i++;
		int val2 = expr(s,i);
		val -= val2;
	}
	return val;
}

int term(string &s, int &i){
	int val = factor(s,i);
	if (s[i] == '*'){
		i++;
		int val2 = term(s,i);
		val *= val2;
	}
	if (s[i] == '/'){
		i++;
		int val2 = term(s,i);
		val /= val2;
	}
	return val;
}	

int factor(string &s, int &i){
	if (isdigit(s[i])) return number(s,i);
	if (s[i] == '('){
		i++;
		int val = expr(s,i);
		i++;
		return val;
	}
	assert(false);
};

int number(string &s, int &i){
	int val = 0;
	while(isdigit(s[i])){
		val = val*10 + s[i]-'0';
		i++;
	}
	return val;
}

int main2(){
	string s;
	cin >> s;
	int i=0;
	cout << expr(s,i) << endl;
}