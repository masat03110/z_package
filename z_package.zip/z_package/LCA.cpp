#include <bits/stdc++.h>

using namespace std;
using ll=long long;

// typical90 035

// O(logN)
/**
 * Lowest Common Ancestor
 */

// 木GのLCAを求める
class LCA{
  private:
  ll root;
  ll k; // n<=2^kとなる最小のk
  vector<vector<ll>> dp; // dp[i][j]:=要素jの2^i上の要素
  vector<ll> depth;  // depth[i]:=rootに対する頂点iの深さ
  
  public:
  LCA(const vector<vector<ll>>& _G, const ll _root=0){
    ll n=_G.size();
    root=_root;
    k=1;
    ll nibeki=2;
    while(nibeki<n){
      nibeki<<=1;
      k++;
    }
    // 頂点iの親ノードを初期化
    dp = vector<vector<ll>>(k+1, vector<ll>(n, -1));
    depth.resize(n);
    function<void(ll, ll)> _dfs=[&](ll v, ll p){
      dp[0][v]=p;
      for(auto nv: _G[v]){
        if(nv==p) continue;
        depth[nv]=depth[v]+1;
        _dfs(nv, v); 
      }
    };
    _dfs(root, -1);
    // ダブリング
    for(ll i=0; i<k; i++){
      for(ll j=0; j<n; j++){
        if(dp[i][j]==-1) continue;
        dp[i+1][j]=dp[i][dp[i][j]];
      }
    }
  }
  
  /// get LCA
  ll get_LCA(ll u, ll v){
    if(depth[u]<depth[v]) swap(u,v); // u側を深くする
    if(depth[u]!=depth[v]){
      long long d=depth[u]-depth[v];
      for(ll i=0; i<k; i++) if((d>>i)&1) u=dp[i][u];
    }
    if(u==v) return u;
    
    for(ll i=k; i>=0; i--){
      if(dp[i][u]!=dp[i][v]){
        u=dp[i][u], v=dp[i][v];
      }
    }
    return dp[0][u];
  }
  
  ll get_distance(const ll u, const ll v){
    ll lca=get_LCA(u,v);
    return depth[u]+depth[v]-2*depth[lca];
  }
};