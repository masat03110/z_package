#include <bits/stdc++.h>

using namespace std;
using ll=long long;

// typical90 021
// O(V+E)
struct StronglyConnectedComponents {
  ll n;
  vector<vector<ll>> G, rG;
  vector<ll> order, component;
  vector<bool> used;
  void dfs(ll v) {
    used[v] = 1;
    for (auto nv : G[v]) {
      if (!used[nv]) dfs(nv);
    }
    order.push_back(v);
  }
  void rdfs(ll v, ll k) {
    component[v] = k;
    for (auto nv : rG[v]) {
      if (component[nv] < 0) rdfs(nv, k);
    }
  }

  StronglyConnectedComponents(vector<vector<ll>> &_G) {
    n = _G.size();
    G = _G;
    rG.resize(n);
    component.assign(n, -1);
    used.resize(n);
    for (ll v = 0; v < n; v++) {
      for (auto nv : G[v]) rG[nv].push_back(v);
    }
    for (ll v = 0; v < n; v++) if (!used[v]) dfs(v);
    ll k = 0;
    reverse(order.begin(), order.end());
    for (auto v : order) if (component[v] == -1) rdfs(v, k), k++;
  }

  /// 頂点(u, v)が同じ強連結成分に含まれるか
  bool is_same(ll u, ll v) { return component[u] == component[v]; }

  /// 強連結成分を1つのノードに潰したグラフを再構築する
  vector<vector<ll>> rebuild() {
    ll N = *max_element(component.begin(), component.end()) + 1;
    vector<vector<ll>> rebuildedG(N);
    set<pair<ll, ll>> connected;
    for (ll v = 0; v < N; v++) {
      for (auto nv : G[v]) {
        if (component[v] != component[nv] and !connected.count(make_pair(v, nv))) {
          connected.insert(make_pair(v, nv));
          rebuildedG[component[v]].push_back(component[nv]);
        }
      }
    }
    return rebuildedG;
  }

  /// rebuild()したグラフの、元のグラフの頂点番号を返す
  vector<ll> rebuild_id() {
    vector<ll> res(n);
    for (ll i = 0; i < n; i++) res[i] = component[i];
    return res;
  }

    /// 強連結成分の個数
    ll size() {
        return *max_element(component.begin(), component.end()) + 1;
    }

    /// 強連結成分の各成分の個数
    vector<ll> component_size() {
        vector<ll> res(size());
        for (auto c : component) res[c]++;
        return res;
    }
};