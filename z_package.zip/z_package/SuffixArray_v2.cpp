#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
#include <atcoder/all>

using std::cout; using namespace std; using ll=long long; using ld=long double; using mint = atcoder::modint998244353;
#define rep(i,n) for (int i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (int i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (int i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }

class SuffixArray {
private:
  string s;
  int n, k;
  vector<int> suffix_array;
  vector<int> rank;
  void create_suffix_array() {
    for (int i = 0; i <= n; i++) {
      suffix_array[i] = i;
      rank[i] = i < n ? (int)s[i] : -1;
    }
    auto compare = [&](int a, int b) {
      if (rank[a] != rank[b]) return rank[a] < rank[b];
      else {
        auto rank_ak = a + k <= n ? rank[a + k] : -1;
        auto rank_bk = b + k <= n ? rank[b + k] : -1;
        return rank_ak < rank_bk;
      }
    };
    vector<int> tmp(n + 1);
    for (k = 1; k <= n; k *= 2) {
      sort(suffix_array.begin(), suffix_array.end(), compare);
      tmp[suffix_array[0]] = 0;
      for (int i = 1; i <= n; i++) {
        tmp[suffix_array[i]] = tmp[suffix_array[i - 1]] + (compare(suffix_array[i - 1], suffix_array[i]) ? 1 : 0);
      }
      for (int i = 0; i <= n; i++) {
        rank[i] = tmp[i];
      }
    }
  }

public:
  SuffixArray(const string &_s) {
    s = _s;
    n = _s.size();
    suffix_array.resize(n + 1);
    rank.resize(n + 1);
    create_suffix_array();
  }

  // 文字列sの部分文字列として、パラメータで渡した文字列tが現れるかを返す
  int contains(const string &t) {
    int l = 0, r = n;
    while (r - l > 1) {
      int mid = (l + r) / 2;
      int index = suffix_array[mid];
      if (s.compare(index, t.size(), t) < 0) l = mid;
      else r = mid;
    }
    if (s.compare(suffix_array[r], t.size(), t) != 0){
        return 0;
    }else{
        int l_is = r;
        l = 0; r = n;
        while (r - l > 1) {
            int mid = (l + r) / 2;
            int index = suffix_array[mid];
            if (s.compare(index, t.size(), t) <= 0) l = mid;
            else r = mid;
        }
        if (s.compare(suffix_array[r], t.size(), t) == 0){
            return r-l_is+1;
        }else{
            return r-l_is;
        }
    }
  }
};