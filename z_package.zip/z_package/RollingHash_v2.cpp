#include <bits/stdc++.h>
using namespace std;
using ll=long long;

// ABC331 F
// typical90 047

#define check 3
using Hash = array<ll, check>;
array<ll,check> bases = {9973LL, 10007LL, 10009LL};
const array<ll,check> mods = {999999937LL, 1000000007LL, 1000000009LL};
struct RollingHash {
    vector<vector<ll>> hash,pow;
    void init(const string &s){
        hash.resize(check,vector<ll> (s.size() + 1,1));
        pow.resize(check,vector<ll> (s.size() + 1,1));
        for (int i = 0; i < s.size(); i++) {
            for (int j=0;j<check;j++){
                hash[j][i + 1] = (hash[j][i] * bases[j] + (s[i])) % mods[j];
                pow[j][i + 1] = pow[j][i] * bases[j] % mods[j];
            }
        }
    }
    // [l, r)
    Hash get(int l, int r) {
        Hash res;
        for (int i=0;i<check;i++){
            res[i] = hash[i][r] + mods[i] - hash[i][l] * pow[i][r - l] % mods[i];
            if (res[i] >= mods[i]) res[i] -= mods[i];
        }
        return res;
    }

    Hash concat(Hash h1, Hash h2, int h2_len) {
        Hash res;
        for (int i=0;i<check;i++){
            res[i] = (h1[i] * pow[i][h2_len] + h2[i]) % mods[i];
        }
        return res;
    }
};