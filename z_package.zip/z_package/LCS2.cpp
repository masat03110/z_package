#include <iostream>
#include <vector>
#include <string>
#include <bitset>
#include <boost/dynamic_bitset.hpp>

using namespace std;
typedef long long ll;
typedef unsigned long long ull;

// 最長共通部分列 O(NM/w)

boost::dynamic_bitset<> operator+(const boost::dynamic_bitset<>& a, const boost::dynamic_bitset<>& b){
    vector<ull> data_a, data_b, data_res;
    boost::to_block_range(a, back_inserter(data_a));
    boost::to_block_range(b, back_inserter(data_b));
    int n = data_a.size();
    int m = data_b.size();
    if (n < m) swap(data_a, data_b), swap(n, m);
    ull carry = 0;
    data_res = vector<ull>(n, 0);
    for(int i=0; i<m; i++){
        ull A = data_a[i], B = data_b[i], C = data_a[i] + data_b[i] + carry;
        carry = (C < A) || (C == A && carry);
        data_res[i] = C;  
    } 
    for(int i=m; i<n; i++){
        ull A = data_a[i], C = data_a[i] + carry;
        carry = (C < A) || (C == A && carry);
        data_res[i] = C;
    }
    boost::dynamic_bitset<> res(a.size()+64);
    boost::from_block_range(data_res.begin(), data_res.end(), res);
    res.resize(a.size(), 1);
    return res;
}

boost::dynamic_bitset<> subb(const boost::dynamic_bitset<>& a, const boost::dynamic_bitset<>& b){
    vector<ull> data_a, data_b, data_res;
    boost::to_block_range(a, back_inserter(data_a));
    boost::to_block_range(b, back_inserter(data_b));
    int n = data_a.size();
    int m = data_b.size();
    if (n < m) swap(data_a, data_b), swap(n, m);
    ull carry = 0;
    data_res = vector<ull>(n, 0);
    for(int i=0; i<m; i++){
        ull A = data_a[i], B = data_b[i], C = data_a[i] - data_b[i] - carry;
        carry = (C > A) || (C == A && carry);
        data_res[i] = C;  
    }
    for(int i=m; i<n; i++){
        ull A = data_a[i], C = data_a[i] - carry;
        carry = (C > A) || (C == A && carry);
        data_res[i] = C;
    }
    boost::dynamic_bitset<> res(a.size()+64);
    boost::from_block_range(data_res.begin(), data_res.end(), res);
    res.resize(a.size(), 1);
    return res;
}

int LCS(string S, string T){
    int N = S.size();
    int M = T.size();

    vector<boost::dynamic_bitset<>> D(2, boost::dynamic_bitset<>(M)), Matrix(1, boost::dynamic_bitset<>(M));

    vector<boost::dynamic_bitset<>> ABC(26, boost::dynamic_bitset<>(M));

    for(int j=0; j<M; j++){
        ABC[T[j]-'a'][j] = 1;
    }

    for (int i=0; i<N; i++){
        Matrix[0] = ABC[S[i]-'a'];
        boost::dynamic_bitset<> x = D[0] | Matrix[0];
        D[1] = x & ((subb(x, ((D[0] << 1) | boost::dynamic_bitset<>(M,1))) ^ x));
        D[0] = D[1];
    }

    return D[0].count();
}

int main2(){
    string S,T;
    cin >> S >> T;
    cout << LCS(S, T) << endl;
}