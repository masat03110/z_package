#include <bits/stdc++.h>

using namespace std;
using ll=long long;
using lp=array<ll,2>;

// typical90 003
// O(N)
ll TreeDiameter(vector<vector<lp>> &G){
    ll N = G.size();
    vector<ll> dist(N,-1);
    queue<ll> q;
    dist[0] = 0;
    q.push(0);
    while (!q.empty()){
        ll v = q.front();
        q.pop();
        for (auto p:G[v]){
            ll u = p[0];
            ll c = p[1];
            if (dist[u] != -1) continue;
            dist[u] = dist[v] + c;
            q.push(u);
        }
    }
    ll max_dist = 0;
    ll max_v = 0;
    for (int i=0;i<N;i++){
        if (max_dist < dist[i]){
            max_dist = dist[i];
            max_v = i;
        }
    }
    dist = vector<ll>(N,-1);
    q.push(max_v);
    dist[max_v] = 0;
    while (!q.empty()){
        ll v = q.front();
        q.pop();
        for (auto p:G[v]){
            ll u = p[0];
            ll c = p[1];
            if (dist[u] != -1) continue;
            dist[u] = dist[v] + c;
            q.push(u);
        }
    }
    max_dist = 0;
    for (int i=0;i<N;i++){
        max_dist = max(max_dist,dist[i]);
    }
    return max_dist;
}