#include <bits/stdc++.h>

using namespace std;
using ll=long long;

//change mono and func
struct mono{
        ll maxi = -1e18;
        ll mini = 1e18;
};

mono func(mono a, mono b){
    mono res;
    res.maxi = max(a.maxi,b.maxi);
    res.mini = min(a.mini,b.mini);
    return res;
}

struct SegmentTree{
    int n;
    vector<mono> node;
    
    SegmentTree(vector<mono> v){
        int sz = v.size();
        n = 1; while(n < sz) n *= 2;
        node.resize(2*n-1,mono());
    
        for (int i=0;i<sz;i++){
        node[i+n-1] = v[i];
        }
        for (int i=n-2;i>=0;i--) node[i] = func(node[i*2+1],node[i*2+2]);
    }
    
    void update(int x, mono apply){
        x += (n - 1);
        node[x] = apply;
        while(x > 0){
        x = (x - 1) / 2;
        node[x] = func(node[2*x+1],node[2*x+2]);
        }
    }
    
    mono get(int a, int b, int k=0, int l=0, int r=-1){
        if (r < 0) r = n;
        if (r <= a || b <= l) return mono();
        if (a <= l && r <= b) return node[k];
        mono vl = get(a,b,2*k+1,l,(l+r)/2);
        mono vr = get(a,b,2*k+2,(l+r)/2,r);
        return func(vl,vr);
    }
};