// https://atcoder.jp/contests/arc039/tasks/arc039_d
// https://atcoder.jp/contests/abc075/tasks/abc075_c
#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
#include <atcoder/all>

using std::cout; using namespace std; using ll=long long; using ld=long double; using mint = atcoder::modint998244353;
#define rep(i,n) for (int i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (int i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (int i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }

#include <bits/stdc++.h>
using namespace std;
using ll = long long;


// const int INF = (int)1e9 + 1001010;
// const ll llINF = (long long)4e18 + 22000020;
// const string endn = "\n";
// template <class T> inline auto vector2(size_t i, size_t j, const T &init = T()) {return vector(i, vector<T>(j, init));}
// const string ELEM_SEPARATION = " ", VEC_SEPARATION = endn;
// template<class T> istream& operator >>(istream &i, vector<T> &A) {for(auto &I : A) {i >> I;} return i;}
// template<class T> ostream& operator <<(ostream &o, const vector<T> &A) {int i=A.size(); for(const auto &I : A){o << I << (--i ? ELEM_SEPARATION : "");} return o;}
// template<class T> ostream& operator <<(ostream &o, const vector<vector<T>> &A) {int i=A.size(); for(const auto &I : A){o << I << (--i ? VEC_SEPARATION : "");} return o;}
// template<class T> vector<T>& operator ++(vector<T> &A, int n) {for(auto &I : A) {I++;} return A;}
// template<class T> vector<T>& operator --(vector<T> &A, int n) {for(auto &I : A) {I--;} return A;}
// template<class T, class U> bool chmax(T &a, const U &b) {return ((a < b) ? (a = b, true) : false);}
// template<class T, class U> bool chmin(T &a, const U &b) {return ((a > b) ? (a = b, true) : false);}
// ll floor(ll a, ll b){if (b < 0) a = -a, b = -b; if(a >= 0) return a / b; else return (a + 1) / b - 1;}
// ll ceil(ll a, ll b){if (b < 0) a = -a, b = -b; if(a > 0) return (a - 1) / b + 1; else return a / b;}
// ll bit(unsigned long long val, unsigned long long digit){return (val >> digit) & 1;}
// #ifdef DEBUG
// #include <debug_slephy.cpp>
// #else
// #define debug(...)
// #endif
// ================================== ここまでテンプレ ==================================



template <typename T = int>
struct Edge {
  int from, to;
  T cost;
  int idx;

  Edge() = default;

  Edge(int from, int to, T cost = 1, int idx = -1)
      : from(from), to(to), cost(cost), idx(idx) {}

  operator int() const { return to; }
};

template <typename T = int>
struct Graph {
  vector<vector<Edge<T> > > g;
  int es;

  Graph() = default;

  explicit Graph(int n) : g(n), es(0) {}

  size_t size() const { return g.size(); }

  void add_directed_edge(int from, int to, T cost = 1) {
    g[from].emplace_back(from, to, cost, es++);
  }

  void add_edge(int from, int to, T cost = 1) {
    g[from].emplace_back(from, to, cost, es);
    g[to].emplace_back(to, from, cost, es++);
  }

  void read(int M, int padding = -1, bool weighted = false,
            bool directed = false) {
    for (int i = 0; i < M; i++) {
      int a, b;
      cin >> a >> b;
      a += padding;
      b += padding;
      T c = T(1);
      if (weighted) cin >> c;
      if (directed)
        add_directed_edge(a, b, c);
      else
        add_edge(a, b, c);
    }
  }

  inline vector<Edge<T> > &operator[](const int &k) { return g[k]; }

  inline const vector<Edge<T> > &operator[](const int &k) const { return g[k]; }
};

template <typename T = int>
using Edges = vector<Edge<T> >;


/**
 * @brief Low Link(橋/関節点)
 * @see http://kagamiz.hatenablog.com/entry/2013/10/05/005213
 *
 */
template <typename T = int>
struct LowLink : Graph<T> {
 public:
  using Graph<T>::Graph;
  vector<int> ord, low, articulation;
  vector<Edge<T> > bridge;
  using Graph<T>::g;

  virtual void build() {
    used.assign(g.size(), 0);
    ord.assign(g.size(), 0);
    low.assign(g.size(), 0);
    int k = 0;
    for (int i = 0; i < (int)g.size(); i++) {
      if (!used[i]) k = dfs(i, k, -1);
    }
  }

  explicit LowLink(const Graph<T> &g) : Graph<T>(g) {}

 private:
  vector<int> used;

  int dfs(int idx, int k, int par) {
    used[idx] = true;
    ord[idx] = k++;
    low[idx] = ord[idx];
    bool is_articulation = false, beet = false;
    int cnt = 0;
    for (auto &to : g[idx]) {
      if (to == par && !exchange(beet, true)) {
        continue;
      }
      if (!used[to]) {
        ++cnt;
        k = dfs(to, k, idx);
        low[idx] = min(low[idx], low[to]);
        is_articulation |= par >= 0 && low[to] >= ord[idx];
        if (ord[idx] < low[to]) bridge.emplace_back(to);
      } else {
        low[idx] = min(low[idx], ord[to]);
      }
    }
    is_articulation |= par == -1 && cnt > 1;
    if (is_articulation) articulation.push_back(idx);
    return k;
  }
};

template <typename T = int>
struct TwoEdgeConnectedComponents : LowLink<T> {
 public:
  using LowLink<T>::LowLink;
  using LowLink<T>::g;
  using LowLink<T>::ord;
  using LowLink<T>::low;
  using LowLink<T>::bridge;

  vector<int> comp;
  Graph<T> tree;
  vector<vector<int> > group;

  int operator[](const int &k) const { return comp[k]; }

  void build() override {
    LowLink<T>::build();
    comp.assign(g.size(), -1);
    int k = 0;
    for (int i = 0; i < (int)comp.size(); i++) {
      if (comp[i] == -1) dfs(i, -1, k);
    }
    group.resize(k);
    for (int i = 0; i < (int)g.size(); i++) {
      group[comp[i]].emplace_back(i);
    }
    tree = Graph<T>(k);
    for (auto &e : bridge) {
      tree.add_edge(comp[e.from], comp[e.to], e.cost);
    }
  }

  explicit TwoEdgeConnectedComponents(const Graph<T> &g) : Graph<T>(g) {}

 private:
  void dfs(int idx, int par, int &k) {
    if (par >= 0 && ord[par] >= low[idx])
      comp[idx] = comp[par];
    else
      comp[idx] = k++;
    for (auto &to : g[idx]) {
      if (comp[to] == -1) dfs(to, idx, k);
    }
  }
};

/**
 * @brief Doubling-Lowest-Common-Ancestor(最小共通祖先)
 *
 */
template <typename T>
struct DoublingLowestCommonAncestor : Graph<T> {
 public:
  using Graph<T>::g;
  vector<int> dep;
  vector<T> sum;
  vector<vector<int> > table;
  const int LOG;

  explicit DoublingLowestCommonAncestor(int n)
      : Graph<T>(n), LOG(32 - __builtin_clz(g.size())) {}

  explicit DoublingLowestCommonAncestor(const Graph<T> &g)
      : LOG(32 - __builtin_clz(g.size())), Graph<T>(g) {}

  void build(int root = 0) {
    dep.assign(g.size(), 0);
    sum.assign(g.size(), 0);
    table.assign(LOG, vector<int>(g.size(), -1));
    dfs(root, -1, 0);
    for (int k = 0; k + 1 < LOG; k++) {
      for (int i = 0; i < (int)table[k].size(); i++) {
        if (table[k][i] == -1)
          table[k + 1][i] = -1;
        else
          table[k + 1][i] = table[k][table[k][i]];
      }
    }
  }

  int lca(int u, int v) {
    if (dep[u] > dep[v]) swap(u, v);
    v = climb(v, dep[v] - dep[u]);
    if (u == v) return u;
    for (int i = LOG - 1; i >= 0; i--) {
      if (table[i][u] != table[i][v]) {
        u = table[i][u];
        v = table[i][v];
      }
    }
    return table[0][u];
  }

  int climb(int u, int k) {
    if (dep[u] < k) return -1;
    for (int i = LOG - 1; i >= 0; i--) {
      if ((k >> i) & 1) u = table[i][u];
    }
    return u;
  }

  T dist(int u, int v) { return sum[u] + sum[v] - 2 * sum[lca(u, v)]; }

 private:
  void dfs(int idx, int par, int d) {
    table[0][idx] = par;
    dep[idx] = d;
    for (auto &to : g[idx]) {
      if (to != par) {
        sum[to] = sum[idx] + to.cost;
        dfs(to, idx, d + 1);
      }
    }
  }
};


int main2(){
    ll n, m; cin >> n >> m;
    TwoEdgeConnectedComponents<ll> tegraph(n);
    for(int i = 0; i < m; i++){
        int x, y; cin >> x >> y;
        x--; y--;
        tegraph.add_edge(x, y);
    }
    tegraph.build();

    vector<vector<int>> graph(tegraph.tree.size());
    for(int i = 0; i < graph.size(); i++){
        for(auto edge : tegraph.tree[i]){
            graph[i].emplace_back(edge.to);
        }
    }

    DoublingLowestCommonAncestor<ll> lca(tegraph.tree);
    lca.build();

    ll q; cin >> q;
    for(int qid = 0; qid < q; qid++){
        ll a, b, c; cin >> a >> b >> c;
        a--; b--; c--;
        int ga = tegraph[a];
        int gb = tegraph[b];
        int gc = tegraph[c];

        if(ga == gc){
            if(ga == gb) cout << "OK" << endl;
            else cout << "NG" << endl;
        }
        else{
            if(lca.dist(ga, gb) + lca.dist(gb, gc) == lca.dist(ga, gc)) cout << "OK" << endl;
            else cout << "NG" << endl;
        }
    }
    return 0;
}


int main3() {
    cin2(N,M);
    TwoEdgeConnectedComponents<ll> G(N);
    rep(i,M){
        cin2(a,b);a--;b--;
        G.add_edge(a,b);
    }
    G.build();
    DoublingLowestCommonAncestor<ll> LCA(G.tree);
    LCA.build();

    cin(Q);
    rep(i,Q){
        cin3(a,b,c);
        a--;b--;c--;
        int ga = G[a];
        int gb = G[b];
        int gc = G[c];
        if(ga == gc){
            if(ga == gb) cout << "OK" << endl;
            else cout << "NG" << endl;
        }
        else{
            if(LCA.dist(ga, gb) + LCA.dist(gb, gc) == LCA.dist(ga, gc)) cout << "OK" << endl;
            else cout << "NG" << endl;
        }
    }
    
    return 0;
} 