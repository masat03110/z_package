#include <bits/stdc++.h>
using namespace std;
using ll=long long;
//change mono and func and eval
//note that the lazy propagation must be commutative here
ll mod = 998244353;
struct mono{
    ll val=1e18;
    ll index=0;

    mono operator+(const mono& another) const {
        return mono{(val+another.val)%mod};
    }

    mono operator*(const ll& another) const {
        return mono{(val*another)%mod};
    }

    mono operator*(const mono& another) const {
        return mono{(val*another.val)%mod};
    }

    bool operator==(const mono& another) const {
        return val == another.val;
    }
};

mono func(mono a, mono b){
    if (a.val <= b.val) return a;
    else return b;
}

struct mono_lazy{
    ll mul=1;
    ll add=0;

    mono_lazy operator+(const mono_lazy& another) const {
        return mono_lazy{(mul*another.mul)%mod,(add*another.mul+another.add)%mod};
    }

    mono_lazy operator*(const ll& another) const {
        return mono_lazy{(mul*another)%mod,(add*another)%mod};
    }

    bool operator==(const mono_lazy& another) const {
        return mul == another.mul && add == another.add;
    }
};

struct LazySegmentTree{
    public:
        int n; 
        vector<mono> node;
        vector<mono_lazy> lazy;
        LazySegmentTree(vector<mono> v){
            int sz = v.size();
            n = 1; while(n < sz) n *= 2;
            node.resize(2*n-1,mono());
            lazy.resize(2*n-1,mono_lazy());
        
            for (int i=0;i<sz;i++){
            node[i+n-1] = v[i];
            }
            for (int i=n-2;i>=0;i--) node[i] = func(node[i*2+1],node[i*2+2]);
        }
        
        void eval(int k, int l, int r){
            // change here
            if (!(lazy[k] == mono_lazy())){
                node[k].val = (node[k].val*lazy[k].mul+lazy[k].add*(r-l))%mod;
                if (r - l > 1){
                    lazy[2*k+1] = lazy[2*k+1] + lazy[k];
                    lazy[2*k+2] = lazy[2*k+2] + lazy[k];
                }
                lazy[k] = mono_lazy();
            }
            // until here
        }
        
        void update(int a, int b, mono_lazy x, int k=0, int l=0, int r=-1){
            eval(k,l,r);
            if (r < 0) r = n;
            if (r <= a || b <= l) return;
            if (a <= l && r <= b){
                // change here
                lazy[k] = lazy[k]+x;
                // until here
                eval(k,l,r);
            } else {
                update(a,b,x,2*k+1,l,(l+r)/2);
                update(a,b,x,2*k+2,(l+r)/2,r);
                node[k] = func(node[2*k+1],node[2*k+2]);
            }
        }

        mono get(int a, int b, int k=0, int l=0, int r=-1){
            eval(k,l,r);
            if (r < 0) r = n;
            if (r <= a || b <= l) return mono();
            if (a <= l && r <= b) return node[k];
            mono vl = get(a,b,2*k+1,l,(l+r)/2);
            mono vr = get(a,b,2*k+2,(l+r)/2,r);
            return func(vl,vr);
        }
};