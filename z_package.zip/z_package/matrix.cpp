#include <bits/stdc++.h>

using namespace std;


using matrix = vector<vector<long long>>;

const int mod = 1000000007;

// 行列の掛け算
matrix mul(matrix &a, matrix &b) {
    int n = a.size();
    matrix res(n, vector<long long>(n, 0));
    for(int i = 0; i < n; i++)
        for(int j = 0; j < n; j++)
            for(int k = 0; k < n; k++)
                (res[i][j] += a[i][k] * b[k][j]) %= mod;
    return res;
}

// 行列累乗
matrix pow(matrix m, long long k) {
    int n = m.size();
    matrix res(n, vector<long long>(n, 0));
    for(int i = 0; i < n; i++)
        res[i][i] = 1; // 単位行列にする

    while(k > 0) {
        if(k & 1) res = mul(res, m);
        m = mul(m, m);
        k >>= 1;
    }
    return res;
}