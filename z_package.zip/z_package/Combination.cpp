#include <bits/stdc++.h>


// 
const int MAX = 510000;
const int MOD = 998244353;

long long FAC[MAX], FINV[MAX], INV[MAX];

// O(1)

// テーブルを作る前処理
void COMinit() {
    FAC[0] = FAC[1] = 1;
    FINV[0] = FINV[1] = 1;
    INV[1] = 1;
    for (int i = 2; i < MAX; i++){
        FAC[i] = FAC[i - 1] * i % MOD;
        INV[i] = MOD - INV[MOD%i] * (MOD / i) % MOD;
        FINV[i] = FINV[i - 1] * INV[i] % MOD;
    }
}

// 二項係数計算
long long COM(int n, int k){
    if (n < k) return 0;
    if (n < 0 || k < 0) return 0;
    return FAC[n] * (FINV[k] * FINV[n - k] % MOD) % MOD;
}

// 順列計算
long long PER(int n, int k){
    if (n < k) return 0;
    if (n < 0 || k < 0) return 0;
    return FAC[n] * FINV[n - k] % MOD;
}