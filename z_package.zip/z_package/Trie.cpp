#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }

struct Node{
    array<ll,26> to;
    ll parent;
    ll cnt;
    ll leaf_cnt;
    ll depth;
    ll min_leaf_dist;
    Node() : parent(-1), cnt(0), leaf_cnt(0), depth(0), min_leaf_dist(1e18) {fill(to.begin(),to.end(),-1);}
};

struct Trie{
    vector<Node> nodes;
    Trie(){nodes.push_back(Node());}
    void insert(const string &s){
        ll v = 0;
        for (char c : s){
            ll i = c - 'a';
            if (nodes[v].to[i] == -1){
                nodes[v].to[i] = nodes.size();
                nodes.push_back(Node());
                nodes.back().parent = v;
                nodes.back().depth = nodes[v].depth + 1;
            }
            v = nodes[v].to[i];
            nodes[v].cnt++;
        }
        nodes[v].leaf_cnt++;

        ll u = v;
        while (u != 0){
            chmin(nodes[u].min_leaf_dist,nodes[v].depth);
            u = nodes[u].parent;
        }
        chmin(nodes[0].min_leaf_dist,nodes[v].depth);
    }

    Node find(const string &s){
        ll v = 0;
        for (char c : s){
            ll i = c - 'a';
            if (nodes[v].to[i] == -1){
                return Node();
            }
            v = nodes[v].to[i];
        }
        return nodes[v];
    }

    // 編集距離の最小値を求める
    ll score(const string &s){
        ll res = 1e18;
        ll v = 0;
        res = min(res,nodes[v].min_leaf_dist-2*nodes[v].depth+(ll)s.size());
        for (char c : s){
            ll i = c - 'a';
            if (nodes[v].to[i] == -1){
                break;
            }
            v = nodes[v].to[i];
            res = min(res,nodes[v].min_leaf_dist-2*nodes[v].depth+(ll)s.size());
        }
        return res;
    }
};

int main2() {
    cin(N);
    vector<string> S(N);
    rep(i,N) cin >> S[i];
    Trie trie;
    trie.insert("");
    rep(i,N){
        cout << trie.score(S[i]) << endl;
        trie.insert(S[i]);
    }
    
    return 0;
} 
