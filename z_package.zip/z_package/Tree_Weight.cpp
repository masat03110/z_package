#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
#include <atcoder/all>

using std::cout; using namespace std; using ll=long long; using ld=long double; using lp=array<ll,2>;//using mll = atcoder::modll998244353;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (ll i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }

struct Tree_Weight{
    public: 
    vector<vector<lp>> G;
	ll N;
    vector<ll> EulerTour_d;
    vector<ll> EulerTour;
    vector<ll> EulerTour_id;
    vector<ll> EulerTour_dist;
    vector<ll> depth;
    vector<ll> median_poll;
	array<ll,3> diameter;
    atcoder::segtree<array<ll,2>, [](array<ll,2> a, array<ll,2> b){return a[0] < b[0] ? a:b;}, [](){return array<ll,2>{(ll)1e9,-1};} > seg;
    atcoder::segtree<ll, [](ll a, ll b){return a+b;}, [](){return 0;}> seg2;
    unordered_map<ll,ll> edge_to_pos;

    vector<vector<ll>> path_decomposition;
    vector<ll> path_decomposition_length;
    vector<vector<array<ll,2>>> g; // 根付き木の隣接リスト
    vector<ll> sub;    // i を根とする部分木のサイズ
    vector<ll> parent;

    ll dfs_hld(ll c, ll p = -1, ll l = 0) {
        parent[c] = p;
        sub[c] = l;
        if (g[c].size() && g[c][0][0] == p) swap(g[c][0], g[c].back());
        for(auto& d : g[c]) {
            if(d[0] == p) continue;
            //outvec({c,d,l});
            sub[c] += dfs_hld(d[0], c, d[1]);
            // 今見ている部分木が g[c][0] を根とする部分木より大きい場合 swap
            if(sub[d[0]] > sub[g[c][0][0]]) swap(d, g[c][0]);
        }
        return sub[c];
    }

    vector<ll> order; // i が行きがけ順で何番目に来るか
    vector<ll> head;  // i を含む heavy path の端点
    void dfs2(ll c, ll &i, ll p = -1) {
        order[c] = i++;
        for(auto [d,l] : g[c]) {
            if(d == p) continue;
            //outvec({c,d,g[c][0]});
            head[d] = (g[c][0][0] == d ? head[c] : d);
            dfs2(d, i, c);
        }
    }

    void dfs_hld_path(ll c, ll p = -1) {
        path_decomposition.back().push_back(c);
        for(auto [d,l] : g[c]) {
            if(d == p) continue;
            dfs_hld_path(d, c);
            if (path_decomposition.back().size() > 0) path_decomposition.push_back(vector<ll>());
        }
    }

    void dfs_e(ll now, ll par, ll d){
        EulerTour.push_back(now);
        EulerTour_d.push_back(now);
        depth[now] = d;
        for(auto [next, nd]: G[now]){
            if(next == par) continue;
            EulerTour_dist.push_back(nd);
            dfs_e(next, now, d+1);
            EulerTour_dist.push_back(-nd);
            EulerTour_d.push_back(now);
        }
        return;
    }

    ll dfs_mp(ll v, ll p){
        ll child = 0;
        ll tree_size = 0;
        for (auto [nv,_]: G[v]){
            if (nv == p) continue;
            ll c = dfs_mp(nv,v);
            child += c;
            tree_size = max(tree_size,c);
        }
        tree_size = max(tree_size, N - child - 1);
        if (tree_size <= N/2) median_poll.push_back(v);
        return child + 1;
    };

	void dfs_dis(ll v, ll p, ll nowdis, ll &maxdis, ll &maxnode){
		if (nowdis > maxdis){
			maxdis = nowdis;
			maxnode = v;
		}
		for (auto [nv,nd]: G[v]){
			if (nv == p) continue;
			dfs_dis(nv,v,nowdis+nd,maxdis,maxnode);
		}
	}

    Tree_Weight(vector<vector<lp>> _G): seg(_G.size()*2), seg2(_G.size()*2), G(_G), depth(_G.size(),1e9) , EulerTour_id(_G.size(),-1), EulerTour_d(), diameter({0,0,0}), N(_G.size()), sub(_G.size()), g(_G), order(_G.size()), head(_G.size()){
        N = _G.size();
        sub.resize(N,-1);
        parent.resize(N,-1);
		dfs_e(0, -1, 0);
        dfs_mp(0,-1);
		dfs_dis(0,-1,0,diameter[0], diameter[1]);
		dfs_dis(diameter[1],-1,0,diameter[0],diameter[2]);

        dfs_hld(0);
        parent[0] = 0;
        ll i = 0;
        dfs2(0, i);
        path_decomposition.push_back(vector<ll>());
        dfs_hld_path(0);
        path_decomposition.pop_back();

        for(ll i=0; i<EulerTour_d.size(); i++){
            if (EulerTour_id[EulerTour_d[i]] == -1) EulerTour_id[EulerTour_d[i]] = i;
            seg.set(i, {depth[EulerTour_d[i]],i});
            assert(depth[EulerTour_d[i]] != 1e9);
        }

        for(ll i=0; i<EulerTour_dist.size(); i++){
            seg2.set(i, EulerTour_dist[i]);
            edge_to_pos[EulerTour_d[i]*N+EulerTour_d[i+1]] = (EulerTour_dist[i] >= 0 ? i : -i);
        }

        for (auto v: path_decomposition){
            path_decomposition_length.push_back(get_dist(parent[v[0]],v.back()));
        }
    }

    ll get_LCA(ll u, ll v){
        ll l = EulerTour_id[u];
        ll r = EulerTour_id[v];
        if(l > r) swap(l,r);
        return EulerTour_d[seg.prod(l,r+1)[1]];
    }

    ll get_dist(ll u, ll v){
        ll l = EulerTour_id[u];
        ll r = EulerTour_id[v];
        return seg2.prod(0,l) + seg2.prod(0,r) - 2*seg2.prod(0,EulerTour_id[get_LCA(u,v)]);
    }

    void change_dist(ll u, ll v, ll d){
        ll pos = edge_to_pos[u*N+v];
        if (pos < 0) {
            seg2.set(-pos,-d);
        }else{
            seg2.set(pos,d);
        }
        
        pos = edge_to_pos[v*N+u];
        if (pos < 0) {
            seg2.set(-pos,-d);
        }else{
            seg2.set(pos,d);
        }
    }
};

int main2(){
	int N; cin >> N;
	vector<vector<lp>> G(N);
	for (int i=0;i<N-1;i++){
		int a,b;
        cin >> a >> b;
		a--;b--;
		G[a].push_back({b,1});
		G[b].push_back({a,1});
	}
	Tree_Weight T(G);
    cin(Q);
    rep(i,Q){
        cin2(a,b);
        a--; b--;
        cout << T.get_dist(a,b)+1 << endl;
    }
}