#include <bits/stdc++.h>

using namespace std;
using ll=long long;

template<typename T>
struct slido_min{
    vector<T> dat;
    ll siz;
    deque<ll> deq;

    slido_min(ll k){
        siz = k;
    }

    void push(T x){
        dat.push_back(x);
        ll n = dat.size()-1;
        while(!deq.empty() && dat[deq.back()] >= x) deq.pop_back();
        deq.push_back(n);
        while(n >= deq.front()+siz) deq.pop_front();
    }

    T get_min(){
        return dat[deq.front()];
    }
};