// https://atcoder.jp/contests/abc266/tasks/abc266_f
// https://atcoder.jp/contests/abc357/tasks/abc357_e

#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}

struct Tree_NonWeight{
    public: 
    vector<vector<int>> G;
    int N;
    vector<int> EulerTour_d;
    vector<int> EulerTour;
    vector<int> EulerTour_id;
    vector<int> depth;
    vector<int> median_point;
    array<int,3> diameter;
    atcoder::segtree<array<int,2>, [](array<int,2> a, array<int,2> b){return a[0] < b[0] ? a:b;}, [](){return array<int,2>{(int)1e9,-1};} > seg;
    vector<vector<int>> path_decomposition;
    vector<vector<int>> g; // 根付き木の隣接リスト
    vector<int> sub;    // i を根とする部分木のサイズ

    vector<int> parent;

    int dfs_hld(int c, int p = -1) {
        parent[c] = p;
        sub[c] = 1;
        if (g[c].size() && g[c][0] == p) swap(g[c][0], g[c].back());
        for(auto& d : g[c]) {
            if(d == p) continue;
            sub[c] += dfs_hld(d, c);
            // 今見ている部分木が g[c][0] を根とする部分木より大きい場合 swap
            if(sub[d] > sub[g[c][0]]) swap(d, g[c][0]);
        }
        return sub[c];
    }

    vector<int> order; // i が行きがけ順で何番目に来るか
    vector<int> head;  // i を含む heavy path の端点
    void dfs2(int c, int &i, int p = -1) {
        order[c] = i++;
        for(auto& d : g[c]) {
            if(d == p) continue;
            //outvec({c,d,g[c][0]});
            head[d] = (g[c][0] == d ? head[c] : d);
            dfs2(d, i, c);
        }
    }

    void dfs_hld_path(int c, int p = -1) {
        path_decomposition.back().push_back(c);
        for(auto d : g[c]) {
            if(d == p) continue;
            dfs_hld_path(d, c);
            if (path_decomposition.back().size() > 0) path_decomposition.push_back(vector<int>());
        }
    }

    void dfs_e(int now, int par, int d){
        EulerTour.push_back(now);
        EulerTour_d.push_back(now);
        depth[now] = d;
        for(auto next: G[now]){
            if(next == par) continue;
            dfs_e(next, now, d+1);
            EulerTour_d.push_back(now);
        }
        return;
    }

    int dfs_mp(int v, int p){
        int child = 0;
        int tree_size = 0;
        for (auto nv: G[v]){
            if (nv == p) continue;
            int c = dfs_mp(nv,v);
            child += c;
            tree_size = max(tree_size,c);
        }
        tree_size = max(tree_size, N - child - 1);
        if (tree_size <= N/2) median_point.push_back(v);
        return child + 1;
    };

    void dfs_dis(int v, int p, int nowdis, int &maxdis, int &maxnode){
        if (nowdis > maxdis){
            maxdis = nowdis;
            maxnode = v;
        }
        for (auto nv: G[v]){
            if (nv == p) continue;
            dfs_dis(nv,v,nowdis+1,maxdis,maxnode);
        }
    }

    vector<vector<int>> doubling_parent;

    void doubling_init(){
        doubling_parent.resize(32,vector<int>(N,-1));
        doubling_parent[0] = parent;

        for (ll i=0; i < doubling_parent.size()-1;i++){
            rep(j,N){
                doubling_parent[i+1][j] = doubling_parent[i][doubling_parent[i][j]];
            }
        }
    }

    // xとroot(0)とのpathのうち、根からindex番目(0はroot)を返す
    int get_root_path_index(int x, int index){
        if (index > depth[x]) return -1;
        int times = depth[x]-index;
        int now = x;
        rep(i,doubling_parent.size()){
            if ((times >> i) & 1){
                now = doubling_parent[i][now];
            }
        }
        return now;
    }

    Tree_NonWeight(){};

    Tree_NonWeight(vector<vector<int>> _G): seg(_G.size()*2), G(_G), depth(_G.size(),1e9) , EulerTour_id(_G.size(),-1), EulerTour_d(), diameter({0,0,0}), g(_G), sub(_G.size()), order(_G.size()), head(_G.size()){
        parent.resize(_G.size());
        N = _G.size();
        dfs_e(0, -1, 0);
        dfs_mp(0,-1);
        dfs_dis(0,-1,0,diameter[0], diameter[1]);
        dfs_dis(diameter[1],-1,0,diameter[0],diameter[2]);

        dfs_hld(0);
        parent[0] = 0;
        int i = 0;
        dfs2(0, i);
        path_decomposition.push_back(vector<int>());
        dfs_hld_path(0);
        path_decomposition.pop_back();

        for(int i=0; i<EulerTour_d.size(); i++){
            if (EulerTour_id[EulerTour_d[i]] == -1) EulerTour_id[EulerTour_d[i]] = i;
            seg.set(i, {depth[EulerTour_d[i]],i});
            assert(depth[EulerTour_d[i]] != 1e9);
        }

        doubling_init();
    }

    int get_LCA(int u, int v){
        int l = EulerTour_id[u];
        int r = EulerTour_id[v];
        if(l > r) swap(l,r);
        return EulerTour_d[seg.prod(l,r+1)[1]];
    }

    int get_dist(int u, int v){
        return depth[u] + depth[v] - 2*depth[get_LCA(u,v)];
    }

    // uからvへのpathのうち、uからk番目を返す(0番目はuである)
    int get_uvpath_kth(int u, int v, int k){
        assert(k >= 0);
        int lca = get_LCA(u,v);
        int path_length_u = depth[u]-depth[lca];
        int path_length_v = depth[v]-depth[lca];
        if (k <= path_length_u) return get_root_path_index(u,depth[u]-k);
        else if (k <= path_length_u+path_length_v) return get_root_path_index(v, depth[v]-(path_length_u+path_length_v-k));
        else return -1;
    }

    // iを根とする部分木の頂点数を返す
    int get_subtree_size(int i){
        return sub[i];
    }
};

struct FunctionalGraph{
    int N, N_oya;
    vector<int> par; // 親
    vector<vector<ll>> G; // 元のfunctional graph
    vector<bool> is_loop; // ループかどうか
    vector<int> butukaru_loop; // ループとなっている最近の親
    vector<vector<int>> revpar; // 子
    vector<vector<int>> newTree; // ループに対し、代表点を新たに作成し、木にしたもの
    vector<int> loop_size, loop_id; // 属しているループのidと、その大きさ　属していないなら、-1

    // vector<vector<int>> Tree;
    // vector<vector<int>> Tree_compressed;
    // vector<int> compressed_id, compressed_id_rev;

    Tree_NonWeight _Tree_NonWeight;

    FunctionalGraph(){};

    int degree(int i, vector<vector<ll>> &G, vector<bool> &visited){
        int cnt = 0;
        for (auto j : G[i]){
            if (visited[j]) continue;
            cnt++;
        }
        return cnt;
    }

    FunctionalGraph(vector<ll> &_par){
        N = _par.size();
        rep(i,N) par.push_back(_par[i]);
        G.resize(N);
        rep(i,N){
            if (par[i] != -1){
                G[par[i]].push_back(i);
                G[i].push_back(par[i]);
            }
        }

        init1();
    }

    FunctionalGraph(vector<vector<ll>> &_G){
        N = _G.size();
        par.resize(N, -1);
        G.resize(N);
        rep(i,N) G[i] = _G[i];

        init1();
    };

    void init1(){
        vector<bool> visited(N, false);
        butukaru_loop.resize(N, 0);
        rep(i,N) butukaru_loop[i] = i;
        // 次数が1のものから、次数が3以上のものにぶつかるまでみる
        rep(i,N){
            ll now = i;
            if (degree(now, G, visited) != 1) continue;
            ll next = -1;
            for (auto j : G[now]){
                if (!visited[j]){
                    next = j;
                    break;
                }
            }
            visited[now] = true;
            while (degree(next, G, visited) == 1){
                visited[next] = true;
                if (par[now] == -1) par[now] = next;
                now = next;
                for (auto j : G[next]){
                    if (!visited[j]){
                        next = j;
                        break;
                    }
                }
            }
            if (par[now] == -1) par[now] = next;
        }

        // 残りはループであるため、parを決定する
        // また、dfsでそれぞれの点の親となるループ点を決定する

        function<void(int,int,int)> dfs = [&](int now, int p, int i){
            for (auto next : G[now]){
                if (next == p) continue;
                if (!visited[next]) continue;
                butukaru_loop[next] = i;
                dfs(next, now, i);
            }
        };

        is_loop.resize(N, false);
        rep(i,N) if (!visited[i]) is_loop[i] = true;

        rep(i,N) if (!visited[i]){
            dfs(i, -1, i);
        }

        rep(i,N){
            if (visited[i]) continue;
            ll now = i;
            while(true){
                visited[now] = true;
                ll next = -1;
                for (auto j : G[now]){
                    if (!visited[j]){
                        next = j;
                        break;
                    }
                }
                if (next == -1) break;
                if (par[now] == -1) par[now] = next;
                now = next;
            }
            if (par[now] == -1) par[now] = i;
        }

        revpar.resize(N, vector<int>());
        rep(i,N) if (par[i] == -1) revpar[i].push_back(i);

        // ループを検出し、新たに木を作成する
        newTree.resize(N, vector<int>());
        loop_size.resize(N, -1);
        loop_id.resize(N, -1);
        rep(i,N){
            if (is_loop[i]){
                if (loop_id[i] != -1) continue;
                vector<ll> loop;
                loop.push_back(i);
                ll now = par[i];
                while (now != i){
                    loop.push_back(now);
                    now = par[now];
                }
                for (auto j : loop){
                    is_loop[j] = true;
                    loop_id[j] = newTree.size();
                    loop_size[j] = loop.size();
                }
                newTree.push_back(vector<int>());
                for (auto j : loop){
                    newTree.back().push_back(j);
                    newTree[j].push_back(newTree.size()-1);
                }
            }else{
                if (par[i] == -1) assert(false);
                newTree[i].push_back(par[i]);
                newTree[par[i]].push_back(i);
            }
        }

        // さらに、全てのループと繋がる点を追加する
        // その点を0とする。そのために、全てのindexをずらす
        rep(i,newTree.size()){
            rep(j,newTree[i].size()){
                newTree[i][j]++;
            }
        }
        newTree.insert(newTree.begin(), vector<int>());
        rep2(i,N+1,newTree.size()){
            newTree[i].push_back(0);
            newTree[0].push_back(i);
        }

        // // newTreeを見る
        // rep(i,newTree.size()){
        //     cout << i+1 << ": ";
        //     for (auto j : newTree[i]){
        //         cout << j+1 << " ";
        //     }
        //     cout << endl;
        // }

        _Tree_NonWeight = Tree_NonWeight(newTree);
    }

    // 同じ成分なら、ループを根にした場合のLCAを返す
    // LCAがループで異なるものの時は、ループのidを返す
    int get_LCA(int u, int v){
        int lca = _Tree_NonWeight.get_LCA(u+1, v+1);
        if (lca == 0) return -1;
        else return lca-1;
    };

    // ループに属しているかどうか
    // 属しているなら、ループの大きさを返す
    // 属していないなら、0を返す
    int get_loop_size(int u){
        return loop_size[u];
    };

    // ループとなる親を返す
    int get_parentloop(int u){
        return butukaru_loop[u];
    };

    // ループとなる親の、ループの大きさを返す
    int get_parentloop_size(int u){
        return loop_size[butukaru_loop[u]];
    };

    // 同じループに属している点のリストを返す
    vector<int> get_loop(int u){
        vector<int> ret;
        if (loop_id[u] == -1) return ret;
        for (auto i : newTree[loop_id[u]+1]){
            if (i == 0) continue;
            ret.push_back(i-1);
        }
        return ret;
    };

    // ループからどれだけ離れているかを返す
    // ループに属していたら0を返す
    int get_loop_dist(int u){
        ll depth = _Tree_NonWeight.depth[u+1];
        return depth - 2;
    };
};


int main2() {
    cin(N);
    cinvec(A);
    rep(i,N) A[i]--;

    FunctionalGraph FG(A);

    ll ans = 0;

    rep(i,N){
        if (FG.get_loop_size(i) > 0){
            ans += (FG.get_loop_size(i));
        }else{
            ans += (FG.get_parentloop_size(i));
            ans += (FG.get_loop_dist(i));
            //cout << i+1 << ": " << FG.get_parentloop(i)+1 << " " << FG.get_loop_dist(i) << endl;
        }
    }

    cout << ans << endl;
    
    return 0;
} 
