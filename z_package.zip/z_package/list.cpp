#include <bits/stdc++.h>

using namespace std;

using ll=long long;
using ld=long double;
#define rep(i,n) for (ll i=0;i<(n);i++)
#define rep2(i,a,b) for (ll i=(a);i<(b);i++)
#define repd(i,a,b) for (ll i=(a);i>=(b);i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}

int main2() {
    cin(N);
    cinvec2(A,N);
    list<ll> lst;
    // llとイテレータの対応を保持するmap
    unordered_map<ll,list<ll>::iterator> mp;
    rep(i,N){
        mp[A[i]] = lst.insert(lst.begin(),A[i]);
        //cout << "mp[" << A[i] << "] = " << *mp[A[i]] << endl;
    }
    cin(Q);

    rep(i,Q){
        cin(a);
        if (a == 1){
            cin2(b,c);
            auto it = mp[b];
            mp[c] = lst.insert(it,c);
            // cout << "mp[" << c << "] = " << *mp[c] << endl;
            // cout << "mp[" << b << "] = " << *mp[b] << endl;
        }else if (a == 2){
            cin(b);
            auto it = mp[b];
            lst.erase(it);
            mp.erase(b);
        }

    //         for (auto it = lst.begin(); it != lst.end(); it++){
    //     if (it != lst.begin()) cout << " ";
    //     cout << *it;
    // }
    // cout << endl;
    }

    reverse(lst.begin(),lst.end());

    for (auto it = lst.begin(); it != lst.end(); it++){
        if (it != lst.begin()) cout << " ";
        cout << *it;
    }
    cout << endl;
    
    return 0;
} 