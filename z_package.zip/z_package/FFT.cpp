#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

// typical90 065

// 高速フーリエ変換（Fast Fourier Transform）の実装．
// 今回は，mod が素数であるときの NTT（Number Theoretic Transform）を実装する．

// A(x) = 1+2x+3x^2, B(x) = 2+3x+4x^2のとき、
// A(x) * B(x) = 2+7x+16x^2+17x^3+12x^4 となることを計算するには、
// a[] = {1,2,3}, b[] = {2,3,4} として、
// convolution(a,b) を計算すればよい．
// このとき、convolution(a,b) は {2,7,16,17,12} を返す．

long long p = 998244353; // NTT に相性の良い mod は 998244353．

// 繰り返し二乗法で x ^ n を mod で割った余りを求める．
long long my_pow(long long x, long long n, long long mod){
    long long ret;
    if (n == 0){
        ret = 1;
    }
    else if (n % 2 == 1){
        ret = (x * my_pow((x * x) % mod, n / 2, mod)) % mod;
    }
    else{
        ret = my_pow((x * x) % mod, n / 2, mod);
    }
    return ret;
}

// mod を法とする x の逆元を計算する．
long long mod_inv(long long x, long long mod){
    return my_pow(x, mod - 2, mod);
}

vector<long long> ntt(vector<long long> &a, long long depth, vector<long long> &root){
    // inv = 1 ならば普通の NTT，inv = -1 ならば INTT になるようにする（今回は，呼び出す root が逆元かそうでないかによって調整する）．
    long long n = a.size();
    vector<long long> ret(0);
    // a のサイズが 1 であるときは，それがそのまま DFT である．
    if (n == 1){
        return a;
    }
    else{
        vector<long long> even(0);
        vector<long long> odd(0);
        for (long long i = 0; i < n; i++){
            if (i % 2 == 0) even.push_back(a[i]);
            else odd.push_back(a[i]);
        }
        // even と odd の DFT を，再帰的に求める．
        vector<long long> d_even = ntt(even, depth - 1, root);
        vector<long long> d_odd = ntt(odd, depth - 1, root);

        long long r = root[depth];
        
        long long now = 1;
        for (long long i = 0; i < n; i++){
            ret.push_back((d_even[i % (n / 2)] + (now * d_odd[i % (n / 2)]) % p) % p);
            now = (now * r) % p;
        }
    }
    return ret;
}


vector<long long> convolution(vector<long long> &a, vector<long long> &b, vector<long long> &root, vector<long long> &invroot){
    // 配列 a, b は，それぞれ A(x) と B(x) の係数を次数の小さい順に並べたもの．
    int len_a = a.size();
    int len_b = b.size();
    int len_c = len_a + len_b - 1; // len_c は A(x) * B(x) の次数
    int n = 1;
    // len_c より大きい最小の 2 べきの数を求める
    while(n <= len_c){
        n *= 2;
    }

    // 配列の長さが n になるまで，配列の末尾に 0 を追加する
    while(a.size() < n){
        a.push_back(0LL);
    }
    while(b.size() < n){
        b.push_back(0LL);
    }


    long long log_2n = 1;
    while ((1LL << log_2n) < n){
        log_2n++;
    }

    // A(x) の NTT DA(t), b(x) の NTT DB(t) を求める．
    // 配列 da, db は，それぞれ DA(t), DB(t) の係数を次数の小さい順に並べたもの．
    vector<long long> da = ntt(a, log_2n - 1, root);
    vector<long long> db = ntt(b, log_2n - 1, root);

    // C(x) の NTT DC(t). これの k 次の係数は， DA(t) と DB(t) の k 次の係数を掛け合わせれば求まる．
    vector<long long> dc(n);
    for (int i = 0; i < n; i++){
        dc[i] = (da[i] * db[i]) % p;
    }

    // C(x) は DC(t) を INTT すれば求まる．このようにしてできた配列 c は，C(x) の係数を次数の小さい順に並べたものとなっている．
    vector<long long> c = ntt(dc, log_2n - 1, invroot);

    // INTT の後は最後に n で割ることを忘れずに．
    vector<long long> ret(0);
    for (int i = 0; i < n; i++){
        ret.push_back((c[i] * mod_inv((long long)n, p)) % p);
    }
    return ret;
}

// NTT に必要となる r の累乗数を求める．
vector<long long> make_root(long long mod){
    vector<long long> ret(0);
    long long r = my_pow(3, 119, mod);
    for (long long i = 0; i < 23; i++){
        ret.push_back(r);
        r = (r * r) % mod;
    }
    reverse(ret.begin(), ret.end());
    return ret;
}

// NTT に必要となる r の累乗数の逆元を求める．
vector<long long> make_invroot(vector<long long> &root, long long mod){
    vector<long long> ret;
    for (long long i = 0; i < root.size(); i++){
        ret.push_back(mod_inv(root[i], mod));
    }
    return ret;
}

int main2(){
    int na;
    int nb;
    cin >> na >> nb;
    // a は A(x) の係数を次数の小さい順に並べたもの． b は B(x) の係数を次数の小さい順に並べたもの．
    vector<long long> a(na);
    vector<long long> b(nb);
    
    // 入力を受け取る．
    for (int i = 0; i < na; i++){
        cin >> a[i];
    }
    for (int i = 0; i < nb; i++){
        cin >> b[i];
    }

    // NTT で必要となる r の累乗数を前計算しておく（これをしないと計算量が悪くなる）．
    vector<long long> root = make_root(p);
    vector<long long> invroot = make_invroot(root, p);

    // convolution 関数で A(x) と B(x) の多項式乗算を行い，C(x) = A(x) * B(x) の係数を小さい順に並べた配列 c を返す．
    vector<long long> c = convolution(a, b, root, invroot);
    for (int i = 0; i < na + nb - 1; i++){
        cout << c[i] << endl;
    }
}
