//https://atcoder.jp/contests/arc199/tasks/arc199_b

#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double; using lp=array<ll,2>;
#define rep(i,n) for (ll i=0;i<n;i++)
#define rep2(i,a,b) for (ll i=(a);i<b;i++)
#define repd(i,a,b) for (ll i=(a);i>=b;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
#define seg_RmaRmsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{(a[0]+b[0])%998244353ll,a[1]+b[1]};},[&](){return array<ll,2>{0,0};},array<ll,2>,[&](array<ll,2> m, array<ll,2> n){ return array<ll,2>{(m[0]*n[0]+m[1]*n[1])%998244353ll,n[1]};}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0]%998244353ll, (b[1]*a[0]+a[1])%998244353ll};},[&](){return array<ll,2>{1ll,0ll};}>
#define seg_Parentheses atcoder::segtree<array<int,3>, [&](array<int,3> a, array<int,3> b){ int m = min(a[1], b[2]);return array<int,3>{a[0]+b[0]+2*m, a[1]+b[1]-m, a[2]+b[2]-m};},[](){return array<int,3>{0,0,0};}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
template<typename T, typename F> T bs(T l, T r, F f) { for(int i=0;i<100;i++){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
template<typename T, typename F> T bs_fast(T l, T r, F f) { while(r-l>1){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}
ll stollmod(string S, ll mod) {ll ret = 0; rep(i,S.size()){ ret = (ret*10 + (S[i]-'0'))%mod; } return ret; }

void verify(vector<ll> &A, vector<int> &output, ll K) {
    vector<ll> B = A;
    rep(i, output.size()) {
        B[output[i] - 1] = B[output[i] - 1] ^ B[output[i]];
        B[output[i]] = B[output[i] - 1];
    }

    //assert(K == B[0]);
    //cout << K << " == " << B[0] << endl;
}

void hukugen(vector<int> &selected_indices, ll N, vector<ll> &A, ll K) {
    vector<int> result(N, 0);
    for (int idx : selected_indices) {
        result[idx] = 1; // 選ばれたインデックスを1に設定
    }
    //outvec(result);
    // 00を探す
    int zerozero_index = -1;
    for (int i = 0; i < N - 1; ++i) {
        if (result[i] == 0 && result[i + 1] == 0) {
            zerozero_index = i;
            break;
        }
    }
    // 11を探す
    int oneone_index = -1;
    for (int i = 0; i < N - 1; ++i) {
        if (result[i] == 1 && result[i + 1] == 1) {
            oneone_index = i;
            break;
        }
    }

    
        vector<int> output;
        if (zerozero_index != -1){
            output.push_back(zerozero_index + 1); // 1-based index
            output.push_back(zerozero_index + 1); // 1-based index
        }else{
            zerozero_index = oneone_index;
        }
        // 右側を見る
        for (int i = zerozero_index + 2; i < N; ++i) {
            if (result[i] == 1) {
                repd(j, i-1, zerozero_index) {
                    output.push_back(j + 1); // 1-based index
                }
                rep2(j, zerozero_index + 1, i) {
                    output.push_back(j + 1); // 1-based index
                    output.push_back(j + 1); // 1-based index
                }
            }else{
                output.push_back(zerozero_index + 1); // 1-based index
                
                rep2(j, zerozero_index + 1, i) {
                    output.push_back(j + 1); // 1-based index
                    output.push_back(j + 1); // 1-based index
                }
            }
        }
        // 左側を見る
        for (int i = zerozero_index - 1; i >= 0; --i) {
            if (result[i] == 1) {
                rep2(j, i, zerozero_index+1) {
                    output.push_back(j + 1); // 1-based index
                }
                rep2(j, i, zerozero_index) {
                    output.push_back(j + 1); // 1-based index
                    output.push_back(j + 1); // 1-based index
                }
            }else{
                output.push_back(zerozero_index + 1); // 1-based index
                
                rep2(j, i, zerozero_index) {
                    output.push_back(j + 1); // 1-based index
                    output.push_back(j + 1); // 1-based index
                }
            }
        }
        // 左端にもっていく
        repd(i, N-2, 0){
            output.push_back(i + 1); // 1-based index
        }

        cout << output.size() << endl;
        outvec(output);
        verify(A, output, K);
        return;
}

void find_valid_subset_with_xor(vector<ll> A, ll k) {
    ll K = k;
    ll N = A.size();
    vector<ll> basis;                      // XOR基底
    vector<unordered_set<ll>> basis_repr;        // 各基底が構成されたインデックス集合
    vector<unordered_set<ll>> zeroset;

    // XOR基底の構築（Gaussian elimination over GF(2)）
    for (ll i = 0; i < N; ++i) {
        ll x = A[i];
        unordered_set<ll> used = {i};
        for (ll j = 0; j < basis.size(); ++j) {
            if ((x ^ basis[j]) < x) {
                x ^= basis[j];
                for (ll idx : basis_repr[j]) {
                    if (used.count(idx) == 0) {
                        used.insert(idx);
                    }else{
                        used.erase(idx); // 同じインデックスがあれば削除
                    }
                }
            }
        }
        if (x != 0) {
            basis.push_back(x);
            basis_repr.push_back(used);
        }else{
            zeroset.push_back(used); // 0を構成するインデックス集合を保存
        }
    }

    // K を構成できるか？
    vector<int> selected_indices;
    for (int i = 0; i < basis.size(); ++i) {
        if ((K ^ basis[i]) < K) {
            K ^= basis[i];
            selected_indices.insert(selected_indices.end(), basis_repr[i].begin(), basis_repr[i].end());
        }
    }

    //outvec(basis);
    //outvec(selected_indices);

    if (K != 0) {
        cout << "No" << endl;
        return;
    }else{
        unordered_map<int, int> index_count;
        for (int idx : selected_indices) {
            index_count[idx]++;
        }
        selected_indices.clear();
        for (const auto& pair : index_count) {
            if (pair.second % 2 == 1) { // 奇数回出現するインデックスのみを選択
                selected_indices.push_back(pair.first);
            }
        }

        sort(selected_indices.begin(), selected_indices.end());

        if (selected_indices.empty()) {
            cout << "Yes" << endl;
            cout << 2 << endl;
            cout << 1 << " " << 1 << endl; // 何も選ばない場合は、1と1を出力
            return;
        }
            // 禁止されているパターンとの照合
            vector<int> dame1, dame2;
            rep(i,N) {
                if (i%2) dame1.push_back(i);
                else dame2.push_back(i);
            }

            // outvec(dame1);
            // outvec(dame2);
            // outvec(selected_indices);

            if (selected_indices == dame1 || selected_indices == dame2) {
                if (basis.size() == A.size()) {
                    cout << "No" << endl;
                    return;
                }else{
                    //To do
                    if (zeroset[0].size() == N) {
                        if (basis.size() == (N - 1)) {
                            cout << "No" << endl;
                            return;
                        }else{
                            for (auto x:selected_indices) {
                                if (zeroset[1].count(x) == 0) {
                                    zeroset[1].insert(x);
                                }else{
                                    zeroset[1].erase(x);
                                }
                            }
                            vector<int> tmp(zeroset[1].begin(), zeroset[1].end());
                            cout << "Yes" << endl;
                            hukugen(tmp, N, A, k);
                        }
                    }else{
                        for (auto x:selected_indices) {
                            if (zeroset[0].count(x) == 0) {
                                zeroset[0].insert(x);
                            }else{
                                zeroset[0].erase(x);
                            }
                        }
                        vector<int> tmp(zeroset[0].begin(), zeroset[0].end());
                        cout << "Yes" << endl;
                        hukugen(tmp, N, A, k);
                    }
                }
            }else{
                cout << "Yes" << endl;
                hukugen(selected_indices, N, A, k);
                return;
            }
    }
}

void solve(){
    cin2(N,K);
    cinvec(A);

    find_valid_subset_with_xor(A, K);

    return;
}

int main() {
    cin(T);
    rep(i,T) solve();
    
    return 0;
} 
