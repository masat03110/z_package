#include <bits/stdc++.h>
using namespace std;
using ll = long long;

// typical90 041
#define rep(i,n) for(ll i=0;i<(n);i++)

// 凸包を返す
// O(NlogN)

struct Point {
	ll x, y;

	bool operator <(const Point &p) const {
		return x < p.x || (x == p.x && y < p.y);
	}
};

// 3D cross product of OA and OB vectors, (i.e z-component of their "2D" cross product, but remember that it is not defined in "2D").
// Returns a positive value, if OAB makes a counter-clockwise turn,
// negative for clockwise turn, and zero if the points are collinear.
ll cross(const Point &O, const Point &A, const Point &B)
{
	return (A.x - O.x) * (B.y - O.y) - (A.y - O.y) * (B.x - O.x);
}

// Returns a list of points on the convex hull in counter-clockwise order.
// Note: the last point in the returned list is the same as the x one.
vector<Point> convex_hull(vector<Point> P)
{
	size_t n = P.size(), k = 0;
	if (n <= 3) return P;
	vector<Point> H(2*n);

	// Sort points lexicographically
	sort(P.begin(), P.end());

	// Build lower hull
	for (size_t i = 0; i < n; ++i) {
		while (k >= 2 && cross(H[k-2], H[k-1], P[i]) <= 0) k--;
		H[k++] = P[i];
	}

	// Build upper hull
	for (size_t i = n-1, t = k+1; i > 0; --i) {
		while (k >= t && cross(H[k-2], H[k-1], P[i-1]) <= 0) k--;
		H[k++] = P[i-1];
	}

	H.resize(k-1);
	return H;
}

ll Surface_mul2(vector<Point> cv){
    ll res = 0;
    rep(i,cv.size()-1){
        res += (cv[i].x - cv[i+1].x) * (cv[i].y + cv[i+1].y);
    }
    res += (cv[cv.size()-1].x - cv[0].x) * (cv[cv.size()-1].y + cv[0].y);
    return abs(res);
}

ll LatticePointsOnLine(vector<Point> cv){
    ll res = 0;
    rep(i,cv.size()-1){
        res += __gcd(abs(cv[i].x - cv[i+1].x),abs(cv[i].y - cv[i+1].y));
    }
    res += __gcd(abs(cv[cv.size()-1].x - cv[0].x),abs(cv[cv.size()-1].y - cv[0].y));
    return res;
}

ll LatticePointsInSurface(vector<Point> cv){
    return (Surface_mul2(cv) - LatticePointsOnLine(cv) + 2)/2;
}