#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
#include <atcoder/all>

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{m[0]+n*m[1],m[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0;}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }

struct segment_length{
    // [l,r)の区間に対して、l,rを格納
    vector<vector<array<ll,2>>> segs;
    // [l,r)の区間に対して、l,rの長さの累積和を格納
    vector<vector<ll>> segs_length;

    segment_length(vector<vector<array<ll,2>>> segs):segs(segs){
        segs_length.resize(segs.size());
        rep(i,segs.size()){
            segs_length[i].resize(segs[i].size()+1);
            rep(j,segs[i].size()){
                segs_length[i][j+1] = segs_length[i][j] + segs[i][j][1] - segs[i][j][0];
            }
        }
    }

    // x,yの区間について、重なる区間の長さを返す O(|S(x)|log|S(y)|)
    ll get_length(ll x, ll y){
        if (segs[x].size() > segs[y].size()) swap(x,y);
        ll res = 0;
        rep(i,segs[x].size()){
            ll l = segs[x][i][0], r = segs[x][i][1];
            ll idx = lower_bound(segs[y].begin(),segs[y].end(),array<ll,2>{r,-1}) - segs[y].begin();
            if (idx == 0) continue;
            ll right = segs_length[y][idx] - max(segs[y][idx-1][1]-r,0ll);
            idx = lower_bound(segs[y].begin(),segs[y].end(),array<ll,2>{l,-1}) - segs[y].begin();
            if (idx == 0) {
                res += right;
                continue;
            }
            ll left = segs_length[y][idx] - max(segs[y][idx-1][1]-l,0ll);
            res += right - left;
        }
        return res;
    }
};