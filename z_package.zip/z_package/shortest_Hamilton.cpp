#include <bits/stdc++.h>

using namespace std;
using ll=long long;

ll shortest_Hamilton(vector<vector<ll>> &d){
    ll n = d.size();
    vector<vector<ll>> dp(1<<n,vector<ll>(n,1e18));
    dp[1][0] = 0;

    for (int i=0;i<(1<<n);i++){
        for (int j=0;j<n;j++){
            if (i & (1<<j)){
                for (int k=0;k<n;k++){
                    if (i & (1<<k)) continue;
                    dp[i|(1<<k)][k] = min(dp[i|(1<<k)][k],dp[i][j]+d[j][k]);
                }
            }
        }
    }

    return dp[(1<<n)-1][n-1];
}