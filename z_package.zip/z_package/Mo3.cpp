//https://atcoder.jp/contests/abc405/tasks/abc405_g

#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
#define seg_RmaRmsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{(a[0]+b[0])%998244353ll,a[1]+b[1]};},[&](){return array<ll,2>{0,0};},array<ll,2>,[&](array<ll,2> m, array<ll,2> n){ return array<ll,2>{(m[0]*n[0]+m[1]*n[1])%998244353ll,n[1]};}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0]%998244353ll, (b[1]*a[0]+a[1])%998244353ll};},[&](){return array<ll,2>{1ll,0ll};}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
template<typename T, typename F> T bs(T l, T r, F f) { for(int i=0;i<100;i++){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
template<typename T, typename F> T bs_fast(T l, T r, F f) { while(r-l>1){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}
ll stollmod(string S, ll mod) {ll ret = 0; rep(i,S.size()){ ret = (ret*10 + (S[i]-'0'))%mod; } return ret; }
// 
const int MAX = 260010;
const int MOD = 998244353;

long long FAC[MAX], FINV[MAX], INV[MAX];

// O(1)

// テーブルを作る前処理
void COMinit() {
    FAC[0] = FAC[1] = 1;
    FINV[0] = FINV[1] = 1;
    INV[1] = 1;
    for (int i = 2; i < MAX; i++){
        FAC[i] = FAC[i - 1] * i % MOD;
        INV[i] = MOD - INV[MOD%i] * (MOD / i) % MOD;
        FINV[i] = FINV[i - 1] * INV[i] % MOD;
    }
}

// 二項係数計算
long long COM(int n, int k){
    if (n < k) return 0;
    if (n < 0 || k < 0) return 0;
    return FAC[n] * (FINV[k] * FINV[n - k] % MOD) % MOD;
}

// 順列計算
long long PER(int n, int k){
    if (n < k) return 0;
    if (n < 0 || k < 0) return 0;
    return FAC[n] * FINV[n - k] % MOD;
}

template<class S, auto op, auto e>
struct HeihoBunkatsu{
        static_assert(std::is_convertible_v<decltype(op), std::function<S(S, S)>>,
                      "op must work as S(S, S)");
        static_assert(std::is_convertible_v<decltype(e), std::function<S()>>,
                      "e must work as S()");
    public:

        const int block_size = 500;

        S _A[MAX];
        S _D[MAX];
        int _n;
        int _size;
    
        HeihoBunkatsu(int n) : _n(n) {
            _size = n / block_size + 1;
            rep(i, n) _A[i] = e();
            rep(i, _size) _D[i] = e();
        }

        HeihoBunkatsu(const std::vector<S>& v) : _A(v), _n(int(v.size())) {
            _size = _n / block_size + 1;
            rep(i, _size) _D[i] = e();
            rep(i, _n) {
                _D[i / block_size] = op(_D[i / block_size], _A[i]);
            }
        }
    
        // change from here
        void set(int p, S x) {
            //assert(0 <= p && p < _n);
            S old = _A[p];
            S old_inv; 
            old_inv = S{-old[0], (int)FAC[old[0]]};
            
            _A[p] = x;
            int block = p / block_size;
            _D[block] = op(_D[block], op(old_inv, x));
        }

        S get(int p) const {
            //assert(0 <= p && p < _n);
            return _A[p];
        }

        void update(int l, int r) {
            assert(0 <= l && l <= r && r <= _n);
            int lblock = l / block_size;
            int rblock = r / block_size;
            if (lblock == rblock) {
                for (int i = l; i < r; i++) {
                    _A[i] = op(_D[lblock], get(i));
                }
            } else {
                for (int i = l; i < (lblock + 1) * block_size; i++) {
                    _A[i] = op(_D[i], get(i));
                }
                for (int i = lblock + 1; i < rblock; i++) {
                    _D[i] = op(_D[i], _D[i]);
                }
                for (int i = rblock * block_size; i < r; i++) {
                    _A[i] = op(_D[i], get(i));
                }
            }
        }

        // change to here

        S prod(int l, int r) const {
            //assert(0 <= l && l <= r && r <= _n);
            S res = e();
            int lblock = l / block_size;
            int rblock = r / block_size;
            if (lblock == rblock) {
                for (int i = l; i < r; i++) {
                    res = op(res, _A[i]);
                }
            } else {
                for (int i = l; i < (lblock + 1) * block_size; i++) {
                    res = op(res, _A[i]);
                }
                for (int i = lblock + 1; i < rblock; i++) {
                    res = op(res, _D[i]);
                }
                for (int i = rblock * block_size; i < r; i++) {
                    res = op(res, _A[i]);
                }
            }
            return res;
        }
};

//https://drken1215.hatenablog.com/entry/2019/01/01/234400

struct Mo {
    vector<int> left, right, index; // the interval's left, right, index
    vector<bool> v;
    int window;
    int nl, nr, ptr;

    Mo(int n) : window((int)sqrt(n)), nl(0), nr(0), ptr(0), v(n, false){
    }
    
    /* push */
    void push(int l, int r) { left.emplace_back(l), right.emplace_back(r); }
    
    /* sort intervals */
    void build() {
        index.resize(left.size());
        iota(index.begin(), index.end(), 0);
		sort(index.begin(), index.end(), [&](const int a, const int b){
            const int c = left[a] / window, d = left[b] / window;
            return (c == d) ? ((c & 1) ? (right[b] < right[a]) : (right[a] < right[b])) : (c < d);
        });
        
        
        // sort(index.begin(), index.end(), [&](int a, int b) {
        //     if (left[a] / window != right[b] / window) return left[a] < left[b];
        //     else return right[a] < right[b];
        // });
    }
    
    /* extend-shorten */
    void extend_shorten(int id) {
        v[id].flip();
        if (v[id]) insert(id);
        else erase(id);
    }
    
    /* next id of interval */
    int next() {
        if (ptr == index.size()) return -1;
        int id = index[ptr];
        while (nl > left[id]) extend_shorten(--nl);
        while (nr < right[id]) extend_shorten(nr++);
        while (nl < left[id]) extend_shorten(nl++);
        while (nr > right[id]) extend_shorten(--nr);
        return index[ptr++];
    }
    
    /* insert, erase (to be set appropriately) */
    void insert(int id);
    void erase(int id);
};

HeihoBunkatsu<array<int,2>, [](array<int,2> a, array<int,2> b){return array<int,2>{a[0]+b[0],(int)((ll)a[1]*b[1] >= MOD ? (ll)a[1]*b[1] %MOD : a[1]*b[1])};}, [](){return array<int,2>{0,1};}> HB(MAX);

int cnt[MAX]={};
int oriA[MAX]={};

void Mo::insert(int id) {
    int val = oriA[id];
    ++cnt[val];
    HB.set(val, array<int,2>{cnt[val], (int)FINV[cnt[val]]});
}

void Mo::erase(int id) {
    int val = oriA[id];
    --cnt[val];
    HB.set(val, array<int,2>{cnt[val], (int)FINV[cnt[val]]});
}

int main() {

    ios::sync_with_stdio(false);
    cin.tie(0);

    cin2(N,Q); cinvec(A);
    rep(i,N) oriA[i] = A[i];

    vector<int> L(Q), R(Q), X(Q);
    rep(i,Q) cin >> L[i] >> R[i] >> X[i];

    COMinit();

    Mo mo(N);

    for(int i = 0; i < Q; i++) {
        mo.push(L[i]-1, R[i]);
    }
    mo.build();
    //exit(0);

    vector<ll> res(Q);
    for (int i = 0; i < Q; i++){
        int idx = mo.next();
        array<int,2> tmp = HB.prod(0, X[idx]);
        res[idx] = (FAC[tmp[0]]*tmp[1] >= MOD ? (FAC[tmp[0]]*tmp[1] %MOD) : FAC[tmp[0]]*tmp[1]);
    }

    string ans = "";
    rep(i,Q) ans += to_string(res[i]) + "\n";
    cout << ans;

    return 0;
} 
