#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
#include <atcoder/all>

using std::cout; using namespace std; using ll=long long; using ld=long double; using mint = atcoder::modint998244353;
#define rep(i,n) for (int i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (int i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (int i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }

struct RangeaddRangeaboveK{
    vector<ll> A;
    vector<vector<ll>> dat;
    vector<array<ll,2>> lazy;
    ll N; ll siz; ll length;
    RangeaddRangeaboveK(vector<ll> &v){
        A = v;
        N = A.size();
        siz = sqrtl(N)+1;
        int index = 0;
        length = (N/siz)+1;
        dat.resize(length);
        lazy.resize(length);
        lazy[0] = {0,0};
        for (int i=0;i<N;i++){
            dat[index].push_back(A[i]);
            if (i%siz == siz-1) {
                index++;
                lazy[index] = {i+1,0};
            }
        }

        if (lazy.back()[0] != N) lazy.push_back({N,0});

        for (int i=0;i<length;i++){
            sort(dat[i].begin(),dat[i].end());
            outvec(dat[i]);
        }

        outvecp(lazy);
    }

    void add(ll l, ll r, ll x){
        assert(0 <= l && l < r && r < N);
        ll lindex = l/siz;
        ll rindex = r/siz;
        if (lindex == rindex){
            for (int i=l;i<=r;i++){
                A[i] += x;
            }
            dat[lindex].clear();
            for (int i=lindex*siz;i<min(N,(lindex+1)*siz);i++){
                dat[lindex].push_back(A[i]);
            }
            sort(dat[lindex].begin(),dat[lindex].end());
            return;
        }
        for (int i=lindex+1;i<rindex;i++){
            lazy[i][1] += x;
        }

        for (int i=l;i<(lindex+1)*siz;i++){
            A[i] += x;
        }

        dat[lindex].clear();
        for (int i=lindex*siz;i<(lindex+1)*siz;i++){
            dat[lindex].push_back(A[i]);
        }
        sort(dat[lindex].begin(),dat[lindex].end());

        for (int i=rindex*siz;i<=r;i++){
            A[i] += x;
        }

        dat[rindex].clear();
        for (int i=rindex*siz;i<min(N,(rindex+1)*siz);i++){
            dat[rindex].push_back(A[i]);
        }
        sort(dat[rindex].begin(),dat[rindex].end());

        return;
    }

    int aboveK(ll l, ll r, ll x){
        assert(0 <= l && l < r && r < N);
        ll lindex = l/siz;
        ll rindex = r/siz;
        int res = 0;
        if (lindex == rindex){
            for (int i=l;i<=r;i++){
                if (A[i]+lazy[lindex][1] >= x) res++;
            }
            return res;
        }
        for (int i=lindex+1;i<rindex;i++){
            res += lazy[i+1][0]-lazy[i][0]-(lower_bound(dat[i].begin(),dat[i].end(),x-lazy[i][1])-dat[i].begin());
        }
        for (int i=l;i<(lindex+1)*siz;i++){
            if (A[i] + lazy[lindex][1] >= x) res++;
        }
        for (int i=rindex*siz;i<=r;i++){
            if (A[i] + lazy[rindex][1] >= x) res++;
        }
        return res;
    }
};



int main2() {
    cin(N); cinvec(A);
    RangeaddRangeaboveK R(A);
    R.add(0,7,1);
    outvec(R.A);
    rep(i,R.length){
        outvec(R.dat[i]);
    }

    cout << R.aboveK(0,7,5) << endl;
    
    return 0;
} 