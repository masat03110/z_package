#include<bits/stdc++.h>
using namespace std;
template<typename S, S (*op)(S,S), S (*e)()>
struct segtree_2d
{
    segtree_2d():segtree_2d(0,0){}
    segtree_2d(int h_, int w_):segtree_2d(vector<vector<S>>(h_,vector<S>(w_,e()))){}
    segtree_2d(vector<vector<S>>v):h(v.size()),w(v[0].size())
    {
        logh=0,logw=0;
        while((1<<logh)<h)logh++;
        while((1<<logw)<w)logw++;
        szh=1<<logh,szw=1<<logw;
        node.resize(4*szh*szw,e());
        for(int i=0;i<h;i++)for(int j=0;j<w;j++)node[idx(i+szh,j+szw)]=v[i][j];
        for(int j=szw;j<2*szw;j++)for(int i=szh-1;i>=1;i--)update_w(i,j);
        for(int i=0;i<2*szh;i++)for(int j=szw-1;j>=1;j--)update_h(i,j);
    }
    void set(int p, int q, S x)
    {
        assert(0<=p&&p<h);
        assert(0<=q&&q<w);
        p+=szh,q+=szw;
        node[idx(p,q)]=x;
        int i=p,j=q;
        for(int j=1;j<=logw;j++)update_h(p,q>>j);
        for(int i=1;i<=logh;i++)
        {
            update_w(p>>i,q);
            for(int j=1;j<=logw;j++)update_h(p>>i,q>>j);
        }
    }
    S get(int p, int q)
    {
        assert(0<=p&&p<h);
        assert(0<=q&&q<w);
        p+=szh,q+=szw;
        return node[idx(p,q)];
    }
    S prod(int d, int l, int u, int r)
    {
        assert(0<=d&&d<=u&&u<=h);
        assert(0<=l&&l<=r&&r<=w);
        d+=szh,u+=szh;
        l+=szw,r+=szw;
        S pd=e(),pu=e();
        while(d<u)
        {
            if(d&1)pd=op(pd,inner_prod(d++,l,r));
            if(u&1)pu=op(inner_prod(--u,l,r),pu);
            d>>=1,u>>=1;
        }
        return op(pd,pu);
    }
    S all_prod(){return node[idx(1,1)];}
private:
    int h,w,logh,logw,szh,szw;
    vector<S>node;
    int idx(int p, int q){return 2*p*szw+q;}
    void update_h(int p, int q){node[idx(p,q)]=op(node[idx(p,2*q)],node[idx(p,2*q+1)]);}
    void update_w(int p, int q){node[idx(p,q)]=op(node[idx(2*p,q)],node[idx(2*p+1,q)]);}
    S inner_prod(int p, int l, int r)
    {
        S pl=e(),pr=e();
        while(l<r)
        {
            if(l&1)pl=op(pl,node[idx(p,l++)]);
            if(r&1)pr=op(node[idx(p,--r)],pr);
            l>>=1,r>>=1;
        }
        return op(pl,pr);
    }
};
pair<int,int> op(pair<int,int> a, pair<int,int> b){return make_pair(a.first+b.first,a.second+b.second);}
pair<int,int> e(){return make_pair(0,0);}
int main2()
{
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int H,W,T,Q;
    cin>>H>>W>>T>>Q;
    segtree_2d<pair<int,int>,op,e>seg(H,W);
    priority_queue<pair<int,pair<int,int>>,vector<pair<int,pair<int,int>>>,greater<pair<int,pair<int,int>>>>q;
    while(Q--)
    {
        int t,c;
        cin>>t>>c;
        while(!q.empty()&&q.top().first<=t)
        {
            auto[h,w]=q.top().second;
            q.pop();
            auto[ok,ng]=seg.get(h,w);
            assert(ng>0);
            seg.set(h,w,make_pair(ok+1,ng-1));
        }
        if(c==0)
        {
            int h,w;
            cin>>h>>w;
            h--,w--;
            q.push(make_pair(t+T,make_pair(h,w)));
            auto[ok,ng]=seg.get(h,w);
            seg.set(h,w,make_pair(ok,ng+1));
        }
        else if(c==1)
        {
            int h,w;
            cin>>h>>w;
            h--,w--;
            auto[ok,ng]=seg.get(h,w);
            if(ok>0)ok--;
            seg.set(h,w,make_pair(ok,ng));
        }
        else
        {
            int h1,w1,h2,w2;
            cin>>h1>>w1>>h2>>w2;
            h1--,w1--;
            auto[ok,ng]=seg.prod(h1,w1,h2,w2);
            cout<<ok<<' '<<ng<<'\n';
        }
    }
}
