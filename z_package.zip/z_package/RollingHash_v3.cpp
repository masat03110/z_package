#include <bits/stdc++.h>
using namespace std;
using ll=long long;

#define check 3
using Hash = array<ll, check>;
array<ll,check> bases = {10LL, 10LL, 10LL};
const array<ll,check> mods = {999999937LL, 1000000007LL, 1000000009LL};
vector<vector<ll>> pows;
Hash operator* (const Hash &a, const Hash &b) {Hash res; for (int i=0;i<check;i++) res[i] = a[i] * b[i] % mods[i]; return res;}
struct RollingHash {
    vector<vector<ll>> hash;
    void init(int N){
        pows.resize(check,vector<ll> (N + 1,1));
        hash.resize(check,vector<ll> (N + 1,1));
        for (int i = 0; i < N; i++) {
            for (int j=0;j<check;j++){
                pows[j][i + 1] = pows[j][i] * bases[j] % mods[j];
            }
        }
    }
    void make(const string &s){
        hash.resize(check,vector<ll> (s.size() + 1,1));
        for (int i = 0; i < s.size(); i++) {
            for (int j=0;j<check;j++){
                hash[j][i + 1] = (hash[j][i] * bases[j] + (s[i]-'0')) % mods[j];
                pows[j][i + 1] = pows[j][i] * bases[j] % mods[j];
            }
        }
    }
    // [l, r)
    Hash get(int l, int r) {
        Hash res;
        for (int i=0;i<check;i++){
            res[i] = hash[i][r] + mods[i] - hash[i][l] * pows[i][r - l] % mods[i];
            if (res[i] >= mods[i]) res[i] -= mods[i];
        }
        return res;
    }

    Hash concat(Hash h1, Hash h2, int h2_len) {
        Hash res;
        for (int i=0;i<check;i++){
            res[i] = (h1[i] * pows[i][h2_len] + h2[i]) % mods[i];
        }
        return res;
    }
};