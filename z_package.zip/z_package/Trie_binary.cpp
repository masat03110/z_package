#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
string to_binary(ll x) { string res; while (x) { res += (x % 2) + '0';x /= 2;}reverse(res.begin(), res.end());return res;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}


// 変えるべきは、Nodeとinsertの部分
// 求めたいスコアは新しく関数として書いたほうが良さそう

struct Node{
    array<ll,2> to;
    ll parent=-1;
    ll cnt=0;
    ll leaf_cnt=0;
    ll depth=0;
    ll min_leaf_dist=1e18;
    ll value=0;
    Node() {fill(to.begin(),to.end(),-1);}
};

struct Trie_binary{
    vector<Node> nodes;
    Trie_binary(){nodes.push_back(Node());}

    void insert(const string &s, ll value=0){
        ll v = 0;
        ll i = 0;
        for (char c : s){
            i++;
            ll i = c - '0';
            if (nodes[v].to[i] == -1){
                nodes[v].to[i] = nodes.size();
                nodes.push_back(Node());
                nodes.back().parent = v;
                nodes.back().depth = nodes[v].depth + 1;
            }
            v = nodes[v].to[i];
            nodes[v].cnt++;
        }
        nodes[v].leaf_cnt++;

        ll u = v;
        while (u != 0){
            chmin(nodes[u].min_leaf_dist,nodes[v].depth);
            nodes[u].value += value >> (i-1);
            i--;
            u = nodes[u].parent;
        }
        chmin(nodes[0].min_leaf_dist,nodes[v].depth);
        nodes[0].value += value;
    }

    Node find(const string &s){
        ll v = 0;
        for (char c : s){
            ll i = c - '0';
            if (nodes[v].to[i] == -1){
                return Node(); // 存在しない
            }
            v = nodes[v].to[i];
        }
        return nodes[v];
    }

    // 編集距離の最小値を求める
    ll score(const string &s){
        ll res = 1e18;
        ll v = 0;
        res = min(res,nodes[v].min_leaf_dist-2*nodes[v].depth+(ll)s.size());
        for (char c : s){
            ll i = c - '0';
            if (nodes[v].to[i] == -1){
                break;
            }
            v = nodes[v].to[i];
            res = min(res,nodes[v].min_leaf_dist-2*nodes[v].depth+(ll)s.size());
        }
        return res;
    }

    // 足したときに、2で割りまくった時のスコアの合計値を求める
    ll score2(const string &s, ll value=0){
        ll res = 0;
        ll v = 0;
        //res += nodes[v].value;
        rep(k,30){
            ll i = value%2;
            ll other = 1-i;

            if (nodes[v].to[other] != -1){
                res += (nodes[nodes[v].to[other]].value)+nodes[nodes[v].to[other]].cnt*(value);
            }

            if (nodes[v].to[i] == -1){
                break;
            }
            v = nodes[v].to[i];
            value /= 2;
            if (i) value++;
        }
        return res;
    }
};