//https://atcoder.jp/contests/code-thanks-festival-2017/submissions/2298433

#include <algorithm>
#include <cassert>
#include <cstdint>
#include <limits>
#include <utility>
#include <vector>


class PartiallyPersistentUnionFind {
public:
  using size_type = std::uint_fast32_t;

private:
  std::vector<std::pair<size_type, size_type>> tree;
  std::vector<std::vector<std::pair<size_type, size_type>>> siz;
  size_type global_count;

public:
  PartiallyPersistentUnionFind(const size_type size)
      : tree(size, std::make_pair(1, std::numeric_limits<size_type>::max())),
        siz(size, std::vector<std::pair<size_type, size_type>>(
                      1, std::make_pair(0, 1))),
        global_count(0) {}
  size_type find(const size_type ver, size_type x) const {
    assert(x < size());
    while (tree[x].second <= ver)
      x = tree[x].first;
    return x;
  }
  bool unite(size_type x, size_type y) {
    assert(x < size());
    assert(y < size());
    ++global_count;
    x = find(global_count, x);
    y = find(global_count, y);
    if (x == y)
      return false;
    if (tree[x].first < tree[y].first)
      std::swap(x, y);
    tree[x].first += tree[y].first;
    siz[x].emplace_back(global_count, tree[x].first);
    tree[y] = std::make_pair(x, global_count);
    return true;
  }
  bool same(const size_type ver, const size_type x, const size_type y) const {
    assert(x < size());
    assert(y < size());
    return find(ver, x) == find(ver, y);
  }
  size_type size(const size_type ver, size_type x) const {
    assert(x < size());
    x = find(ver, x);
    return (std::lower_bound(
                siz[x].begin(), siz[x].end(),
                std::make_pair(ver + 1, static_cast<size_type>(0))) -
            1)
        ->second;
  }
  size_type count() const noexcept { return global_count; }
  size_type size() const noexcept { return tree.size(); }
  bool empty() const noexcept { return tree.empty(); }
};
 
#include<iostream>
int main2(void) {
	int n, m;
	std::cin >> n >> m;
	PartiallyPersistentUnionFind T(n);
	for (int i = 0;i < m;++i) {
		int a, b;
		std::cin >> a >> b;
		--a;--b;
		T.unite(a, b);
	}
	int q;
	std::cin >> q;
	while (q--) {
		int x, y;
		std::cin >> x >> y;
		--x;--y;
		int low = 0, high = m + 1;
		while (high - low > 1) {
			int mid = (low + high) / 2;
			if (T.same(mid, x, y)) high = mid;
			else low = mid;
		}
		std::cout << (high == m + 1 ? -1 : high) << std::endl;
	}
	return 0;
}