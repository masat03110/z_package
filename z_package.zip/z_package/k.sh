#!/bin/bash
#!/usr/bin/expect -f

set -e

if [ $# -lt 1 ]; then
    echo "Usage: $0 <file> <number> <op>"
    exit 1
fi

if [ $# -gt 4 ]; then
    echo "Usage: $0 <file> <number> <op> <times>"
    exit 1
fi

file="$1"
number="$2"
contest="${1:0:3}"
cpp_file="main.cpp"
output_file="a.out"
command="submit"
back="../.."
JSON_FILE="contest.acc.json"


if [ $# -eq 1 ]; then
    acc new "$file"
    cd "$file"

    for dir in $(ls -d */); do
        cd "$dir"
        cat <<EOF > r.py
import random

N = random.randint(3, 10)
print(N)

X = [random.randint(1, 10) for _ in range(N)]
print(*X)
EOF
        cp main.cpp main2.cpp
        cd ..
    done
fi

if [ $# -eq 2 ]; then
    cd "$file/$number"
    echo "Compiling..."
    g++ -march=native -std=c++20 -fsanitize=undefined -D_GLIBCXX_DEBUG "$cpp_file" -I /home/tsuka79/tsuka/Kyopro/atcoder/ac-library/
    oj t -d ./test/
    # if [ "$contest" == "abc" ]; then
        # spawn 
    # acc "$command" "$cpp_file" -- --no-open
        # expect "Are you sure? Please type"
        # send "$contest$number\n"
        # expect eof
    # fi
    #acss watch "$file" -t 3
    cd "$back"

    json_path="$file/$JSON_FILE"
    URL=$(jq -r --arg path "$number" '.tasks[] | select(.directory.path == $path) | .url' "$json_path")

    wslview "$URL"

fi

if [ $# -eq 4 ]; then
    cd "$file/$number"
    if [ "$3" != "1" ]; then
        cpp_file="main$3.cpp"
    fi
    echo "interactive input:"
    g++ -march=native -std=c++20 -fsanitize=undefined -D_GLIBCXX_DEBUG "$cpp_file" -I /home/tsuka79/tsuka/Kyopro/atcoder/ac-library/
    times=1
    while [ $times -le $4 ]; do
        if [ "$times" != "1" ]; then
            echo "input:"
        fi
        ./a.out
        times=$((times+1))
    done
    cd "$back"
fi

if [ $# -eq 3 ]; then
    cd "$file/$number"
    echo "test"
    echo -e "input:"

    if [ "$3" != "1" ]; then
        cpp_file="main$3.cpp"
    fi

    g++ -march=native -std=c++20 -fsanitize=undefined "$cpp_file" -D_GLIBCXX_DEBUG -O3 -I /home/tsuka79/tsuka/Kyopro/atcoder/ac-library/
    read line
    if [ "$line" != "" ]; then
        echo "$line" > input.txt
        while [ "$line" != "" ]; do
            read line
            echo "$line" >> input.txt
        done
    else
        cat input.txt
    fi
    echo -e "output:\n"
    time {
        ./a.out < input.txt > output.txt 
        cat output.txt
    }
    cd "$back"
fi

# if [ $# -eq 4 ]; then
#     count=2
#     cd "$file/$number"
#     echo "test"
#     echo -e "input:"
#     g++ -std=c++20 -D_GLIBCXX_DEBUG "main$4.cpp" -O3 -I /home/tsuka79/tsuka/Kyopro/atcoder/ac-library/
#     read line
#     if [ "$line" != "" ]; then
#         echo "$line" > input.txt
#         while [ "$line" != "" ]; do
#             read line
#             echo "$line" >> input.txt
#         done
#     else
#         cat input.txt
#     fi
#     echo -e "output:\n"
#     time {
#         ./a.out < input.txt > output.txt 
#         cat output.txt
#     }
#     while [ $count -le $3 ]
#     do
#         echo -e "\ninput:"
#         read line
#         echo "$line" > input.txt
#         echo -e "output:\n"
#         time ./a.out < input.txt
#         count=$((count+1))
#     done
#     cd "$back"
# fi

# if [ $? -eq 0 ]; then
#     echo "Compilation successful: $output_file"
# else
#     echo "Compilation failed"
# fi
