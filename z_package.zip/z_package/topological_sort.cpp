#include <iostream>
#include <vector>
#include <queue> // std::priority_queue
#include <functional> // std::greater
#include <array>

using ll = long long;
using namespace std;

/// @brief トポロジカルソート
/// @param graph グラフ
/// @return トポロジカルソートの結果で辞書順最小のもの。グラフが閉路を含む場合は空の配列
/// @note 1.3 トポロジカルソートの結果で辞書順最小のもの
/// @see https://zenn.dev/reputeless/books/standard-cpp-for-competitive-programming/viewer/topological-sort

// O(|V|+|E|)
std::vector<ll> TopologicalSort(const std::vector<std::vector<ll>>& graph)
{
	std::vector<ll> indegrees(graph.size());

	for (const auto& v : graph)
	{
		for (const auto& to : v)
		{
			++indegrees[to];
		}
	}

	std::priority_queue<ll, std::vector<ll>, std::greater<ll>> pq;

	for (ll i = 0; i < (ll)graph.size(); ++i)
	{
		if (indegrees[i] == 0)
		{
			pq.push(i);
		}
	}

	std::vector<ll> result;

	while (!pq.empty())
	{
		const ll from = pq.top(); pq.pop();

		result.push_back(from);

		for (const auto& to : graph[from])
		{
			if (--indegrees[to] == 0)
			{
				pq.push(to);
			}
		}
	}

	if (result.size() != graph.size())
	{
		return{};
	}

	return result;
}

// O(|V|+|E|)
std::vector<int> TopologicalSort2(const std::vector<std::vector<array<int,2>>>& graph)
{
	std::vector<int> indegrees(graph.size());

	for (const auto& v : graph)
	{
		for (const auto [to,_] : v)
		{
			++indegrees[to];
		}
	}

	std::priority_queue<int, std::vector<int>, std::greater<int>> pq;

	for (int i = 0; i < (int)graph.size(); ++i)
	{
		if (indegrees[i] == 0)
		{
			pq.push(i);
		}
	}

	std::vector<int> result;

	while (!pq.empty())
	{
		const int from = pq.top(); pq.pop();

		result.push_back(from);

		for (const auto [to,_] : graph[from])
		{
			if (--indegrees[to] == 0)
			{
				pq.push(to);
			}
		}
	}

	if (result.size() != graph.size())
	{
		return{};
	}

	return result;
};

int main2()
{
	ll V, E;
	std::cin >> V >> E;

	std::vector<std::vector<ll>> graph(V);

	for (ll i = 0; i < E; ++i)
	{
		//ll s, t;
		//std::cin >> s >> t;
		//graph[s].push_back(t);
	}

	const std::vector<ll> result = TopologicalSort(graph);

	for (const auto& v : result)
	{
		std::cout << v << '\n';
	}
}