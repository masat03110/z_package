#include <bits/stdc++.h>

using namespace std;

using ll=long long;
using ld=long double;
#define rep(i,n) for (ll i=0;i<(n);i++)
#define rep2(i,a,b) for (ll i=(a);i<(b);i++)
#define repd(i,a,b) for (ll i=(a);i>=(b);i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}

int main2() {
    cins(K);cin(D);
    vector<vector<ll>> dp1(K.size()+1,vector<ll>(D,0)), dp2(K.size()+1,vector<ll>(D,0)), dp3(K.size()+1,vector<ll>(D,0));
    rep2(i,1,10){
        if (i > K[0]-'0') dp1[1][i%D]++;
        else if (i == K[0]-'0') dp2[1][i%D]++;
        else dp3[1][i%D]++;
    }
    rep2(i,2,K.size()+1){
        rep2(j,0,D){
            rep2(k,0,10){
                if (k > K[i-1]-'0') {
                    dp1[i][(j+k)%D] += dp1[i-1][j];
                    dp1[i][(j+k)%D] %= 1000000007;
                    dp1[i][(j+k)%D] += dp2[i-1][j];
                    dp1[i][(j+k)%D] %= 1000000007;
                    dp3[i][(j+k)%D] += dp3[i-1][j];
                    dp3[i][(j+k)%D] %= 1000000007;
                }else if (k == K[i-1]-'0'){
                    dp1[i][(j+k)%D] += dp1[i-1][j];
                    dp1[i][(j+k)%D] %= 1000000007;
                    dp2[i][(j+k)%D] += dp2[i-1][j];
                    dp2[i][(j+k)%D] %= 1000000007;
                    dp3[i][(j+k)%D] += dp3[i-1][j];
                    dp3[i][(j+k)%D] %= 1000000007;
                }else{
                    dp1[i][(j+k)%D] += dp1[i-1][j];
                    dp1[i][(j+k)%D] %= 1000000007;
                    dp3[i][(j+k)%D] += dp2[i-1][j];
                    dp3[i][(j+k)%D] %= 1000000007;
                    dp3[i][(j+k)%D] += dp3[i-1][j];
                    dp3[i][(j+k)%D] %= 1000000007;
                }
            }
        }
    }

    ll ans = 0;
    rep2(i,1,K.size()+1){
        ans += dp2[i][0];
        ans %= 1000000007;
        ans += dp3[i][0];
        ans %= 1000000007;
    }
    rep2(i,1,K.size()){
        ans += dp1[i][0];
        ans %= 1000000007;
    }

    cout << ans << endl;
    
    return 0;
} 