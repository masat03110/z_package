#include <bits/stdc++.h>

using namespace std;

using ll=long long;
using ld=long double;
#define rep(i,n) for (ll i=0;i<(n);i++)
#define rep2(i,a,b) for (ll i=(a);i<(b);i++)
#define repd(i,a,b) for (ll i=(a);i>=(b);i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}

#include <bits/stdc++.h>

using namespace std;
using ll=long long;

ll mod = 998244353;
struct mono{
    ll val=0;

    mono operator+(const mono& another) const {
        return mono{(val+another.val)%mod};
    }
};

mono func(mono a, mono b){
    return a+b;
}

struct mono_lazy{
    ll mul=1;
    ll add=0;

    mono_lazy operator+(const mono_lazy& another) const {
        return mono_lazy{(mul*another.mul)%mod,(add*another.mul+another.add)%mod};
    }
};

mono upd(mono a, mono_lazy b, ll l, ll r){
    return mono{(a.val*b.mul+b.add*(r-l))%mod};
}

struct LazySegmentTree{
    public:
        int n; 
        vector<mono> node;
        vector<mono_lazy> lazy;
        LazySegmentTree(vector<mono> v){
            int sz = v.size();
            n = 1; while(n < sz) n *= 2;
            node.resize(2*n-1,mono());
            lazy.resize(2*n-1,mono_lazy());
        
            for (int i=0;i<sz;i++){
            node[i+n-1] = v[i];
            }
            for (int i=n-2;i>=0;i--) node[i] = func(node[i*2+1],node[i*2+2]);
        }
        
        void eval(int k, int l, int r){
            node[k] = upd(node[k],lazy[k],l,r);
            if (r - l > 1){
                lazy[2*k+1] = lazy[2*k+1] + lazy[k];
                lazy[2*k+2] = lazy[2*k+2] + lazy[k];
            }
            lazy[k] = mono_lazy();
        }
        
        void update(int a, int b, mono_lazy x, int k=0, int l=0, int r=-1){
            eval(k,l,r);
            if (r < 0) r = n;
            if (r <= a || b <= l) return;
            if (a <= l && r <= b){
                lazy[k] = lazy[k]+x; // maybe you don't need to change this
                eval(k,l,r);
            } else {
                update(a,b,x,2*k+1,l,(l+r)/2);
                update(a,b,x,2*k+2,(l+r)/2,r);
                node[k] = func(node[2*k+1],node[2*k+2]);
            }
        }

        mono get(int a, int b, int k=0, int l=0, int r=-1){
            eval(k,l,r);
            if (r < 0) r = n;
            if (r <= a || b <= l) return mono();
            if (a <= l && r <= b) return node[k];
            mono vl = get(a,b,2*k+1,l,(l+r)/2);
            mono vr = get(a,b,2*k+2,(l+r)/2,r);
            return func(vl,vr);
        }
};
