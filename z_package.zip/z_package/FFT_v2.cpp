#include <bits/stdc++.h>

using namespace std;
using ll=long long;

#define SZ(x) ((ll)(x).size())

namespace FIO {
	const ll D = 1 << 23;
	char in[D], *I = in + D, out[D], *O = out;
	char rdc() { return (I == in + D ? fread(I = in, 1, D, stdin) : 0), *I++; }
	template<typename T> void read(T &x) {
		char c = rdc(), fl = 0;
		while(c < '0' || c > '9') fl |= (c == '-'), c = rdc();
		for(x = 0; '0' <= c && c <= '9'; c = rdc()) x = x * 10 + (c - '0');
		if(fl) x = -x;
	}
	void wrtc(char c) { (O == out + D ? fwrite(O = out, 1, D, stdout) : 0), *O++ = c; }
	template<typename T> void write(T x, char ch = 0) {
		static char c[60]; ll top = 0;
		if(x < 0) wrtc('-'), x = -x;
		do c[++top] = x % 10, x /= 10; while(x);
		while(top) wrtc(c[top--] + '0');
		if(ch) wrtc(ch);
	}
	void flush() { fwrite(out, 1, O - out, stdout); }
	struct Flusher { ~Flusher() { flush(); } } flusher;
}
using FIO::write;
using FIO::read;

typedef long long LL;

ll N_max = 1e5+10;

template<ll MOD, ll G>
class Polynomial {
	std::vector<ll> a;
	static ll lg2(ll x) { return 31 ^ __builtin_clz(x); }
	static ll modadd(const ll &x) { return x + ((x >> 31) & MOD); }
	static ll modsub(const ll &x) { return x >= MOD ? x - MOD : x; }
	static ll qpow(ll x, ll y) { ll ret = 1; while(true) { if(y & 1) ret = (LL)ret * x % MOD; if(!(y >>= 1)) return ret; x = (LL)x * x % MOD; } }
	static ll inv(ll x) { return qpow(x, MOD - 2); }
	static std::vector<ll> &get_power_G(ll len) {
		static std::vector<ll> vct{1};
		static ll last = 0;
		if(SZ(vct) < len) {
			len = lg2(len);
			ll k = last;
			vct.resize(1 << len);
			vct[1 << (len - 1)] = qpow(G, (MOD - 1) >> (len + 1));
			for(ll i = len - 1; i > k; i--) vct[1 << (i - 1)] = (LL)vct[1 << i] * vct[1 << i] % MOD;
			for(ll lim = (1 << k); k < len; k++, lim <<= 1)
				for(ll i = lim + 1; i < (lim << 1); i++)
					vct[i] = (LL)vct[i - lim] * vct[lim] % MOD;
			last = len;
		}
		return vct;
	}
	static void DIF(std::vector<ll> &arr) {
		auto &power = get_power_G(arr.size() >> 1);
		ll lim = SZ(arr);
		for(ll i = (lim >> 1); i >= 1; i >>= 1) {
			for(ll k = 0; k < i; k++) {
				LL x = arr[k], y = arr[i + k];
				arr[k] = modsub(x + y);
				arr[i + k] = modadd(x - y);
			}
			for(ll j = (i << 1), t = 1; j < lim; j += (i << 1), t++)
				for(ll k = 0; k < i; k++) {
					LL x = arr[j + k], y = (LL)arr[j + i + k] * power[t] % MOD;
					arr[j + k] = modsub(x + y);
					arr[j + i + k] = modadd(x - y);
				}
		}
	}
	static void DIT(std::vector<ll> &arr) {
		auto &power = get_power_G(arr.size() >> 1);
		ll lim = SZ(arr);
		for(ll i = 1; i < lim; i <<= 1) {
			for(ll k = 0; k < i; k++) {
				LL x = arr[k], y = arr[i + k];
				arr[k] = modsub(x + y);
				arr[i + k] = modadd(x - y);
			}
			for(ll j = (i << 1), t = 1; j < lim; j += (i << 1), t++)
				for(ll k = 0; k < i; k++) {
					LL x = arr[j + k], y = arr[j + i + k];
					arr[j + k] = modsub(x + y);
					arr[j + i + k] = (LL)(x - y + MOD) * power[t] % MOD;
				}
		}
		LL invlim = qpow(lim, MOD - 2);
		for(ll i = 0; i < lim; i++) arr[i] = (LL)arr[i] * invlim % MOD;
		std::reverse(arr.begin() + 1, arr.end());
	}
	Polynomial inv() const {
		Polynomial ret({inv(a[0])});
		ll l = SZ(a);
		if(l & (l - 1)) l = 1 << (lg2(l) + 1);
		for(ll i = 2; i <= l; i <<= 1) {
			Polynomial tmp = split(0, i);
			tmp.a.resize(i << 1), ret.a.resize(i << 1);
			DIF(tmp.a), DIF(ret.a);
			for(ll j = 0; j < (i << 1); j++) ret.a[j] = (LL)ret.a[j] * (2 - (LL)tmp.a[j] * ret.a[j] % MOD + MOD) % MOD;
			DIT(ret.a), ret.a.resize(i);
		}
		ret.a.resize(SZ(a));
		return ret;
	}
public:
	Polynomial() : a({0}) {}
	explicit Polynomial(const std::vector<ll> &rhs) : a(rhs) {
		if(a.empty()) a.emplace_back();
	}
	explicit Polynomial(std::vector<ll> &&rhs) : a(rhs) {
		if(a.empty()) a.emplace_back();
	}
	explicit operator std::vector<ll>() const { return a; }
	std::vector<ll> &data() { return a; }
	const std::vector<ll> &data() const { return a; }
	void negative() { for(ll i = 0; i < SZ(a); i++) a[i] = MOD - a[i]; }
	Polynomial operator+() const { return *this; }
	Polynomial operator-() const { auto tmp = *this; tmp.negative(); return tmp; }
	Polynomial &operator+=(const Polynomial &rhs) {
		a.resize(std::max(SZ(a), SZ(rhs.a)));
		for(ll i = 0; i < SZ(a); i++) a[i] = modsub(a[i] + rhs.a[i]);
		return a;
	}
	Polynomial &operator-=(const Polynomial &rhs) {
		a.resize(std::max(SZ(a), SZ(rhs.a)));
		for(ll i = 0; i < SZ(a); i++) a[i] = modadd(a[i] - rhs.a[i]);
		return a;
	}
	Polynomial &operator*=(const Polynomial &rhs) {
		if(std::min(SZ(a), SZ(rhs.a)) <= 8) {
			std::vector<ll> ret(SZ(a) + SZ(rhs.a) - 1);
			for(ll i = 0; i < SZ(a); i++)
				for(ll j = 0; j < SZ(rhs.a); j++) {
					ret[i + j] += (LL)a[i] * rhs.a[j] % MOD;
					if(ret[i + j] >= MOD) ret[i + j] -= MOD;
				}
			return *this = Polynomial(std::move(ret));
		}
		ll l = (SZ(a) + SZ(rhs.a) - 1);
		if(l & (l - 1)) l = 1 << (lg2(l) + 1);
		a.resize(l), DIF(a);
		if(&rhs != this) {
			Polynomial rhs_ = rhs;
			rhs_.a.resize(l), DIF(rhs_.a);
			for(ll i = 0; i < l; i++) a[i] = (LL)a[i] * rhs_.a[i] % MOD;
		} else for(ll i = 0; i < l; i++) a[i] = (LL)a[i] * a[i] % MOD;
		DIT(a);
        while(!a.empty() && a.back() == 0) a.pop_back();
		if(a.empty()) a.emplace_back();
		return *this;
	}
	Polynomial split(ll start, ll end = -1) const {
		Polynomial ret;
		if(end == -1) end = a.size();
		ret.a.resize(end - start);
		for(ll i = start; i < SZ(a) && i < end; i++) ret.a[i - start] = a[i];
		return ret;
	}
	ll degree() const { return SZ(a) - 1; }
	ll &operator[](const ll &x) { return a[x]; }
	const ll &operator[](const ll &x) const { return a[x]; }
	friend Polynomial inv(const Polynomial &x) { return x.inv(); }
};
template<ll MOD, ll G> Polynomial<MOD, G> operator+(const Polynomial<MOD, G> &x, const Polynomial<MOD, G> &y) { return Polynomial<MOD, G>(x) += y; }
template<ll MOD, ll G> Polynomial<MOD, G> operator-(const Polynomial<MOD, G> &x, const Polynomial<MOD, G> &y) { return Polynomial<MOD, G>(x) -= y; }
template<ll MOD, ll G> Polynomial<MOD, G> operator*(const Polynomial<MOD, G> &x, const Polynomial<MOD, G> &y) { return Polynomial<MOD, G>(x) *= y; }


const ll MOD = 998244353;
const ll G = 3;
using poly = Polynomial<MOD, G>;