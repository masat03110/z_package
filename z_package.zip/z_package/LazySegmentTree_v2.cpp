#include <bits/stdc++.h>
using namespace std;
using ll=long long;

// O(logN)

//change mono and func and eval
//note that the lazy propagation must be commutative here
struct mono{
    ll val=0;
};

mono func(mono a, mono b){
    return mono{max(a.val,b.val)};
}

struct LazySegmentTree{
    public:
        int n; 
        // change here
        ll zero=-1;
        vector<mono> node;
        vector<ll> lazy;
        LazySegmentTree(vector<mono> v){
            int sz = v.size();
            n = 1; while(n < sz) n *= 2;
            node.resize(2*n-1,mono());
            lazy.resize(2*n-1,zero);
        
            for (int i=0;i<sz;i++){
            node[i+n-1] = v[i];
            }
            for (int i=n-2;i>=0;i--) node[i] = func(node[i*2+1],node[i*2+2]);
        }
        
        void eval(int k, int l, int r){
            // change here
            if (lazy[k] != zero){
                node[k].val = lazy[k];
                if (r - l > 1){
                    lazy[2*k+1] = lazy[k];
                    lazy[2*k+2] = lazy[k];
                }
                lazy[k] = zero;
            }
            // until here
        }
        
        void update(int a, int b, ll x, int k=0, int l=0, int r=-1){
            eval(k,l,r);
            if (r < 0) r = n;
            if (r <= a || b <= l) return;
            if (a <= l && r <= b){
                // change here
                lazy[k] = x;
                // until here
                eval(k,l,r);
            } else {
                update(a,b,x,2*k+1,l,(l+r)/2);
                update(a,b,x,2*k+2,(l+r)/2,r);
                node[k] = func(node[2*k+1],node[2*k+2]);
            }
        }

        mono get(int a, int b, int k=0, int l=0, int r=-1){
            eval(k,l,r);
            if (r < 0) r = n;
            if (r <= a || b <= l) return mono();
            if (a <= l && r <= b) return node[k];
            mono vl = get(a,b,2*k+1,l,(l+r)/2);
            mono vr = get(a,b,2*k+2,(l+r)/2,r);
            return func(vl,vr);
        }
};