#include <bits/stdc++.h>

using namespace std;
using ll=long long;

struct PartiallyPersistentUnionFind {
  vector< ll > data;
  vector< ll > last;
  vector< vector< pair< ll, ll > > > add;

  PartiallyPersistentUnionFind() {}

  PartiallyPersistentUnionFind(ll sz) : data(sz, -1), last(sz, 1e9), add(sz) {
    for(auto &vs : add) vs.emplace_back(-1, -1);
  }

  bool unite(ll t, ll x, ll y) {
    x = find(t, x);
    y = find(t, y);
    if(x == y) return false;
    if(data[x] > data[y]) swap(x, y);
    data[x] += data[y];
    add[x].emplace_back(t, data[x]);
    data[y] = x;
    last[y] = t;
    return true;
  }

  ll find(ll t, ll x) {
    if(t < last[x]) return x;
    return find(t, data[x]);
  }

  ll size(ll t, ll x) {
    x = find(t, x);
    return -prev(lower_bound(begin(add[x]), end(add[x]), make_pair(t, 0)))->second;
  }
};
