#include <bits/stdc++.h>
using namespace std; using ll=long long; using ld=long double; using Pair=array<ll,2>;

#define rep(i,n) for (ll i=0;i<(n);i++)
#define rep2(i,a,b) for (ll i=(a);i<(b);i++)
#define repd(i,a,b) for (ll i=(a);i>=(b);i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }

struct mono{
        ll val=0;
};

struct mono_apply{
        ll mul=1;
        ll add=0;
};

mono func(mono a, mono b){
    return mono{a.val+b.val};
}

struct SegmentTree{
    int n;
    vector<mono> node;
    
    SegmentTree(vector<mono> v){
        int sz = v.size();
        n = 1; while(n < sz) n *= 2;
        node.resize(2*n-1,mono());
    
        for (int i=0;i<sz;i++){
        node[i+n-1] = v[i];
        }
        for (int i=n-2;i>=0;i--) node[i] = func(node[i*2+1],node[i*2+2]);
    }
    
    void update(int x, mono_apply apply){
        x += (n - 1);
        // change here
        node[x] = mono{node[x].val*apply.mul+apply.add};
        // until here
        while(x > 0){
        x = (x - 1) / 2;
        node[x] = func(node[2*x+1],node[2*x+2]);
        }
    }
    
    mono get(int a, int b, int k=0, int l=0, int r=-1){
        if (r < 0) r = n;
        if (r <= a || b <= l) return mono();
        if (a <= l && r <= b) return node[k];
        mono vl = get(a,b,2*k+1,l,(l+r)/2);
        mono vr = get(a,b,2*k+2,(l+r)/2,r);
        return func(vl,vr);
    }
};

int main2() {
    cin(N);
    vector<vector<ll>> G(N);

    rep(i,N-1){
        cin2(a,b);
        a--;b--;
        G[a].push_back(b);
        G[b].push_back(a);
    }

    cinvec(C);

    ll acm = accumulate(C.begin(),C.end(),0LL);

    vector<mono> v(2*N,mono{0});
    SegmentTree seg(v);
    map<Pair,ll> subtree_sum;

    ll count = 0;

    auto dfs = [&](auto &&f, ll now, ll from)->void{
        ll id = count;
        seg.update(id,mono_apply{0,C[now]});
        count++;
        for(auto &to: G[now]){
            if (to == from) continue;
            f(f,to,now);
        }
        subtree_sum[Pair{from,now}] = seg.get(id,count+1).val;
    };

    dfs(dfs,0,-1);

    rep(i,N){
        for (auto &to: G[i]){
            if (subtree_sum[Pair{i,to}] == 0){
                subtree_sum[Pair{i,to}] = acm - subtree_sum[Pair{to,i}];
            }
        }
    }

    //outvec({subtree_sum[Pair{0,1}],subtree_sum[Pair{1,0}]});
}