#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}

// Description: 区間をsetで管理するデータ構造(なお実装はmap)．各クエリO(log区間数)．
 
// #### attention! : [l, r] ( include r, not [l, r) )
class SegmentMap : public std::map<ll, ll> {
    private:
        bool flagToMergeAdjacentSegment;
    public:
        // if merge [l, c] and [c+1, r], set flagToMergeAdjacentSegment to true
        SegmentMap(bool flagToMergeAdjacentSegment) :
            flagToMergeAdjacentSegment(flagToMergeAdjacentSegment) {}
        // __exist -> iterator pair(l, r) (contain p)
        // noexist -> map.end()
        auto get(ll p) const {
            auto it = upper_bound(p);
            if (it == begin() || (--it)->second < p) return end();
            return it;
        }
        // insert segment [l, r]
        void insert(ll l, ll r) {
            auto itl = upper_bound(l), itr = upper_bound(r + flagToMergeAdjacentSegment);
            if (itl != begin()) {
                if ((--itl)->second < l - flagToMergeAdjacentSegment) ++itl;
            }
            if (itl != itr) {
                l = std::min(l, itl->first);
                r = std::max(r, std::prev(itr)->second);
                erase(itl, itr);
            }
            (*this)[l] = r;
        }
        // remove segment [l, r]
        void remove(ll l, ll r) {
            auto itl = upper_bound(l), itr = upper_bound(r);
            if (itl != begin()) {
                if ((--itl)->second < l) ++itl;
            }
            if (itl == itr) return;
            ll tl = std::min(l, itl->first), tr = std::max(r, std::prev(itr)->second);
            erase(itl, itr);
            if (tl < l) (*this)[tl] = l - 1;
            if (r < tr) (*this)[r + 1] = tr;
        }
        // Is p and q in same segment?
        bool same(ll p, ll q) const {
            const auto&& it = get(p);
            return it != end() && it->first <= q && q <= it->second;
        }
        // return size of segments
        ll size() const {
            ll ret = 0;
            for (auto [l,r]: *this) ret += r-l+1;
            return ret;
        }
        // return all segments
        vector<array<ll,2>> get_segments() const {
            vector<array<ll,2>> ret;
            for (auto [l,r]: *this) ret.push_back({l,r});
            return ret;
        }
        pair<ll,ll> get_left() const {
            auto [l,r] = *begin();
            return {l,r};
        }
};

struct Mex{

    SegmentMap seg;
    unordered_map<ll,ll> mp;

    Mex() : seg(true) {}

    void insert(ll x) {
        mp[x]++;
        if (mp[x] == 1) {
            seg.insert(x,x);
        }
    }

    void remove(ll x) {
        mp[x]--;
        if (mp[x] == 0) {
            mp.erase(x);
            seg.remove(x,x);
        }
    }

    ll get() {
        auto it = seg.get(0);
        if (it == seg.end()) {
            return 0;
        } else {
            return it->second + 1;
        }
    }
};

int main2() {
    cin2(N,Q);
    cinvec(A);

    Mex mex;
    rep(i,N) {
        mex.insert(A[i]);
    }

    rep(i,Q){
        cin2(t,x);
        t--;
        mex.remove(A[t]);
        A[t] = x;
        mex.insert(A[t]);
        cout << mex.get() << endl;
    }
    
    return 0;
} 
