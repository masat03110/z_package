#include <bits/stdc++.h>

using namespace std;
using ll=long long;
using Pair=array<ll,2>;

// O(EV^2) (E:辺の数, V:頂点の数)
// 二部グラフの最大マッチングの時はO(E*sqrt(V))
// ギリギリでも通る

class Dinic_MaximFlow{
    private:
        struct Edge{
            ll to;
            ll cap;
            ll rev;
        };
        vector<vector<Edge>> G;
        vector<ll> level;
        vector<ll> iter;
        ll N;
        void bfs(ll s){
            for (ll i=0;i<N;i++) level[i] = -1;
            queue<ll> que;
            level[s] = 0;
            que.push(s);
            while(!que.empty()){
                ll v = que.front(); que.pop();
                for (ll i=0;i<G[v].size();i++){
                    Edge &e = G[v][i];
                    if (e.cap > 0 && level[e.to] < 0){
                        level[e.to] = level[v] + 1;
                        que.push(e.to);
                    }
                }
            }
        }
        ll dfs(ll v, ll t, ll f){
            if (v == t) return f;
            for (ll &i=iter[v];i<G[v].size();i++){
                Edge &e = G[v][i];
                if (e.cap > 0 && level[v] < level[e.to]){
                    ll d = dfs(e.to, t, min(f, e.cap));
                    if (d > 0){
                        e.cap -= d;
                        G[e.to][e.rev].cap += d;
                        return d;
                    }
                }
            }
            return 0;
        }
    public:
        Dinic_MaximFlow(ll n){
            N = n;
            G.resize(n);
            level.resize(n);
            iter.resize(n);
        }
        void add_edge(ll from, ll to, ll cap){
            G[from].push_back((Edge){to, cap, (ll)G[to].size()});
            G[to].push_back((Edge){from, 0, (ll)G[from].size()-1});
        }
        ll max_flow(ll s, ll t){
            ll flow = 0;
            while (true){
                bfs(s);
                if (level[t] < 0) return flow;
                for (ll i=0;i<N;i++) iter[i] = 0;
                ll f;
                while ((f = dfs(s, t, 1e18)) > 0){
                    flow += f;
                }
            }
        }
        vector<vector<Edge>> edges(){
            return G;
        }

        vector<Pair> matching_res(ll Ns){
            vector<Pair> ans;
            for (ll i=0;i<Ns;i++){
                for (ll j=0;j<G[i].size();j++){
                    Edge e = G[i][j];
                    if (e.cap == 0) ans.push_back(Pair{i,e.to});
                }
            }
            return ans;
        }
};