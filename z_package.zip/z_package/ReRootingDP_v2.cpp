#include <bits/stdc++.h>

using namespace std;

using ll=long long;
using ld=long double;
#define yes {cout << "Yes" << endl; return 0;}
#define no {cout << "No" << endl; return 0;}
#define rep(i,n) for (ll i=0;i<(n);i++)
#define rep2(i,a,b) for (ll i=(a);i<(b);i++)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}

// https://null-mn.hatenablog.com/entry/2020/04/14/124151

template <typename T>
struct ReRooting {
  using F = function<T(T, ll, ll)>;
  using F2 = function<T(T, T)>;
  using F3 = function<T(T, ll)>;
  ll V;
  vector<vector<ll>> G;
  vector<vector<T>> dp;
  // dp_v = g(merge(f(dp_c1,c1,v), f(dp_c2,c2,v), ..., f(dp_ck,ck,v)), v)
  F f;
  F3 g;
  F2 merge;
  T mi;  // identity of merge

  ReRooting() {}
  ReRooting(ll V, F f, F2 merge, T mi, F3 g)
      : V(V), f(f), merge(merge), mi(mi), g(g) {
    G.resize(V);
    dp.resize(V);
  }

  void read(ll idx = 1) {
    ll a, b;
    for (ll i = 0; i < V - 1; ++i) {
      cin >> a >> b;
      a -= idx, b -= idx;
      G[a].emplace_back(b);
      G[b].emplace_back(a);
    }
  }

  void add_edge(ll a, ll b) {
    G[a].emplace_back(b);
    G[b].emplace_back(a);
  }

  T dfs1(ll p, ll v) {
    T res = mi;
    for (ll i = 0; i < G[v].size(); ++i) {
      if (G[v][i] == p) continue;
      dp[v][i] = dfs1(v, G[v][i]);
      res = merge(res, f(dp[v][i], G[v][i], v));
    }
    return g(res, v);
  }

  void dfs2(ll p, ll v, T from_par) {
    for (ll i = 0; i < G[v].size(); ++i) {
      if (G[v][i] == p) {
        dp[v][i] = from_par;
        break;
      }
    }
    vector<T> pR(G[v].size() + 1);
    pR[G[v].size()] = mi;
    for (ll i = G[v].size(); i > 0; --i)
      pR[i - 1] = merge(pR[i], f(dp[v][i - 1], G[v][i - 1], v));
    T pL = mi;
    for (ll i = 0; i < G[v].size(); ++i) {
      if (G[v][i] != p) {
        T val = merge(pL, pR[i + 1]);
        dfs2(v, G[v][i], g(val, v));
      }
      pL = merge(pL, f(dp[v][i], G[v][i], v));
    }
  }

  void calc(ll root = 1) {
    for (ll i = 0; i < V; ++i) dp[i].resize(G[i].size());
    dfs1(-1, root);
    dfs2(-1, root, mi);
  }

  T solve(ll v) {
    T ans = mi;
    for (ll i = 0; i < G[v].size(); ++i){
      ans = merge(ans, f(dp[v][i], G[v][i], v));
    }
    return g(ans, v);
  }
};

int main2()
{
  int n, m;
  cin >> n >> m;
  auto f = [&](long long a, ll v, ll p) {
    (void)v;
    return (a + 1) % m;
  };
  auto merge = [&](long long a, long long b) {
    return a * b % m;
  };
  auto g = [&](long long a, ll v) {
    return a;
  };
  ReRooting<long long> re(n, f, merge, 1, g);
  re.read();

  re.calc();
  for (int i = 0; i < n; ++i)
    cout << re.solve(i) << endl;
  return 0;
}