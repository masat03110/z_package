#include <bits/stdc++.h>

using namespace std;
using ll=long long;

// O(logN)
class UnionFind {
    vector<ll> par;
    vector<ll> rank;
    vector<ll> size;
    vector<ll> diff_weight;

    public:
        UnionFind(ll n=1, ll w=0) {
            init(n,w);
        }

        void init(ll n=1, ll w=0) {
            par.resize(n);
            rank.resize(n);
            size.resize(n);
            diff_weight.resize(n);
            for (ll i=0;i<n;i++){
                par[i] = i;
                rank[i] = 0;
                size[i] = 1;
                diff_weight[i] = 0;
            }
        }

        ll root(ll x) {
            if (par[x] == x){
                return x;
            } else {
                ll r = root(par[x]);
                diff_weight[x] += diff_weight[par[x]];
                return par[x] = r;
            }
        }

        ll getWeight(ll x){
            root(x);
            return diff_weight[x];
        }

        bool issame(ll x, ll y) {
            return root(x) == root(y);
        }

        bool merge(ll x, ll y, ll w) {
            w += getWeight(x); w -= getWeight(y);
            x = root(x); y = root(y);
            if (x == y) return false;
            if (rank[x] < rank[y]) swap(x,y), w = -w;
            if (rank[x] == rank[y]) rank[x]++;
            par[y] = x;
            size[x] += size[y];
            diff_weight[y] = w;
            return true;
        }

        ll getsize(ll x) {
            return size[root(x)];
        }

        ll diff(ll x, ll y) {
            return getWeight(y) - getWeight(x);
        }
};