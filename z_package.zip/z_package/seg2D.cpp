#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }


/**
* Binary_Indexed_Tree(BIT) 2d by mod
* Fenwick Tree
* 0-indexed!!!
* O((log N)(log M))
*/
template<int mod>
class binary_indexed_tree_2d_by_mod {
private:
    int N;
    int M;
    std::vector<std::vector<int>> bit;

    void add(int &a, int b) {
        if (b < 0) b += mod;
        a += b;
        if (a >= mod) a -= mod;
    }

    int sum(int x, int y) {
        int res = 0;

        for (int i = x; i > 0; i -= i & (-i)) {
            for (int j = y; j > 0; j -= j & (-j)) {
                this->add(res, this->bit[i - 1][j - 1]);
            }
        }
        return res;
    }

public:
    binary_indexed_tree_2d_by_mod() {}
    binary_indexed_tree_2d_by_mod(int n, int m) : N(n + 2), M(m + 2), bit(n + 2, std::vector<int>(m + 2)) {}

    void add(int x, int y, long long val) {
        // for mod calc
        val %= mod;
        // for 0-indexed
        x++; y++;

        for (int i = x; i - 1 < N; i += i & (-i)) {
            for (int j = y; j - 1 < M; j += j & (-j)) {
                this->add(this->bit[i - 1][j - 1], val);
            }
        }
    }

    // [ (x1, y1), (x2, y2) )
    int sum(int x1, int y1, int x2, int y2) {

        int res = this->sum(x2 + 1, y2 + 1);
        add(res, -sum(x1, y2 + 1));
        add(res, -sum(x2 + 1, y1));
        add(res, sum(x1, y1));

        return res;
    }
};

int main2() {
    cin2(N,M); cinvec2(A,N); cinvec2(B,M);

    const ll MOD = 1e9+7;
    binary_indexed_tree_2d_by_mod<MOD> bit(2008,2008);

    rep(i,N) rep(j,M) {
        if (A[i] == B[j]) {
            ll sum = bit.sum(0,0,i,j) + 1;
            bit.add(i,j,sum);
        }
    }

    cout << bit.sum(0,N,0,M) << endl;
    
    return 0;
} 
