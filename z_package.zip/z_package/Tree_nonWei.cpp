#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

#include <bits/stdc++.h>
#include <atcoder/all>

using std::cout; using namespace std; using ll=long long; using ld=long double; using mint = atcoder::modint998244353;
#define rep(i,n) for (int i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (int i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (int i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }

struct Tree_NonWeight{
    public: 
    vector<vector<int>> G;
	int N;
    vector<int> EulerTour_d;
    vector<int> EulerTour;
    vector<int> EulerTour_id;
    vector<int> depth;
	vector<int> median_point;
	array<int,3> diameter;
    atcoder::segtree<array<int,2>, [](array<int,2> a, array<int,2> b){return a[0] < b[0] ? a:b;}, [](){return array<int,2>{(int)1e9,-1};} > seg;

    void dfs_e(int now, int par, int d){
        EulerTour.push_back(now);
        EulerTour_d.push_back(now);
        depth[now] = d;
        for(auto next: G[now]){
            if(next == par) continue;
            dfs_e(next, now, d+1);
            EulerTour_d.push_back(now);
        }
        return;
    }

    int dfs_mp(int v, int p){
        int child = 0;
        int tree_size = 0;
        for (auto nv: G[v]){
            if (nv == p) continue;
            int c = dfs_mp(nv,v);
            child += c;
            tree_size = max(tree_size,c);
        }
        tree_size = max(tree_size, N - child - 1);
        if (tree_size <= N/2) median_point.push_back(v);
        return child + 1;
    };

	void dfs_dis(int v, int p, int nowdis, int &maxdis, int &maxnode){
		if (nowdis > maxdis){
			maxdis = nowdis;
			maxnode = v;
		}
		for (auto nv: G[v]){
			if (nv == p) continue;
			dfs_dis(nv,v,nowdis+1,maxdis,maxnode);
		}
	}

    Tree_NonWeight(vector<vector<int>> _G): seg(_G.size()*2), G(_G), depth(_G.size(),1e9) , EulerTour_id(_G.size(),-1), EulerTour_d(), diameter({0,0,0}){
        N = _G.size();
		dfs_e(0, -1, 0);
		dfs_mp(0,-1);
		dfs_dis(0,-1,0,diameter[0], diameter[1]);
		dfs_dis(diameter[1],-1,0,diameter[0],diameter[2]);

        for(int i=0; i<EulerTour_d.size(); i++){
            if (EulerTour_id[EulerTour_d[i]] == -1) EulerTour_id[EulerTour_d[i]] = i;
            seg.set(i, {depth[EulerTour_d[i]],i});
            assert(depth[EulerTour_d[i]] != 1e9);
        }
    }

    int get_LCA(int u, int v){
        int l = EulerTour_id[u];
        int r = EulerTour_id[v];
        if(l > r) swap(l,r);
        return EulerTour_d[seg.prod(l,r+1)[1]];
    }

    int get_dist(int u, int v){
        return depth[u] + depth[v] - 2*depth[get_LCA(u,v)];
    }
};

int main2(){
	int N; cin >> N;
	vector<vector<int>> G(N);
	for (int i=0;i<N-1;i++){
		int a,b;
        cin >> a >> b;
		a--;b--;
		G[a].push_back(b);
		G[b].push_back(a);
	}
	Tree_NonWeight T(G);
    vector<int> a = T.median_point;
    //outvec(a);
    vector<int> b = T.EulerTour;
    if (N & 1){
        b.erase(find(b.begin(),b.end(),a[0]));
        rep(i,N/2){
            cout << b[i]+1 << " " << b[N/2+i]+1 << endl;
        }
    }else{
        rep(i,N/2){
            cout << b[i]+1 << " " << b[N/2+i]+1 << endl;
        }
    }
}