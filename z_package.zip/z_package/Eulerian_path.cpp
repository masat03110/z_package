#include <bits/stdc++.h>
using namespace std;
using ll=long long;
 
//グラフのエッジを格納するデータ構造
struct Edge {
    ll src, dest;
};
 
//グラフオブジェクトを表すクラス
class Graph
{
public:
 
    //隣接リストを表すvectorのvector
    vector<vector<ll>> adjList;
 
    //グラフの各頂点の次数を格納するvector
    vector<ll> in;
 
    //グラフコンストラクタ
    Graph(ll n, vector<Edge> const &edges = {})
    {
        //両方のvectorのサイズを変更してそれぞれ`n`要素を保持します
        adjList.resize(n);
        in.resize(n);
 
        //有向グラフにエッジを追加し、各エッジの角度を更新します
        for (auto &edge: edges) {
            addEdge(edge.src, edge.dest);
        }
    }
 
    //グラフにエッジ(u、v)を追加するユーティリティ関数
    void addEdge(ll u, ll v)
    {
        adjList[u].push_back(v);
        in[v]++;
    }
};
 
//グラフ上でDFSトラバーサルを実行するユーティリティ関数
void DFS(Graph const &graph, ll u, vector<bool> &visited)
{
    //現在のノードを訪問済みとしてマークします
    visited[u] = true;
 
    //すべてのエッジに対して実行(u、v)
    for (ll v: graph.adjList[u])
    {
        //`v`にアクセスしない場合は繰り返します
        if (!visited[v]) {
            DFS(graph, v, visited);
        }
    }
}
 
//グラフ、つまり同じグラフの転置を作成する関数
//すべてのエッジの方向を逆にします
Graph buildTranspose(Graph const &graph, ll n)
{
    Graph g(n);
 
    for (ll u = 0; u < n; u++)
    {
        //すべてのエッジ(u、v)に対して、逆エッジ(v、u)を作成します
        //転置グラフ内
        for (ll v: graph.adjList[u]) {
            g.addEdge(v, u);
        }
    }
    return g;
}
 
//次数がゼロ以外のグラフのすべての頂点にアクセスしたかどうかを確認する関数
bool isVisited(Graph const &graph, const vector<bool> &visited)
{
    for (ll i = 0; i < visited.size(); i++)
    {
        if (graph.adjList[i].size() && !visited[i]) {
            return false;
        }
    }
    return true;
}
 
//グラフ内のゼロ以外の次数を持つすべての頂点がに属しているかどうかを確認する関数
//コサラジュのアルゴリズムを使用した単一の強連結成分
bool isSC(Graph const &graph, ll n)
{
    //以前にアクセスしたすべての頂点を追跡します
    vector<bool> visited(n);
 
    //ゼロ以外の次数を持つ最初の頂点`i`を見つけ、そこからDFSを開始します
    ll i;
    for (i = 0; i < n; i++)
    {
        if (graph.adjList[i].size())
        {
            DFS(graph, i, visited);
            break;
        }
    }
 
    // DFSがゼロ以外の次数ですべての頂点にアクセスできなかった場合、falseを返します
    if (!isVisited(graph, visited)) {
        return false;
    }
 
    //訪問したアレイをリセットします
    fill(visited.begin(), visited.end(), false);
 
    //グラフの転置を作成します
    Graph g = buildTranspose(graph, n);
 
    //同じ開始頂点を使用して転置グラフでDFSを実行します
    //前のDFS呼び出しで使用
    DFS(g, i, visited);
 
    //2番目のDFSもゼロ以外の次数ですべての頂点を探索した場合はtrueを返します。
    //それ以外の場合はfalse
    return isVisited(g, visited);
}
 
//有向グラフにオイラー閉路があるかどうかをチェックする関数
bool hasEulerianCycle(Graph const &graph, ll n)
{
    //すべての頂点の次数と次数が同じかどうかを確認します
    for (ll i = 0; i < n; i++)
    {
        if (graph.adjList[i].size() != graph.in[i]) {
            return false;
        }
    }
 
    //次数がゼロ以外のすべての頂点が単一に属しているかどうかを確認します
    //強く接続されたコンポーネント
    return isSC(graph, n);
}
 
ll main2()
{
    //上の図のようなグラフエッジのvector
    vector<Edge> edges = {
        {0, 1}, {1, 2}, {2, 3}, {3, 1}, {1, 4}, {4, 3}, {3, 0}
    };
 
    //グラフ内のノードの総数(0から4までのラベルが付いています)
    ll n = 5;
 
    //上記のエッジから有向グラフを作成します
    Graph graph(n, edges);
 
    if (hasEulerianCycle(graph, n)) {
        cout << "The graph has an Eulerian cycle" << endl;
    }
    else {
        cout << "The Graph does not contain Eulerian cycle" << endl;
    }
 
    return 0;
}