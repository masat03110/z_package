template<class T>
struct Fraction{
    T Bunsi,Bunbo;
    Fraction(T Bunsi=0,T Bunbo=1)noexcept:Bunsi(Bunsi),Bunbo(Bunbo){reduce();}
    void reduce(){
        if(Bunbo<0){Bunbo=-Bunbo;Bunsi=-Bunsi;}
        if(Bunsi==0){Bunbo=1;return;}
        T GCD=gcd(abs(Bunsi),abs(Bunbo));
        Bunsi/=GCD;Bunbo/=GCD;
    }
    const Fraction<T>& operator++(){
        Bunsi+=Bunbo;reduce();return *this;
    }
    const Fraction<T>& operator--(){
        Bunsi-=Bunbo;reduce();return *this;
    }
    const Fraction<T>& operator+=(const Fraction<T>& rhs)noexcept{
        Bunsi=Bunsi*rhs.Bunbo+Bunbo*rhs.Bunsi;
        Bunbo=Bunbo*rhs.Bunbo;reduce();
        return *this;
    }
    const Fraction<T>& operator-=(const Fraction<T>& rhs)noexcept{
        Bunsi=Bunsi*rhs.Bunbo-Bunbo*rhs.Bunsi;
        Bunbo=Bunbo*rhs.Bunbo;reduce();
        return *this;
    }
    const Fraction<T>& operator*=(const Fraction<T>& rhs)noexcept{
        Bunsi=Bunsi*rhs.Bunsi;
        Bunbo=Bunbo*rhs.Bunbo;reduce();
        return *this;
    }
    const Fraction<T>& operator/=(const Fraction<T>& rhs)noexcept{
        Bunsi*=rhs.Bunbo;
        Bunbo*=rhs.Bunsi;reduce();
        return *this;
    }

    friend Fraction<T> operator+(const Fraction<T> &lhs,const Fraction<T> &rhs)noexcept{
        return Fraction(lhs)+=rhs;
    }
    friend Fraction<T> operator-(const Fraction<T> &lhs,const Fraction<T> &rhs)noexcept{
        return Fraction(lhs)-=rhs;
    }
    friend Fraction<T> operator*(const Fraction<T> &lhs,const Fraction<T> &rhs)noexcept{
        return Fraction(lhs)*=rhs;
    }
    friend Fraction<T> operator/(const Fraction<T> &lhs,const Fraction<T> &rhs)noexcept{
        return Fraction(lhs)/=rhs;
    }
    constexpr bool operator<(const Fraction<T> &rhs)const noexcept{
        return Bunsi*rhs.Bunbo<Bunbo*rhs.Bunsi;
    }
    constexpr bool operator<=(const Fraction<T> &rhs)const noexcept{
        return Bunsi*rhs.Bunbo<=Bunbo*rhs.Bunsi;
    }
    constexpr bool operator>(const Fraction<T> &rhs)const noexcept{
        return Bunsi*rhs.Bunbo>Bunbo*rhs.Bunsi;
    }
    constexpr bool operator>=(const Fraction<T> &rhs)const noexcept{
        return Bunsi*rhs.Bunbo>=Bunbo*rhs.Bunsi;
    }
    constexpr bool operator==(const Fraction<T> &rhs)const noexcept{
        return Bunsi*rhs.Bunbo==Bunbo*rhs.Bunsi;
    }
    constexpr bool operator!=(const Fraction<T> &rhs)const noexcept{
        return Bunsi*rhs.Bunbo!=Bunbo*rhs.Bunsi;
    }
    
};