// https://atcoder.jp/contests/abc196/tasks/abc196_e

#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
template<typename T, typename F> T bs(T l, T r, F f) { for(int i=0;i<100;i++){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}

struct mono_lazy1{
    array<ll,3> lazy = {0,(ll)-1e18,(ll)1e18};
};

void upd(mono_lazy1& a, mono_lazy1& b){
    mono_lazy1 res;
    res.lazy[0] = a.lazy[0]+b.lazy[0];
    res.lazy[1] = max(b.lazy[1],b.lazy[0]+a.lazy[1]);
    res.lazy[2] = min(b.lazy[2],max(b.lazy[1],b.lazy[0]+a.lazy[2]));
    a = res;
    return;
}

struct mono1{
    ll val=0;
};

void func(mono1& a, mono_lazy1& b){
    ll tmp = a.val;
    a.val = min(b.lazy[2],max(b.lazy[1],b.lazy[0]+tmp));
    return;
}

class segtree_dual{
public:
	vector<mono_lazy1> data;
    vector<mono1> original;
	int n;

	segtree_dual(int _n){
		n=_n;
		data.resize(2*n);
	}

    segtree_dual(vector<mono1> _original){
        n = _original.size();
        original = _original;
        data.resize(2*n);
    }

	void eval(int p,mono_lazy1 b){
		upd(data[p],b);
	}

	void prod(int l,int r,mono_lazy1 b){
		for(l+=n,r+=n;l!=r;l=(l+1)>>1,r>>=1){
			if(l&1)eval(l,b);
			if(r&1)eval(r-1,b);
		}
	}

	mono1 get(int i){
		mono1 ans = original[i];
		for(i+=n;i;i>>=1){
            func(ans,data[i]);
		}
		return ans;
	}
};


// int main2(){
// 	int n;
// 	cin >> n;
// 	segtree_dual seg(n);
// 	rep(i,n){
// 		int a;
// 		cin >> a;
//         multiset<P> b;
//         b.insert({a,0});
// 		seg.prod(i,i+1,mono_lazy1{b});
// 	}

// 	int q;
// 	cin >> q;
// 	vector<array<int,3>>query(q+1);
// 	for(int i=1;i<=q;i++){
// 		int t;
// 		cin >> t;
// 		if(t==1){
// 			int l,r,val;
// 			cin >> l >> r >> val;
// 			l--;
//             multiset<P> b;
//             b.insert({val,i});
// 			seg.prod(l,r,mono_lazy1{b});
// 			query[i]={l,r,val};
// 		}else if(t==2){
// 			int ii;
// 			cin >> ii;
//             multiset<P> b;
//             b.insert({-query[ii][2],ii});
// 			seg.prod(query[ii][0],query[ii][1],mono_lazy1{b});
// 		}else{
// 			int ii;
// 			cin >> ii;
// 			cout << seg.get(ii-1).val << endl;
// 		}
// 	}
// }

int main3() {
    cin(N);
    vector<ll> A(N),T(N);
    rep(i,N) cin >> A[i] >> T[i];
    cin(Q);
    cinvec2(X,Q);
    vector<mono1> X2(Q);
    rep(i,Q){
        X2[i].val = X[i];
    }
    segtree_dual seg(X2);

    rep(i,N){
        mono_lazy1 b;
        if (T[i] == 1){
            b.lazy[0] = A[i];
        }else if (T[i] == 2){
            b.lazy[1] = A[i];
        }else if (T[i] == 3){
            b.lazy[2] = A[i];
        }
        seg.prod(0,Q,b);
    }

    rep(i,Q){
        cout << seg.get(i).val << endl;
    }
    
    return 0;
} 
