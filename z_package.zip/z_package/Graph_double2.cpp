// https://atcoder.jp/contests/arc198/submissions/66182682

#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
#define seg_RmaRmsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{(a[0]+b[0])%998244353ll,a[1]+b[1]};},[&](){return array<ll,2>{0,0};},array<ll,2>,[&](array<ll,2> m, array<ll,2> n){ return array<ll,2>{(m[0]*n[0]+m[1]*n[1])%998244353ll,n[1]};}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0]%998244353ll, (b[1]*a[0]+a[1])%998244353ll};},[&](){return array<ll,2>{1ll,0ll};}>
#define seg_Parentheses atcoder::segtree<array<int,3>, [&](array<int,3> a, array<int,3> b){ int m = min(a[1], b[2]);return array<int,3>{a[0]+b[0]+2*m, a[1]+b[1]-m, a[2]+b[2]-m};},[](){return array<int,3>{0,0,0};}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
template<typename T, typename F> T bs(T l, T r, F f) { for(int i=0;i<100;i++){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
template<typename T, typename F> T bs_fast(T l, T r, F f) { while(r-l>1){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}
ll stollmod(string S, ll mod) {ll ret = 0; rep(i,S.size()){ ret = (ret*10 + (S[i]-'0'))%mod; } return ret; }

/// @brief 重み付き Union-Find 木
/// @tparam Type 重みの表現に使う型
/// @note 1.2 省メモリ化
/// @see https://zenn.dev/reputeless/books/standard-cpp-for-competitive-programming/viewer/weighted-union-find

// O(α(N))
template <class Type>
class WeightedUnionFind
{
public:

	WeightedUnionFind() = default;

	ll num_parts;
    std::unordered_set<ll> roots;

	/// @brief 重み付き Union-Find 木を構築します。
	/// @param n 要素数
	explicit WeightedUnionFind(size_t n)
		: m_parentsOrSize(n, -1), num_parts(n)
		, m_diffWeights(n) {
            for (int i = 0; i < n; i++) roots.insert(i);
        }

	/// @brief 頂点 i の root のインデックスを返します。
	/// @param i 調べる頂点のインデックス
	/// @return 頂点 i の root のインデックス
	ll find(ll i)
	{
		if (m_parentsOrSize[i] < 0)
		{
			return i;
		}

		const ll root = find(m_parentsOrSize[i]);

		m_diffWeights[i] += m_diffWeights[m_parentsOrSize[i]];

		// 経路圧縮
		return (m_parentsOrSize[i] = root);
	}

	/// @brief a のグループと b のグループを統合します。
	/// @param a 一方のインデックス
	/// @param b 他方のインデックス
	/// @param w (b の重み) - (a の重み)
	ll merge(ll a, ll b, Type w)
	{
		w += weight(a);
		w -= weight(b);

		a = find(a);
		b = find(b);

		if (a != b)
		{
			// union by size (小さいほうが子になる）
			if (-m_parentsOrSize[a] < -m_parentsOrSize[b])
			{
				std::swap(a, b);
				w = -w;
			}

			m_parentsOrSize[a] += m_parentsOrSize[b];
			m_parentsOrSize[b] = a;
			m_diffWeights[b] = w;
			num_parts--;
            roots.erase(b);
            return b;
		}else{
            return -1;
        }
	}

	/// @brief (b の重み) - (a の重み) を返します。
	/// @param a 一方のインデックス
	/// @param b 他方のインデックス
	/// @remark a と b が同じグループに属さない場合の結果は不定です。
	/// @return (b の重み) - (a の重み)
	Type diff(ll a, ll b)
	{
		return (weight(b) - weight(a));
	}

	/// @brief a と b が同じグループに属すかを返します。
	/// @param a 一方のインデックス
	/// @param b 他方のインデックス
	/// @return a と b が同じグループに属す場合 true, それ以外の場合は false
	bool connected(ll a, ll b)
	{
		return (find(a) == find(b));
	}

	/// @brief i が属するグループの要素数を返します。
	/// @param i インデックス
	/// @return i が属するグループの要素数
	ll size(ll i)
	{
		return -m_parentsOrSize[find(i)];
	}

	/// @brief グループの数を返します。
	/// @return グループの数
	ll num()
	{
		return num_parts;
	}

private:

	// m_parentsOrSize[i] は i の 親,
	// ただし root の場合は (-1 * そのグループに属する要素数)
	std::vector<ll> m_parentsOrSize;

	// 重み
	std::vector<Type> m_diffWeights;

	Type weight(ll i)
	{
		find(i); // 経路圧縮
		return m_diffWeights[i];
	}
};

// O(N)
struct KruskalMethod{
	ll N;
	vector<array<ll,3>> E;
	ll MST(vector<vector<array<ll,2>>> &G){
		N = G.size();
		E.clear();
		for (ll i=0;i<N;i++){
			for (ll j=0;j<G[i].size();j++){
				if (i < G[i][j][0]){
					E.push_back({G[i][j][1], i, G[i][j][0]});
				}
			}
		}
		sort(E.begin(), E.end());
		WeightedUnionFind<ll> uf(N);
		ll res = 0;
        ll cnt = 0;
		for (ll i=0;i<E.size();i++){
			ll cost = E[i][0];
			ll from = E[i][1];
			ll to = E[i][2];
			if (!uf.connected(from, to)){
				uf.merge(from, to, cost);
                cnt++;
				res += cost;
			}
		}
        if (cnt != N-1) return -1;
		return res;
	}
};

int main2() {
    cin2(N,M);

    WeightedUnionFind<ll> uf(N);

    vector<array<ll,2>> AB;
    vector<ll> cable;

    rep(i,M){
        cin2(A,B);
        if (uf.connected(A-1,B-1)){
            AB.push_back({A,B});
            cable.push_back(i+1);
        }else{
            uf.merge(A-1,B-1,0);
        }
    }

    ll num = uf.num();

    ll ans = num - 1;
    vector<array<ll,3>> ans_cable;

    rep(i,AB.size()){
        ll a = uf.find(AB[i][0]-1);
        // 自分とは違うグループに属している点を一つ選ぶ
        ll another_root = -1;
        for (auto root : uf.roots){
            if (root == a) continue;
            another_root = root;
            break;
        }
        if (another_root == -1) continue;
        uf.merge(AB[i][0]-1,another_root,0);
        ans_cable.push_back({cable[i],AB[i][1],another_root+1});
    }

    assert(ans_cable.size() == ans);

    cout << ans_cable.size() << endl;

    rep(i,ans_cable.size()){
        cout << ans_cable[i][0] << " " << ans_cable[i][1] << " " << ans_cable[i][2] << endl;
    }
    
    return 0;
} 

// 二乗グラフを構築
// O(N^2 + min(N^3, M^2))
// ただし、定数倍が結構重い
struct Graph_double{
    vector<vector<int>> G_double;
    vector<vector<int>> G;
    vector<int> length;
    vector<int> parent;
    vector<vector<int>> dist;
    int N;
    Graph_double(vector<vector<int>> _G): G(_G), N(_G.size()) {
        G_double.resize(N*N+1);
        rep(i,N) {
            G_double[i*N+i].push_back(N*N); // ルートからの辺を追加
            G_double[N*N].push_back(i*N+i); // ルートからの辺を追加
        }
        rep(i,N){
            for (int j: G[i]) {
                if (i <= j) {
                    G_double[i*N+j].push_back(N*N); // ルートからの辺を追加
                    G_double[N*N].push_back(i*N+j); // ルートからの辺を追加
                }
            }
        }

        rep(i,N){
            rep2(j,i,N){
                for (int ni: G[i]) {
                    for (int nj: G[j]){
                        if (ni <= nj) G_double[i*N+j].push_back(ni*N+nj); // iからjへの辺を追加
                        else G_double[i*N+j].push_back(nj*N+ni); // jからiへの辺を追加
                    }
                }
            }
        }

        rep(i,N*N+1){
            sortunique(G_double[i]);
        }
    }

    // 何度でも同じところを通ってよいときの、回文判定
    void palindorome_nodes(vector<int> &A){
        length.resize(N*N+1,-1);
        length[N*N] = 0;
        queue<int> que;
        rep(i,N){
            que.push(i*N+i);
            length[i*N+i] = 0;
        }
        rep(i,N) for (auto j: G[i]) {
            if ((i < j) && (A[i] == A[j])) {
                que.push(i*N+j);
                length[i*N+j] = 1;
            }
        }

        while (!que.empty()) {
            int v = que.front();
            que.pop();
            for (auto nv: G_double[v]) {
                int ni = nv / N;
                int nj = nv % N;
                if (length[nv] == -1 && A[ni] == A[nj]) {
                    length[nv] = length[v] + 2;
                    que.push(nv);
                }
            }
        }

        return;
    }

    // 何度でも同じ辺を通ってよいときの、回文判定
    void palindorome_edges(vector<array<int,3>> &E){

        vector<vector<int>> edge_to_char(N*N);
        for (auto &e: E) {
            int u = e[0];
            int v = e[1];
            edge_to_char[u*N+v].push_back(e[2]);
            edge_to_char[v*N+u].push_back(e[2]);
        }

        rep(i,N*N){
            sortunique(edge_to_char[i]);
        }

        length.resize(N*N+1,-1);
        length[N*N] = 0;
        queue<int> que;
        rep(i,N){
            que.push(i*N+i);
            length[i*N+i] = 0;
        }
        rep(i,N) for (auto j: G[i]) {
            if (i < j) {
                que.push(i*N+j);
                length[i*N+j] = 1;
            }
        }

        while (!que.empty()) {
            int v = que.front();
            que.pop();
            int i = v / N;
            int j = v % N;
            for (auto nv: G_double[v]) {
                if (length[nv] == -1) {
                    int ni = nv / N;
                    int nj = nv % N;
                    for (auto c: edge_to_char[i*N+ni]) {
                        for (auto nc: edge_to_char[j*N+nj]) {
                            if (c == nc) {
                                goto found_match; // 辺の文字が一致した場合はスキップ
                            }
                        }
                    }
                    for (auto c: edge_to_char[i*N+nj]) {
                        for (auto nc: edge_to_char[j*N+ni]) {
                            if (c == nc) {
                                goto found_match; // 辺の文字が一致した場合はスキップ
                            }
                        }
                    }
                    continue; // 辺の文字が一致しない場合はスキップ
                    found_match:
                        length[nv] = length[v] + 2;
                        que.push(nv);
                }
            }
        }

        return;
    }

    // グラフGが木の時限定で、pathを2減らす次のnodeを返す
    int parent_node(int u, int v){
        if (!parent.empty()) {
            if (u > v) swap(u, v);
            return parent[u*N+v];
        }else{
            parent.resize(N*N+1,-1);
            
            dist.resize(N, vector<int>(N, 1e9));

            function<void(int,int,int,int)> dfs2 = [&](int v, int p, int d, int root) {
                for (auto nv: G[v]) {
                    if (nv == p) continue;
                    dist[root][nv] = min(dist[root][nv], d+1);
                    dfs2(nv, v, d+1, root);
                }
            };
            rep(i,N) {
                dfs2(i, -1, 0, i);
                dist[i][i] = 0; // 自分自身への距離は0
            }

            rep(i,N){
                parent[i*N+i] = N*N; // ルートの親はN*Nにしておく
            }

            rep(i,N) for (auto j: G[i]) {
                if (i < j) {
                    parent[i*N+j] = N*N; // ルートの親はN*Nにしておく
                    parent[j*N+i] = N*N; // ルートの親はN*Nにしておく
                }
            }

            rep(i,N) rep2(j,i+1,N){
                if (parent[i*N+j] == -1){
                    for (auto v: G_double[i*N+j]) {
                        int ni = v / N;
                        int nj = v % N;
                        if (dist[ni][nj] < dist[i][j]){
                            if (ni > nj) parent[i*N+j] = nj*N+ni;
                            else parent[i*N+j] = ni*N+nj;
                            break;
                        }
                    }
                }
            }

            if (u > v) swap(u, v);
            return parent[u*N+v];
        }
    }

    int get_length(int u, int v) {
        if (u > v) swap(u, v);
        return length[u*N+v];
    }

    int get_dist(int u, int v) {
        if (dist.empty()) return 0;
        if (u > v) swap(u, v);
        return dist[u][v];
    }
};


int main2() {
    cin(N);
    vector<vector<int>> G(N);
    vector<int> U(N-1), V(N-1);
    rep(i,N-1){
        cin2(a,b);
        a--; b--;
        G[a].push_back(b);
        G[b].push_back(a);
    }

    vector<vector<int>> A(N, vector<int>(N, 0));
    rep(i,N) {
        cins(s);
        rep(j,N) {
            if (s[j] == '1') {
                A[i][j] = 1;
            } else {
                A[i][j] = 0;
            }
        }
    }

    Graph_double graph_double(G);

    vector<vector<int>> A2(N, vector<int>(N, 0));

    rep(i,N) rep2(j,i+1,N) {
        if (A[i][j] == 0) continue;
        if (A2[i][j] == 1) continue;
        A2[i][j] = 1;
        A2[j][i] = 1;

        int v = i*N+j;
        while (v != N*N) {
            int next = graph_double.parent_node(v / N, v % N);
            if (next == N*N || next == -1) break; // ルートに到達
            int ni = next / N;
            int nj = next % N;
            if (A2[ni][nj] == 1) break; // すでに辺が存在する場合はスキップ
            A2[ni][nj] = 1;
            A2[nj][ni] = 1;
            v = next;
        }
    }

    WeightedUnionFind<ll> uf(N);
    rep(i,N){
        rep(j,N){
            if (A2[i][j] == 1){
                uf.merge(i,j,0);
            }
        }
    }

    vector<int> root(N,-1);
    rep(i,N){
        root[i] = uf.find(i);
    }

    //outvec(root);

    graph_double.palindorome_nodes(root);
    
    ll cnt = 0;
    rep(i,N){
        rep(j,N){
            if (graph_double.get_length(i,j) == graph_double.get_dist(i,j)) cnt++;
        }
    }
    cout << cnt << endl;
    
    return 0;
} 
