#include <bits/stdc++.h>

using namespace std;
using ll=long long;

// O(N)
void dfs(vector<vector<ll>> &G, vector<ll> &buka,ll v, ll p){
    buka[v] = 1;
    for (auto nv : G[v]){
        if (nv == p) continue;
        dfs(G,buka,nv,v);
        buka[v] += buka[nv];
    }
    return;
}