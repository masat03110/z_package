// verify: https://blog.tiramister.net/posts/acpc2020-day1-f/
// https://onlinejudge.u-aizu.ac.jp/challenges/sources/VPC/TUATPC/3198
#include <iostream>
#include <vector>
#include <queue>
#include <string>
#include <unordered_set>

struct HopcroftKarp{
    const int INF = 1e9+7;
    std::vector<std::vector<int>> Graph;
    std::vector<int> match, dist;
    int N, M;
    int now_matching = 0;
    int now_max_matching = 0;
    int now_edge = 0;

    void init(int n, int m){
        N = n;
        M = m;
        Graph.resize(n+m+2);
        match.resize(n+m+2, 0);
        dist.resize(n+m+2);
    }
    // u: 0-indexed, v: 0-indexed
    void add_edge(int u, int v){
        u++; v++;
        Graph[u].push_back(N+v);
        now_edge++;
    }
    // u: 0-indexed, v: 0-indexed
    void delete_edge(int u, int v){
        u++; v++;
        now_edge--;
        for(int i = 0; i < Graph[u].size(); i++){
            if(Graph[u][i] == N+v){
                Graph[u].erase(Graph[u].begin()+i);
                break;
            }
        }
        if (match[u] == N+v){
            match[u] = 0;
            match[N+v] = 0;
            now_matching--;
        }
    }
    bool bfs(int n){
        std::queue<int> que;
        for (int i = 1; i <= N; i++){
            if (match[i]) dist[i] = INF;
            else dist[i] = 0, que.emplace(i);
        }
        dist[0] = INF;
        while (!que.empty()){
            int u = que.front(); que.pop();
            if (!u) continue;
            for (int v : Graph[u]){
                if (dist[match[v]] == INF){
                    dist[match[v]] = dist[u] + 1, que.emplace(match[v]);
                }
            }
        }
        return dist[0] != INF;
    }
    bool dfs(int u){
        if (!u) return true;
        for (int v : Graph[u]){
            if (dist[match[v]] == dist[u] + 1 && dfs(match[v])){
                match[u] = v, match[v] = u;
                return true;
            }
        }
        dist[u] = INF;
        return false;
    }
    int matching_from_scratch(){
        int res = 0;
        while (bfs(N)){
            for (int i = 1; i <= N; i++){
                res += !match[i] && dfs(i);
            }
        }
        now_matching = res;
        now_max_matching = std::max(now_max_matching, now_matching);
        return res;
    }

    int matching_again(){
        while (bfs(N)){
            for (int i = 1; i <= N; i++){
                now_matching += !match[i] && dfs(i);
            }
        }
        now_max_matching = std::max(now_max_matching, now_matching);
        return now_matching;
    }

    int matching_again_if_maximized_is_bigger(){
        if (now_edge < now_max_matching) return 0;

        return matching_again();
    }
};

int main2() {
    int N,M; std::cin >> N >> M;

    HopcroftKarp hk;
    hk.init(N, M);

    std::unordered_set<long long> s;

    for (int i = 0; i < M; i++){
        int a,b; std::cin >> a >> b; a--; b--;
        hk.add_edge(a, b);
        s.insert((long long)a * (long long)N + (long long)b);
    }

    int Q; std::cin >> Q;

    hk.matching_from_scratch();

    for (int i = 0; i < Q; i++){
        int a,b; std::cin >> a >> b; a--; b--;
        if (s.find((long long)a * (long long)N + (long long)b) != s.end()){
            hk.delete_edge(a, b);
            s.erase((long long)a * (long long)N + (long long)b);
        }else{
            hk.add_edge(a, b);
            s.insert((long long)a * (long long)N + (long long)b);
        }
        if (hk.matching_again_if_maximized_is_bigger() == N){
            std::cout << "Yes" << std::endl;
        }else{
            std::cout << "No" << std::endl;
        }
    }
    
    return 0;
} 
