#include <bits/stdc++.h>

using namespace std;
using ll=long long;

struct Edge{
    int to;
    ll cap;
    int rev;
};

class FordFulkerson{
    private:
        vector<vector<Edge>> G;
        vector<bool> used;
        int N;
        ll dfs(int v, int t, ll f){
            if (v == t) return f;
            used[v] = true;
            for (int i=0;i<G[v].size();i++){
                Edge &e = G[v][i];
                if (!used[e.to] && e.cap > 0){
                    ll d = dfs(e.to, t, min(f, e.cap));
                    if (d > 0){
                        e.cap -= d;
                        G[e.to][e.rev].cap += d;
                        return d;
                    }
                }
            }
            return 0;
        }
    public:
        FordFulkerson(int n){
            N = n;
            G.resize(n);
            used.resize(n);
        }
        void add_edge(int from, int to, ll cap){
            G[from].push_back((Edge){to, cap, (int)G[to].size()});
            G[to].push_back((Edge){from, 0, (int)G[from].size()-1});
        }
        ll max_flow(int s, int t){
            ll flow = 0;
            while (true){
                for (int i=0;i<N;i++) used[i] = false;
                ll f = dfs(s, t, 1e18);
                if (f == 0) return flow;
                flow += f;
            }
        }
};

// O(EV^2) (E:辺の数, V:頂点の数)
// ギリギリでも通る

class Dinic_MaximFlow{
    private:
        struct Edge{
            int to;
            ll cap;
            int rev;
        };
        vector<vector<Edge>> G;
        vector<int> level;
        vector<int> iter;
        int N;
        void bfs(int s){
            for (int i=0;i<N;i++) level[i] = -1;
            queue<int> que;
            level[s] = 0;
            que.push(s);
            while(!que.empty()){
                int v = que.front(); que.pop();
                for (int i=0;i<G[v].size();i++){
                    Edge &e = G[v][i];
                    if (e.cap > 0 && level[e.to] < 0){
                        level[e.to] = level[v] + 1;
                        que.push(e.to);
                    }
                }
            }
        }
        ll dfs(int v, int t, ll f){
            if (v == t) return f;
            for (int &i=iter[v];i<G[v].size();i++){
                Edge &e = G[v][i];
                if (e.cap > 0 && level[v] < level[e.to]){
                    ll d = dfs(e.to, t, min(f, e.cap));
                    if (d > 0){
                        e.cap -= d;
                        G[e.to][e.rev].cap += d;
                        return d;
                    }
                }
            }
            return 0;
        }
    public:
        Dinic_MaximFlow(int n){
            N = n;
            G.resize(n);
            level.resize(n);
            iter.resize(n);
        }
        void add_edge(int from, int to, ll cap){
            G[from].push_back((Edge){to, cap, (int)G[to].size()});
            G[to].push_back((Edge){from, 0, (int)G[from].size()-1});
        }
        ll max_flow(int s, int t){
            ll flow = 0;
            while (true){
                bfs(s);
                if (level[t] < 0) return flow;
                for (int i=0;i<N;i++) iter[i] = 0;
                ll f;
                while ((f = dfs(s, t, 1e18)) > 0){
                    flow += f;
                }
            }
        }
};