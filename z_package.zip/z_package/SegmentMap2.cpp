#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
#define seg_RmaRmsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{(a[0]+b[0])%998244353ll,a[1]+b[1]};},[&](){return array<ll,2>{0,0};},array<ll,2>,[&](array<ll,2> m, array<ll,2> n){ return array<ll,2>{(m[0]*n[0]+m[1]*n[1])%998244353ll,n[1]};}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0]%998244353ll, (b[1]*a[0]+a[1])%998244353ll};},[&](){return array<ll,2>{1ll,0ll};}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
template<typename T, typename F> T bs(T l, T r, F f) { for(int i=0;i<100;i++){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}


namespace atcoder {

    namespace internal {

        #if __cplusplus >= 202002L
        
        using std::bit_ceil;
        
        #else
        
        // @return same with std::bit::bit_ceil
        unsigned int bit_ceil(unsigned int n) {
            unsigned int x = 1;
            while (x < (unsigned int)(n)) x *= 2;
            return x;
        }
        
        #endif
        
        // @param n `1 <= n`
        // @return same with std::bit::countr_zero
        int countr_zero(unsigned int n) {
        #ifdef _MSC_VER
            unsigned long index;
            _BitScanForward(&index, n);
            return index;
        #else
            return __builtin_ctz(n);
        #endif
        }
        
        // @param n `1 <= n`
        // @return same with std::bit::countr_zero
        constexpr int countr_zero_constexpr(unsigned int n) {
            int x = 0;
            while (!(n & (1 << x))) x++;
            return x;
        }
        
    }  // namespace internal
    
    template <class S, auto op, auto e> 
    struct segtree {
        static_assert(std::is_convertible_v<decltype(op), std::function<S(S, S)>>,
                      "op must work as S(S, S)");
        static_assert(std::is_convertible_v<decltype(e), std::function<S()>>,
                      "e must work as S()");
    
      public:
        segtree() : segtree(0) {}
        explicit segtree(int n) : segtree(std::vector<S>(n, e())) {}
        explicit segtree(const std::vector<S>& v) : _n(int(v.size())) {
            size = (int)internal::bit_ceil((unsigned int)(_n));
            log = internal::countr_zero((unsigned int)size);
            d = std::vector<S>(2 * size, e());
            for (int i = 0; i < _n; i++) d[size + i] = v[i];
            for (int i = size - 1; i >= 1; i--) {
                update(i);
            }
        }
    
        void set(int p, S x) {
            assert(0 <= p && p < _n);
            p += size;
            d[p] = x;
            for (int i = 1; i <= log; i++) update(p >> i);
        }
    
        S get(int p) const {
            assert(0 <= p && p < _n);
            return d[p + size];
        }
    
        S prod(int l, int r) const {
            assert(0 <= l && l <= r && r <= _n);
            S sml = e(), smr = e();
            l += size;
            r += size;
    
            while (l < r) {
                if (l & 1) sml = op(sml, d[l++]);
                if (r & 1) smr = op(d[--r], smr);
                l >>= 1;
                r >>= 1;
            }
            return op(sml, smr);
        }
    
        S all_prod() const { return d[1]; }
    
        template <bool (*f)(S)> int max_right(int l) const {
            return max_right(l, [](S x) { return f(x); });
        }
        template <class F> int max_right(int l, F f) const {
            assert(0 <= l && l <= _n);
            assert(f(e()));
            if (l == _n) return _n;
            l += size;
            S sm = e();
            do {
                while (l % 2 == 0) l >>= 1;
                if (!f(op(sm, d[l]))) {
                    while (l < size) {
                        l = (2 * l);
                        if (f(op(sm, d[l]))) {
                            sm = op(sm, d[l]);
                            l++;
                        }
                    }
                    return l - size;
                }
                sm = op(sm, d[l]);
                l++;
            } while ((l & -l) != l);
            return _n;
        }
    
        template <bool (*f)(S)> int min_left(int r) const {
            return min_left(r, [](S x) { return f(x); });
        }
        template <class F> int min_left(int r, F f) const {
            assert(0 <= r && r <= _n);
            assert(f(e()));
            if (r == 0) return 0;
            r += size;
            S sm = e();
            do {
                r--;
                while (r > 1 && (r % 2)) r >>= 1;
                if (!f(op(d[r], sm))) {
                    while (r < size) {
                        r = (2 * r + 1);
                        if (f(op(d[r], sm))) {
                            sm = op(d[r], sm);
                            r--;
                        }
                    }
                    return r + 1 - size;
                }
                sm = op(d[r], sm);
            } while ((r & -r) != r);
            return 0;
        }
    
      private:
        int _n, size, log;
        std::vector<S> d;
    
        void update(int k) { d[k] = op(d[2 * k], d[2 * k + 1]); }
    };

    template <class S,
          auto op,
          auto e,
          class F,
          auto mapping,
          auto composition,
          auto id>
    struct lazy_segtree {
        static_assert(std::is_convertible_v<decltype(op), std::function<S(S, S)>>,
                    "op must work as S(S, S)");
        static_assert(std::is_convertible_v<decltype(e), std::function<S()>>,
                    "e must work as S()");
        static_assert(
            std::is_convertible_v<decltype(mapping), std::function<S(F, S)>>,
            "mapping must work as S(F, S)");
        static_assert(
            std::is_convertible_v<decltype(composition), std::function<F(F, F)>>,
            "composition must work as F(F, F)");
        static_assert(std::is_convertible_v<decltype(id), std::function<F()>>,
                    "id must work as F()");

        public:
            lazy_segtree() : lazy_segtree(0) {}
            explicit lazy_segtree(int n) : lazy_segtree(std::vector<S>(n, e())) {}
            explicit lazy_segtree(const std::vector<S>& v) : _n(int(v.size())) {
                size = (int)internal::bit_ceil((unsigned int)(_n));
                log = internal::countr_zero((unsigned int)size);
                d = std::vector<S>(2 * size, e());
                lz = std::vector<F>(size, id());
                for (int i = 0; i < _n; i++) d[size + i] = v[i];
                for (int i = size - 1; i >= 1; i--) {
                    update(i);
                }
            }

            void set(int p, S x) {
                assert(0 <= p && p < _n);
                p += size;
                for (int i = log; i >= 1; i--) push(p >> i);
                d[p] = x;
                for (int i = 1; i <= log; i++) update(p >> i);
            }

            S get(int p) {
                assert(0 <= p && p < _n);
                p += size;
                for (int i = log; i >= 1; i--) push(p >> i);
                return d[p];
            }

            S prod(int l, int r) {
                assert(0 <= l && l <= r && r <= _n);
                if (l == r) return e();

                l += size;
                r += size;

                for (int i = log; i >= 1; i--) {
                    if (((l >> i) << i) != l) push(l >> i);
                    if (((r >> i) << i) != r) push((r - 1) >> i);
                }

                S sml = e(), smr = e();
                while (l < r) {
                    if (l & 1) sml = op(sml, d[l++]);
                    if (r & 1) smr = op(d[--r], smr);
                    l >>= 1;
                    r >>= 1;
                }

                return op(sml, smr);
            }

            S all_prod() { return d[1]; }

            void apply(int p, F f) {
                assert(0 <= p && p < _n);
                p += size;
                for (int i = log; i >= 1; i--) push(p >> i);
                d[p] = mapping(f, d[p]);
                for (int i = 1; i <= log; i++) update(p >> i);
            }
            void apply(int l, int r, F f) {
                assert(0 <= l && l <= r && r <= _n);
                if (l == r) return;

                l += size;
                r += size;

                for (int i = log; i >= 1; i--) {
                    if (((l >> i) << i) != l) push(l >> i);
                    if (((r >> i) << i) != r) push((r - 1) >> i);
                }

                {
                    int l2 = l, r2 = r;
                    while (l < r) {
                        if (l & 1) all_apply(l++, f);
                        if (r & 1) all_apply(--r, f);
                        l >>= 1;
                        r >>= 1;
                    }
                    l = l2;
                    r = r2;
                }

                for (int i = 1; i <= log; i++) {
                    if (((l >> i) << i) != l) update(l >> i);
                    if (((r >> i) << i) != r) update((r - 1) >> i);
                }
            }

            template <bool (*g)(S)> int max_right(int l) {
                return max_right(l, [](S x) { return g(x); });
            }
            template <class G> int max_right(int l, G g) {
                assert(0 <= l && l <= _n);
                assert(g(e()));
                if (l == _n) return _n;
                l += size;
                for (int i = log; i >= 1; i--) push(l >> i);
                S sm = e();
                do {
                    while (l % 2 == 0) l >>= 1;
                    if (!g(op(sm, d[l]))) {
                        while (l < size) {
                            push(l);
                            l = (2 * l);
                            if (g(op(sm, d[l]))) {
                                sm = op(sm, d[l]);
                                l++;
                            }
                        }
                        return l - size;
                    }
                    sm = op(sm, d[l]);
                    l++;
                } while ((l & -l) != l);
                return _n;
            }

            template <bool (*g)(S)> int min_left(int r) {
                return min_left(r, [](S x) { return g(x); });
            }
            template <class G> int min_left(int r, G g) {
                assert(0 <= r && r <= _n);
                assert(g(e()));
                if (r == 0) return 0;
                r += size;
                for (int i = log; i >= 1; i--) push((r - 1) >> i);
                S sm = e();
                do {
                    r--;
                    while (r > 1 && (r % 2)) r >>= 1;
                    if (!g(op(d[r], sm))) {
                        while (r < size) {
                            push(r);
                            r = (2 * r + 1);
                            if (g(op(d[r], sm))) {
                                sm = op(d[r], sm);
                                r--;
                            }
                        }
                        return r + 1 - size;
                    }
                    sm = op(d[r], sm);
                } while ((r & -r) != r);
                return 0;
            }

        private:
            int _n, size, log;
            std::vector<S> d;
            std::vector<F> lz;

            void update(int k) { d[k] = op(d[2 * k], d[2 * k + 1]); }
            void all_apply(int k, F f) {
                d[k] = mapping(f, d[k]);
                if (k < size) lz[k] = composition(f, lz[k]);
            }
            void push(int k) {
                all_apply(2 * k, lz[k]);
                all_apply(2 * k + 1, lz[k]);
                lz[k] = id();
            }
    };
}  // namespace atcoder


// Description: 区間をsetで管理するデータ構造(なお実装はmap)．各クエリO(log区間数)．
 
// #### attention! : [l, r] ( include r, not [l, r) )
class SegmentMap : public std::map<ll, ll> {
    private:
        bool flagToMergeAdjacentSegment;
        ll length = 0;
    public:
        // if merge [l, c] and [c+1, r], set flagToMergeAdjacentSegment to true
        SegmentMap(bool flagToMergeAdjacentSegment) :
            flagToMergeAdjacentSegment(flagToMergeAdjacentSegment) {}
        // __exist -> iterator pair(l, r) (contain p)
        // noexist -> map.end()
        auto get(ll p) const {
            auto it = upper_bound(p);
            if (it == begin() || (--it)->second < p) return end();
            return it;
        }
        // insert segment [l, r]
        void insert(ll l, ll r) {
            auto itl = upper_bound(l), itr = upper_bound(r + flagToMergeAdjacentSegment);
            if (itl != begin()) {
                if ((--itl)->second < l - flagToMergeAdjacentSegment) ++itl;
            }
            if (itl != itr) {
                l = std::min(l, itl->first);
                r = std::max(r, std::prev(itr)->second);
                for (auto it = itl; it != itr; ++it) {
                    length -= it->second - it->first + 1;
                }
                erase(itl, itr);
            }
            length += r - l + 1;
            (*this)[l] = r;
        }
        // remove segment [l, r]
        void remove(ll l, ll r) {
            auto itl = upper_bound(l), itr = upper_bound(r);
            if (itl != begin()) {
                if ((--itl)->second < l) ++itl;
            }
            if (itl == itr) return;
            ll tl = std::min(l, itl->first), tr = std::max(r, std::prev(itr)->second);
            for (auto it = itl; it != itr; ++it) {
                length -= it->second - it->first + 1;
            }
            erase(itl, itr);
            if (tl < l) {
                (*this)[tl] = l - 1;
                length += l - tl;
            }
            if (r < tr) {
                (*this)[r + 1] = tr;
                length += tr - r;
            }
        }
        // Is p and q in same segment?
        bool same(ll p, ll q) const {
            const auto&& it = get(p);
            return it != end() && it->first <= q && q <= it->second;
        }
        // return size of segments
        ll len_size() const {
            return length;
        }
        // return all segments
        vector<array<ll,2>> get_segments() const {
            vector<array<ll,2>> ret;
            for (auto [l,r]: *this) ret.push_back({l,r});
            return ret;
        }
        // return number of segments
        ll num_segments() const {
            return (*this).size();
        }
};


void solve(){
    cin(N);
    cinvec(A);
    SegmentMap seg(true);
    vector<array<ll,2>> ScoreTurn(N+1,{-1,0});
    ScoreTurn[0] = {0,0};
    rep(i,N){
        auto it = seg.get(A[i]);
        if (it == seg.end()){
            seg.insert(A[i],A[i]);
            ll num = seg.len_size();
            ScoreTurn[num] = {ScoreTurn[num-1][0]+i,i+1};
        }else{
            ll left = it->first;
            if (left == 1) continue;
            seg.insert(left-1,left-1);
            ll num = seg.len_size();
            ScoreTurn[num] = {ScoreTurn[num-1][0]+i,i+1};
        }
    }
    //rep(i,N+1) cout << ScoreTurn[i][0] << " " << ScoreTurn[i][1] << endl;
    //cout << endl;
    SegmentMap seg2(true);
    auto B = A;
    reverse(B.begin(),B.end());
    vector<array<ll,2>> ScoreTurn2(N+1,{-1,0});
    ScoreTurn2[0] = {0,0};
    rep(i,N){
        auto it = seg2.get(B[i]);
        if (it == seg2.end()){
            seg2.insert(B[i],B[i]);
            ll num = seg2.len_size();
            ScoreTurn2[num] = {ScoreTurn2[num-1][0]+i,i+1};
        }else{
            ll left = it->first;
            if (left == 1) continue;
            seg2.insert(left-1,left-1);
            ll num = seg2.len_size();
            ScoreTurn2[num] = {ScoreTurn2[num-1][0]+i,i+1};
        }
    }
    //rep(i,N+1) cout << ScoreTurn2[i][0] << " " << ScoreTurn2[i][1] << endl;
    //cout << endl;

    ll ans = 0;

    rep2(i,1,N+1){
        if (ScoreTurn[i][0] == -1 || ScoreTurn2[i][0] == -1) continue;
        if (ScoreTurn[i][1] + ScoreTurn2[i][1] > N){
            continue;
        }
        ans = max(ans,(N-1)*i-ScoreTurn[i][0]-ScoreTurn2[i][0]);
    }

    cout << ans << endl;
    
}

int main(){

    ios::sync_with_stdio(false);
    cin.tie(0);

    cin(T);
    rep(i,T) solve();

}
