#include "bits/stdc++.h"

using namespace std;
using ll=long long;

#define rep(i,n) for (ll i=0;i<(n);i++)

// Reconstruction of Euler Tour
// O(V+E)

struct EulerTour{
    vector<int>name;
    vector<vector<ll>> G_ret;

    EulerTour(const vector<vector<ll>>& G){
        rep(i,G.size()){
            sort(G[i].begin(),G[i].end());
        }
        dfs(0,-1,G);

        G_ret.resize(name.size());
        rep(i,name.size()){
            G_ret[i] = G[name[i]];
        }
    }

    void dfs(int crr,int pre, const vector<vector<ll>>& G){
        name.push_back(crr);
        for(int nxt:G[crr])if(nxt!=pre){
            dfs(nxt,crr, G);
        }
    }
};