#include <bits/stdc++.h>
using namespace std;

/*
	Rankのみバージョン(+rangefreq)
*/
typedef unsigned int u32;
inline int popcount_(u32 x) {
	x = x - ((x >> 1) & 0x55555555); 
	x = (x & 0x33333333) + ((x >> 2) & 0x33333333);
	return ((x + (x >> 4) & 0xF0F0F0F) * 0x1010101) >> 24;
}

struct RankDictionary {
	static const int NOTFOUND = -1;
	int length, blockslength, count;
	vector<u32> blocks; vector<int> ranktable;
	RankDictionary(int len): length(len) {
		blocks.resize((blockslength = (len + 31) / 32) + 1);
	}
	inline void set(int i) { blocks[i / 32] |= 1 << i % 32; }
	void build() {
		if(length == 0) { count = 0; return; }
		ranktable.assign(blockslength + 1, 0);
		int prev0 = 0, prev1 = 0, count0 = 0, count1 = 0;
		for(int i = 0; i < blockslength; i ++) {
			ranktable[i] = count1;
			count1 += popcount_(blocks[i]);
			count0 = 32 * (i + 1) - count1;
		}
		ranktable[blockslength] = count1;
		count = count1;
	}
	inline int rank(int pos) const {	//[0..pos)の1の個数
		int block_idx = pos / 32;
		return ranktable[block_idx] + popcount_(blocks[block_idx] & (1U << pos % 32)-1);
	}
	inline int rank(bool b, int pos) const { return b ? rank(pos) : pos - rank(pos); }
	inline int rank(bool b, int left, int right) const { return rank(b, right) - rank(b, left); }
};

inline unsigned int BITMASK(int i) {
	return (1 << i) - 1;
}
struct WaveletMatrix {
	typedef unsigned int Val;
	int length, bitsize; Val maxval;
	vector<RankDictionary> dicts;
	vector<int> mids;
	void init(const vector<Val>& data) {
		length = data.size();
		maxval = *max_element(data.begin(), data.end());
		if(Val(1) << (8 * sizeof(Val) - 1) <= maxval) bitsize = 8 * sizeof(Val);
		else for(bitsize = 0; Val(1) << bitsize <= maxval; bitsize ++) ;
		dicts.assign(bitsize, length);
		mids.assign(bitsize, 0);
		vector<Val> datacurrent(data), datanext(length);
		for(int bit = 0; bit < bitsize; bit ++) {
			int pos = 0;
			for(int i = 0; i < length; i ++)
				if((datacurrent[i] >> (bitsize - bit - 1) & 1) == 0)
					datanext[pos ++] = datacurrent[i];
			mids[bit] = pos;
			for(int i = 0; i < length; i ++)
				if((datacurrent[i] >> (bitsize - bit - 1) & 1) != 0)
					dicts[bit].set(i), datanext[pos ++] = datacurrent[i];
			dicts[bit].build();
			datacurrent.swap(datanext);
		}
	}
	int rank_all(Val val, int left, int right, int& out_lt, int& out_gt) const {
		if(val > maxval) { out_lt = right - left; out_gt = 0; return 0; }
		out_lt = out_gt = 0;
		for(int bit = 0; bit < bitsize; bit ++) {
			bool dir = val >> (bitsize - bit - 1) & 1;
			int leftcount = dicts[bit].rank(dir, left), rightcount = dicts[bit].rank(dir, right);
			(dir ? out_lt : out_gt) += (right - left) - (rightcount - leftcount);
			left = leftcount, right = rightcount;
			if(dir) left += mids[bit], right += mids[bit];
		}
		return right - left;
	}
	inline int rank_lt(Val val, int left, int right) const {
		if(val > maxval) { return right - left; }
		int lt = 0;
		for(int bit = 0; bit < bitsize; bit ++) {
			bool dir = val >> (bitsize - bit - 1) & 1;
			int leftcount = dicts[bit].rank(dir, left), rightcount = dicts[bit].rank(dir, right);
			if(dir) lt += (right - left) - (rightcount - leftcount);
			left = leftcount, right = rightcount;
			if(dir) left += mids[bit], right += mids[bit];
		}
		return lt;
	}
	inline int rank_ge(Val val, int left, int right) const {
		if(val > maxval) { return 0; }
		int ge = 0;
		for(int bit = 0; bit < bitsize; bit ++) {
			bool dir = val >> (bitsize - bit - 1) & 1;
			int leftcount = dicts[bit].rank(dir, left), rightcount = dicts[bit].rank(dir, right);
			if(!dir) ge += (right - left) - (rightcount - leftcount);
			left = leftcount, right = rightcount;
			if(dir) left += mids[bit], right += mids[bit];
		}
		return ge + (right - left);
	}
	inline int rangefreq(int left, int right, Val bottom, Val up) {
		return rank_lt(up, left, right) - rank_lt(bottom, left, right);
	}
};

int main2() {
    int N, Q; scanf("%d %d", &N, &Q);
    vector<unsigned int> A(N);
    for(int i = 0; i < N; i ++) scanf("%u", &A[i]);
    WaveletMatrix wm; wm.init(A);
    for(int i = 0; i < Q; i ++) {
        int l, r; unsigned int k; scanf("%d %d %u", &l, &r, &k);
        printf("%d\n", wm.rangefreq(l, r, k, -1));
    }
    return 0;
}