#include <bits/stdc++.h>

using namespace std;
using ll=long long;

bool check(ll mid){
    // write here
}
int main2(){

//  (l,r]
    ll l = -1;
    ll r = 1e9;

    while(r-l > 1){
        ll mid = (l+r+1)/2;
        if (check(mid)) r = mid;
        else l = mid;
    }

// [l,r)
    ll l = 0;
    ll r = 1e9+1;

    while(r-l > 1){
        ll mid = (l+r)/2;
        if (check(mid)) l = mid;
        else r = mid;
    }

    return 0;
}