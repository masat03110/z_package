#include <bits/stdc++.h>
#include <atcoder/all>
using namespace std;
using ll = long long;
using ld = long double;

// https://atcoder.jp/contests/abc014/tasks/abc014_4

struct LCA_seg{
    public: 
    vector<vector<int>> G;
    vector<int> EulerTour;
    vector<int> EulerTour_id;
    vector<int> depth;
    atcoder::segtree<array<ll,2>, [](array<ll,2> a, array<ll,2> b){return a[0] < b[0] ? a:b;}, [](){return array<ll,2>{(ll)1e9,-1};} > seg;

    void dfs_e(int now, int par, int d){
        depth[now] = d;
        for(auto next: G[now]){
            if(next == par) continue;
            EulerTour.push_back(next);
            dfs_e(next, now, d+1);
            EulerTour.push_back(now);
        }
        return;
    }

    LCA_seg(vector<vector<int>> _G): seg(_G.size()*2), G(_G), depth(_G.size(),1e9) , EulerTour_id(_G.size(),-1), EulerTour(){
        EulerTour.push_back(0);
        dfs_e(0, -1, 0);

        for(int i=0; i<EulerTour.size(); i++){
            if (EulerTour_id[EulerTour[i]] == -1) EulerTour_id[EulerTour[i]] = i;
            seg.set(i, {depth[EulerTour[i]],i});
            assert(depth[EulerTour[i]] != 1e9);
        }
    }

    int get_LCA(int u, int v){
        int l = EulerTour_id[u];
        int r = EulerTour_id[v];
        if(l > r) swap(l,r);
        return EulerTour[seg.prod(l,r+1)[1]];
    }

    int get_dist(int u, int v){
        return depth[u] + depth[v] - 2*depth[get_LCA(u,v)];
    }
};

int main2(){
    int N; cin >> N;
    vector<vector<int>> G(N);

    for(int i=0; i<N-1; i++){
        int a, b; cin >> a >> b;
        a--; b--;
        G[a].push_back(b);
        G[b].push_back(a);
    }

    LCA_seg lca(G);

    int Q; cin >> Q;
    for(int i=0; i<Q; i++){
        int a, b; cin >> a >> b;
        a--; b--;
        cout << lca.get_dist(a,b)+1 << endl;
    }
    return 0;
}
