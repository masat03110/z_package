#include <bits/stdc++.h>

using namespace std;
using ll=long long;
using ld=long double;
#define yes {cout << "Yes" << endl; return 0;}
#define no {cout << "No" << endl; return 0;}
#define rep(i,n) for (ll i=0;i<(n);i++)
#define rep2(i,a,b) for (ll i=(a);i<(b);i++)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];

// 転倒数を求めるコード
//change mono and func
struct mono{
        ll val=0;
        ll index=-1;
};

struct mono_apply{
        ll mul=1;
        ll add=0;
};

mono func(mono a, mono b){
    if (a.val >= b.val) return a;
    else return b;
}

struct SegmentTree{
    int n;
    vector<mono> node;
    
    SegmentTree(vector<mono> v){
        int sz = v.size();
        n = 1; while(n < sz) n *= 2;
        node.resize(2*n-1,mono());
    
        for (int i=0;i<sz;i++){
        node[i+n-1] = v[i];
        }
        for (int i=n-2;i>=0;i--) node[i] = func(node[i*2+1],node[i*2+2]);
    }
    
    void update(int x, mono_apply apply){
        x += (n - 1);
        // change here
        node[x] = mono{node[x].val*apply.mul+apply.add,node[x].index};
        // until here
        while(x > 0){
        x = (x - 1) / 2;
        node[x] = func(node[2*x+1],node[2*x+2]);
        }
    }
    
    mono get(int a, int b, int k=0, int l=0, int r=-1){
        if (r < 0) r = n;
        if (r <= a || b <= l) return mono();
        if (a <= l && r <= b) return node[k];
        mono vl = get(a,b,2*k+1,l,(l+r)/2);
        mono vr = get(a,b,2*k+2,(l+r)/2,r);
        return func(vl,vr);
    }
};