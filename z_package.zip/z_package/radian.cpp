#include <bits/stdc++.h>

// typical90 009

// O(1)
// 0-360
long double calculateAngle(double x, double y) {
    // atan2関数を使用して(x, y)の偏角を求める
    // 結果は[-pi, pi]の範囲
    long double angle = std::atan2(y, x);

    // ラジアンを度に変換
    angle = angle * 180.0 / M_PI;

    if (angle < 0.0) angle = angle + 360.0;

    // 0-360;
    return angle;
}