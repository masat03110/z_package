#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
template<typename T, typename F> T bs(T l, T r, F f) { for(int i=0;i<100;i++){T m = (l+r)/2; if (f(m)) r = m; else l = m;} return r; } // 始めてtrueとなるのを、[l,r)で求める
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}


namespace rklib {

template <char cmin = 'a', char cmax = 'z', size_t step = 1>
struct BurrowsWheelerTransform {
   public:
    BurrowsWheelerTransform(std::string &s) : n(s.size() + 1) {
        std::vector<int> v(s.size());
        for (size_t i = 0; i < s.size(); i++) {
            v[i] = (s[i] - cmin) + 1;
        }
        sa = atcoder::suffix_array(v);
        v.push_back(0);
        sa.insert(sa.begin(), n - 1);
        bwt.resize(n);
        for (size_t i = 0; i < n; ++i) {
            bwt[i] = (sa[i] == 0 ? v[n - 1] : v[sa[i] - 1]);
        }

        cnt_smaller.resize(cnum, 0);
        cnt.resize(cnum);
        for (size_t c = 0; c < cnum; ++c) cnt[c].resize((n + 1) / step + 1, 0);
        std::vector<int> table(cnum, 0);
        for (size_t i = 0; i < n; ++i) {
            if (bwt[i] + 1 < (int)cnum) ++cnt_smaller[bwt[i] + 1];
            ++table[bwt[i]];
            if ((i + 1) % step == 0) {
                for (size_t c = 0; c < cnum; ++c)
                    cnt[c][(i + 1) / step] = table[c];
            }
        }
        std::partial_sum(cnt_smaller.begin(), cnt_smaller.end(),
                         cnt_smaller.begin());
    }

    std::pair<int, int> fm_index(std::string &s) {
        int l = 0, r = n;
        for (int i = (int)s.size() - 1; i >= 0; --i) {
            int c = (s[i] - cmin) + 1;
            l = cnt_smaller[c] + get_cnt(c, l);
            r = cnt_smaller[c] + get_cnt(c, r);
        }
        return {l, r};
    }

    std::vector<int> find_all(std::string &s) {
        auto [l, r] = fm_index(s);
        std::vector<int> res(sa.begin() + l, sa.begin() + r);
        std::sort(res.begin(), res.end());
        return res;
    }

    bool contains(std::string &s) {
        auto [l, r] = fm_index(s);
        return r - l > 0;
    }

   private:
    const size_t cnum = (cmax - cmin) + 2;
    size_t n;
    std::vector<int> bwt, cnt_smaller, sa;
    std::vector<std::vector<int>> cnt;

    int get_cnt(int c, int k) {
        int ret = cnt[c][k / step];
        for (int i = k / step * step; i < k; ++i) ret += (bwt[i] == c);
        return ret;
    }
};

template <char cmin = 'a', char cmax = 'z'>
struct BurrowsWheelerTransformBitVector {
   public:
    BurrowsWheelerTransformBitVector(std::string &s) : n(s.size() + 1) {
        std::vector<int> v(s.size());
        for (size_t i = 0; i < s.size(); i++) {
            v[i] = (s[i] - cmin) + 1;
        }
        sa = atcoder::suffix_array(v);
        v.push_back(0);
        sa.insert(sa.begin(), n - 1);
        bwt.resize(n);
        for (size_t i = 0; i < n; ++i) {
            bwt[i] = (sa[i] == 0 ? v[n - 1] : v[sa[i] - 1]);
        }

        vs.resize(cnum);
        for (size_t c = 1; c < cnum; c++) {
            std::vector<int> b(n, 0);
            for (size_t i = 0; i < n; i++) {
                if (bwt[i] == int(c)) b[i] = 1;
            }
            vs[c] = {b};
        }

        cnt_smaller.resize(cnum, 0);
        for (size_t i = 0; i < n; ++i) {
            if (bwt[i] + 1 < (int)cnum) ++cnt_smaller[bwt[i] + 1];
        }
        std::partial_sum(cnt_smaller.begin(), cnt_smaller.end(),
                         cnt_smaller.begin());
    }

    std::pair<int, int> fm_index(std::string &s) {
        int l = 0, r = n;
        for (int i = (int)s.size() - 1; i >= 0; --i) {
            int c = (s[i] - cmin) + 1;
            l = cnt_smaller[c] + vs[c].rank(l, 1);
            r = cnt_smaller[c] + vs[c].rank(r, 1);
        }
        return {l, r};
    }

    std::vector<int> find_all(std::string &s) {
        auto [l, r] = fm_index(s);
        std::vector<int> res(sa.begin() + l, sa.begin() + r);
        std::sort(res.begin(), res.end());
        return res;
    }

    bool contains(std::string &s) {
        auto [l, r] = fm_index(s);
        return r - l > 0;
    }

   private:
    const size_t cnum = (cmax - cmin) + 2;
    size_t n;
    std::vector<int> bwt, cnt_smaller, sa;
    std::vector<BitVector<int>> vs;
};

}  // namespace rklib

int main2() {
  string s;
  cin >> s;
  rklib::BurrowsWheelerTransform<> bwt(s);

  int q;
  cin >> q;
  rep(_, q) {
    string t;
    cin >> t;
    auto [l, r] = bwt.fm_index(t);
    cout << r - l << "\n";
  }
}