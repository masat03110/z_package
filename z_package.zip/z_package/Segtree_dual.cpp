#include <bits/stdc++.h>

using namespace std;

using ll=long long;
using ld=long double;
using Pair=array<ll,2>;
#define rep(i,n) for (ll i=0;i<(n);i++)
#define rep2(i,a,b) for (ll i=(a);i<(b);i++)
#define repd(i,a,b) for (ll i=(a);i>=(b);i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}

struct mono_lazy1{
    multiset<Pair> lazy = {};
};

void upd(mono_lazy1& a, mono_lazy1& b){
    for (auto x : b.lazy) {
        if (x[0] < 0){
            a.lazy.erase({-x[0],x[1]});
        }else{
            a.lazy.insert({x[0],x[1]});
        }
    }
}

struct mono1{
    ll val=0;
};

void func(mono1& a, mono_lazy1& b){
    //assert(b.lazy.size()>0);
    if (b.lazy.size() == 0){
        return;
    }
    auto res = *(b.lazy.rbegin());
    a.val = max(a.val,res[0]);
}

class segtree_dual{
public:
	vector<mono_lazy1> data;
	int n;

	segtree_dual(int _n){
		n=_n;
		data.resize(2*n);
	}

	void eval(int p,mono_lazy1 b){
		upd(data[p],b);
	}

	void update(int l,int r,mono_lazy1 b){
		for(l+=n,r+=n;l!=r;l=(l+1)>>1,r>>=1){
			if(l&1)eval(l,b);
			if(r&1)eval(r-1,b);
		}
	}

	mono1 get(int i){
		mono1 ans = mono1();
		for(i+=n;i;i>>=1){
            func(ans,data[i]);
		}
		return ans;
	}
};


int main2(){
	int n;
	cin >> n;
	segtree_dual seg(n);
	rep(i,n){
		int a;
		cin >> a;
        multiset<Pair> b;
        b.insert({a,0});
		seg.update(i,i+1,mono_lazy1{b});
	}

	int q;
	cin >> q;
	vector<array<int,3>>query(q+1);
	for(int i=1;i<=q;i++){
		int t;
		cin >> t;
		if(t==1){
			int l,r,val;
			cin >> l >> r >> val;
			l--;
            multiset<Pair> b;
            b.insert({val,i});
			seg.update(l,r,mono_lazy1{b});
			query[i]={l,r,val};
		}else if(t==2){
			int ii;
			cin >> ii;
            multiset<Pair> b;
            b.insert({-query[ii][2],ii});
			seg.update(query[ii][0],query[ii][1],mono_lazy1{b});
		}else{
			int ii;
			cin >> ii;
			cout << seg.get(ii-1).val << endl;
		}
	}
}