//https://atcoder.jp/contests/arc196/tasks/arc196_a

#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}

/** structure: 2-3 tree
 * available for both set and multiple set (see constructor)
 * every method works in O(logn)
 * tests: { https://judge.yosupo.jp/submission/105334,
 *          https://atcoder.jp/contests/abc241/submissions/35040063
 *        }
 *
 * コンストラクタの引数にtrueを入れることでmultisetに
 * insert.erase,lower_bound,upper_bound(配列番号),size,count,[]
 */

 template <class T>
 class twothreetree {
    private:
     struct node {
         node *parent = nullptr;
         unsigned char position;
         unsigned char n = 0;
         unsigned size = 0;
         T keys[2];
         node *children[3] = {nullptr, nullptr, nullptr};
         node() {}
 
         unsigned char LB(T key) {
             for(unsigned char i = 0; i < n; i++)
                 if(key <= keys[i]) return i;
             return n;
         }
 
         unsigned char UB(T key) {
             for(unsigned char i = 0; i < n; i++)
                 if(key < keys[i]) return i;
             return n;
         }
 
         void insert(unsigned char i, T key, node *child = nullptr) {
             if(n < 2) {
                 if(i == 0) {
                     keys[1] = keys[0];
                     children[2] = children[1];
                 }
                 keys[i] = key;
                 children[i + 1] = child;
                 n++;
                 coordinate();
                 if(parent == nullptr) return;
                 parent->sizeIncrement();
                 return;
             }
             node *newNode = new node();
             T newKey;
             if(i == 0) {
                 newNode->keys[0] = keys[1];
                 newNode->children[0] = children[1];
                 newNode->children[1] = children[2];
                 newKey = keys[0];
                 keys[0] = key;
                 children[1] = child;
             } else if(i == 1) {
                 newNode->keys[0] = keys[1];
                 newNode->children[0] = child;
                 newNode->children[1] = children[2];
                 newKey = key;
             } else {
                 newNode->keys[0] = key;
                 newNode->children[0] = children[2];
                 newNode->children[1] = child;
                 newKey = keys[1];
             }
             children[2] = nullptr;
             newNode->n = 1;
             n = 1;
             newNode->coordinate();
             coordinate();
             if(parent == nullptr) {
                 node *newRoot = new node();
                 newRoot->keys[0] = newKey;
                 newRoot->children[0] = this;
                 newRoot->children[1] = newNode;
                 newRoot->n = 1;
                 newRoot->coordinate();
                 return;
             }
             parent->insert(position, newKey, newNode);
         }
 
         void erase(unsigned char i) {
             delete children[i + 1];
             children[i + 1] = nullptr;
             if(n == 2) {
                 if(i == 0) {
                     keys[0] = keys[1];
                     children[1] = children[2];
                     children[2] = nullptr;
                 }
                 n--;
                 this->coordinate();
                 if(parent == nullptr) return;
                 parent->sizeDecrement();
                 return;
             }
             if(parent == nullptr) {
                 n--;
                 size--;
                 return;
             }
             if(position > 0) {
                 node *leftNode = parent->children[position - 1];
                 if(leftNode->n == 2) {
                     keys[0] = parent->keys[position - 1];
                     parent->keys[position - 1] = leftNode->keys[1];
                     children[1] = children[0];
                     children[0] = leftNode->children[2];
                     leftNode->children[2] = nullptr;
                     leftNode->n = 1;
                     n = 1;
                     leftNode->coordinate();
                     coordinate();
                     if(parent == nullptr) return;
                     parent->sizeDecrement();
                     return;
                 }
 
                 leftNode->keys[1] = parent->keys[position - 1];
                 leftNode->children[2] = children[0];
                 leftNode->n = 2;
                 leftNode->coordinate();
                 parent->erase(position - 1);
                 return;
             }
             node *rightNode = parent->children[1];
             if(rightNode->n == 2) {
                 keys[0] = parent->keys[0];
                 parent->keys[0] = rightNode->keys[0];
                 children[1] = rightNode->children[0];
                 rightNode->keys[0] = rightNode->keys[1];
                 rightNode->children[0] = rightNode->children[1];
                 rightNode->children[1] = rightNode->children[2];
                 rightNode->children[2] = nullptr;
                 rightNode->n = 1;
                 n = 1;
                 rightNode->coordinate();
                 coordinate();
                 if(parent == nullptr) return;
                 parent->sizeDecrement();
                 return;
             }
             rightNode->keys[1] = rightNode->keys[0];
             rightNode->keys[0] = parent->keys[position];
             rightNode->children[2] = rightNode->children[1];
             rightNode->children[1] = rightNode->children[0];
             rightNode->children[0] = children[0];
             rightNode->n = 2;
             rightNode->coordinate();
             parent->children[0] = rightNode;
             parent->children[1] = this;
             rightNode->position = 0;
             parent->erase(0);
         }
 
         void sizeIncrement() {
             size++;
             if(parent != nullptr) parent->sizeIncrement();
         }
 
         void sizeDecrement() {
             size--;
             if(parent != nullptr) parent->sizeDecrement();
         }
 
         void coordinate() {
             size = n;
             if(children[0] == nullptr) return;
             for(unsigned char i = 0; i <= n; i++) {
                 size += children[i]->size;
                 children[i]->parent = this;
                 children[i]->position = i;
             }
         }
     };
     node *root;
     bool isForMulti;
 
    public:
     /** if argument is true, works as multiple set.default is set.*/
     twothreetree(bool forMultiSet = false) {
         root = new node();
         isForMulti = forMultiSet;
     }
     /** returns index.*/
     unsigned lower_bound(T key) {
         node *presentNode = root;
         unsigned res = 0;
         while(presentNode->children[0] != nullptr) {
             unsigned char i = presentNode->LB(key);
             for(unsigned char j = 0; j < i; j++)
                 res += presentNode->children[j]->size;
             res += i;
             presentNode = presentNode->children[i];
         }
         return res + presentNode->LB(key);
     }
     /** returns index.*/
     unsigned upper_bound(T key) {
         node *presentNode = root;
         unsigned res = 0;
         while(presentNode->children[0] != nullptr) {
             unsigned char i = presentNode->UB(key);
             for(unsigned char j = 0; j < i; j++)
                 res += presentNode->children[j]->size;
             res += i;
             presentNode = presentNode->children[i];
         }
         return res + presentNode->UB(key);
     }
 
     bool insert(T key) {
         node *presentNode = root;
         unsigned char i;
         while(presentNode->children[0] != nullptr) {
             i = presentNode->LB(key);
             if(!isForMulti && i < presentNode->n && presentNode->keys[i] == key)
                 return false;
             presentNode = presentNode->children[i];
         }
         i = presentNode->LB(key);
         if(!isForMulti && i < presentNode->n && presentNode->keys[i] == key)
             return false;
         presentNode->insert(i, key);
         if(root->parent != nullptr) {
             root = root->parent;
         }
         return true;
     }
 
     bool erase(T key) {
         node *presentNode = root;
         unsigned char i;
         while(presentNode->children[0] != nullptr) {
             i = presentNode->LB(key);
             if(i < presentNode->n && presentNode->keys[i] == key) break;
             presentNode = presentNode->children[i];
         }
         if(presentNode->children[0] == nullptr) {
             i = presentNode->LB(key);
             if(i < presentNode->n && presentNode->keys[i] == key) {
                 presentNode->erase(i);
                 if(root->n == 0 && root->children[0] != nullptr) {
                     root = root->children[0];
                     delete root->parent;
                     root->parent = nullptr;
                 }
                 return true;
             }
             return false;
         }
         node *eraseNode = presentNode->children[i + 1];
         while(eraseNode->children[0] != nullptr)
             eraseNode = eraseNode->children[0];
         presentNode->keys[i] = eraseNode->keys[0];
         eraseNode->erase(0);
         if(root->n == 0) {
             root = root->children[0];
             delete root->parent;
             root->parent = nullptr;
         }
         return true;
     }
 
     T get(unsigned i) {
         if(i < 0) i += root->size;
         node *presentNode = root;
         while(presentNode->children[0] != nullptr) {
             unsigned char j = 0;
             while(i >= presentNode->children[j]->size + 1) {
                 i -= presentNode->children[j]->size + 1;
                 j++;
             }
             if(i == presentNode->children[j]->size) {
                 return presentNode->keys[j];
             }
             presentNode = presentNode->children[j];
         }
         return presentNode->keys[i];
     }
 
     unsigned size() {
         return root->size;
     }
 
     unsigned count(T key) {
         return upper_bound(key) - lower_bound(key);
     }
 
     T operator[](unsigned i) {
         return get(i);
     }
 };
 
 
// 遅延セグ木と同じ
// <monoid, monoidに対する演算, 単位元, 遅延作用素, 遅延作用素の、monoidに対する演算, 遅延作用素同士のまとめ演算, 遅延作用素の単位元>
// ImplicitTreap<int,op,e,int,op,op,e> tr;

// 可能なこと
// insert(pos,val): valをposの場所に追加する O(log N)
// erase(pos): posにある要素を消す O(log N)
// size(): サイズを返す
// operator[](pos): posの要素を返す
// prod(l,r): [l,r)の区間 O(log N)
// apply(l,r,x): [l,r)の区間にxを適用する
// reverse(l,r): [l,r)の区間を反転する
// rotate(l,m,r): [l,m)と[m,r)を、[m,r)と[l,m)に入れ替える]
// dump(): 中身を出力する

template<class T,T(*op)(T,T),T(*e)(),class F,T(*mapping)(F f,T x),F(*composition)(F f,F g),F(*id)()>
class ImplicitTreap{
    struct Node{
        T val,acc=e();
        int priority;
        int cnt=1;
        F lazy=id();
        bool rev=false;
        Node *l, *r;
        Node(T val,int priority):val(val),priority(priority),l(nullptr),r(nullptr){};
    }
    *root=nullptr;
    using Tree=Node *;

    int cnt(Tree t) {
        return t ? t->cnt : 0;
    }

    T acc(Tree t){
        return t ? t->acc : e();
    }

    void update(Tree t){
        if(t){
            t->cnt=1+cnt(t->l)+cnt(t->r);
            t->acc=op(t->val,op(acc(t->l),acc(t->r)));
        }
    }

    void pushdown(Tree t){
        if(t && t->rev){
            t->rev=false;
            std::swap(t->l,t->r);
            if(t->l)t->l->rev^=1;
            if(t->r)t->r->rev^=1;
        }
        if(t && t->lazy!=id()){
            if(t->l){
                t->l->lazy=composition(t->l->lazy,t->lazy);
                t->l->acc=mapping(t->lazy,t->l->acc);
            }
            if(t->r){
                t->r->lazy=composition(t->r->lazy,t->lazy);
                t->r->acc=mapping(t->lazy,t->r->acc);
            }
            t->val=mapping(t->lazy,t->val);
            t->lazy=id();
        }
        update(t);
    }

    void split(Tree t, int key, Tree& l,Tree& r){
        if(!t){
            l=r=nullptr;
            return;
        }
        pushdown(t);
        int implicit_key=cnt(t->l)+1;
        if(key<implicit_key){
            split(t->l,key,l,t->l),r=t;
        }else{
            split(t->r,key-implicit_key,t->r,r),l=t;
        }
        update(t);
    }

    void insert(Tree& t,int key,Tree item){
        Tree t1,t2;
        split(t,key,t1,t2);
        merge(t1,t1,item);
        merge(t,t1,t2);
    }

    void merge(Tree& t, Tree l, Tree r){
        pushdown(l);
        pushdown(r);
        if(!l || !r){
            t=l?l:r;
        }else if(l->priority>r->priority){
            merge(l->r,l->r,r),t=l;
        }else{
            merge(r->l,l,r->l),t=r;
        }
        update(t);
    }

    void erase(Tree& t,int key){
        Tree t1,t2,t3;
        split(t,key+1,t1,t2);
        split(t1,key,t1,t3);
        merge(t,t1,t2);
    }

    T prod(Tree t,int l,int r){
        Tree t1,t2,t3;
        split(t,l,t1,t2);
        split(t2,r-l,t2,t3);
        T ret=t2->acc;
        merge(t2,t2,t3);
        merge(t,t1,t2);
        return ret;
    }

    void apply(Tree t,int l,int r,F x){
        Tree t1,t2,t3;
        split(t,l,t1,t2);
        split(t2,r-l,t2,t3);
        t2->lazy=composition(t2->lazy,x);
        t2->acc=mapping(x,t2->acc);
        merge(t2,t2,t3);
        merge(t,t1,t2);
    }

    void reverse(Tree t,int l,int r){
        if(l>r)return;
        Tree t1,t2,t3;
        split(t,l,t1,t2);
        split(t2,r-l,t2,t3);
        t2->rev^=1;
        merge(t2,t2,t3);
        merge(t,t1,t2);
    }

    void rotate(Tree t,int l,int m,int r){
        reverse(t,l,r);
        reverse(t,l,l+r-m);
        reverse(t,l+r-m,r);
    }

    void dump(Tree t) {
        if (!t) return;
        pushdown(t);
        dump(t->l);
        std::cout << t->val << " ";
        dump(t->r);
    }

public:
    ImplicitTreap() {}
    ImplicitTreap(std::vector<T> as){
        std::reverse(as.begin(),as.end());
        for(T a:as){
            insert(0,a);
        }
    }

    void insert(int pos,T val){
        //valをposの場所に追加する O(log N)
        insert(root,pos,new Node(val,rand()));
    }

    void erase(T pos){
        //posにある要素を消す O(log N)
        erase(root,pos);
    }

    int size(){
        return cnt(root);
    }

    T operator[](int pos) {
        Tree t1, t2, t3;
        split(root, pos + 1, t1, t2);
        split(t1, pos, t1, t3);
        T ret = t3->acc;
        merge(t1, t1, t3);
        merge(root, t1, t2);
        return ret;
    }

    T prod(int l, int r){
        //[l,r)の区間 O(log N)
        return prod(root,l,r);
    }

    void apply(int l,int r,F x){
        apply(root,l,r,x);
    }

    void reverse(int l,int r){
        reverse(root,l,r);
    }

    void rotate(int l,int m,int r){
        rotate(root,l,m,r);
    }

    void dump(){
        dump(root);std::cout<<std::endl;
    }
};

// Note: ここは可換である必要がある
long long __op1(long long a, long long b) { return a+b; }
long long __e1() { return 0; }

long long __op2(long long a, long long b) { return b; }
long long __op3(long long a, long long b) { return b; }
long long __e2() { return 0; }

struct SortedSumTree{
    twothreetree<ll> g;
    ImplicitTreap<long long,__op1,__e1,long long,__op2,__op3,__e2> tr;

    SortedSumTree() : g(true) {}
    SortedSumTree(std::vector<long long> as) : g(true) {
        for (auto a : as) {
            g.insert(a);
        }
        vector<long long> sorted_as = as;
        sort(sorted_as.begin(), sorted_as.end());
        tr = ImplicitTreap<long long,__op1,__e1,long long,__op2,__op3,__e2>(sorted_as);
    }

    ll insert(long long x) {
        g.insert(x);
        ll index = g.lower_bound(x);
        tr.insert(index, x);
        return index;
    }

    ll erase(long long x) {
        ll index = g.lower_bound(x);
        if (index < g.size() && g[index] == x) {
            g.erase(x);
            tr.erase(index);
            return index;
        }
        return -1;
    }

    ll get_value(int index) {
        if (index < 0 || index >= g.size()) {
            assert(false && "SortedSumTree.get_value: Index out of bounds");
        }
        return g[index];
    }

    ll lower_bound(long long x) {
        return g.lower_bound(x);
    }

    ll size() {
        return g.size();
    }

    ll count(long long x) {
        return g.count(x);
    }

    ll prod(int l, int r) {
        if (l < 0 || r > g.size() || l > r) {
            assert(false && "SortedSumTree.prod: Invalid range");
        }
        if (l == r) {
            return 0;
        }
        return tr.prod(l, r);
    }

    bool is_in(long long x) {
        return g.lower_bound(x) < g.size() && g[g.lower_bound(x)] == x;
    }

};

 int main2(){
    cin(Q);
    SortedSumTree g;

    rep(i, Q) {
        int t;
        cin >> t;
        if(t == 1) {
            cin(x);
            g.insert(x);
        } else if (t == 2) {
            cin2(x,k);
            ll index = g.lower_bound(x+1);
            cout << g.get_value(index-k) << endl;
        } else if (t == 3) {
            cin2(x,k);
            ll index = g.lower_bound(x) + (k-1);
            cout << g.get_value(index) << endl;
        }
    }
    return 0;
 }


int main3() {
    cin(N);cinvec(A);
    if (N % 2 == 0){
        auto B = A;
        sort(B.begin(),B.end());
        ll ans = 0;
        rep(i,N/2) {
            ans += abs(B[i] - B[N-i-1]);
        }
        cout << ans << endl;
    }else{
        SortedSumTree g1, g2(A);
        g2.erase(A[0]);
        ll ans = g2.prod(0,g2.size())-2*g2.prod(0,g2.size()/2);
        ll i = 0;
        while (i < N-2){
            g1.insert(A[i]);
            g1.insert(A[i+1]);
            g2.erase(A[i+1]);
            g2.erase(A[i+2]);
            ll score = -2*g1.prod(0,g1.size()/2)+g1.prod(0,g1.size());
            score += -2*g2.prod(0,g2.size()/2)+g2.prod(0,g2.size());
            ans = max(ans,score);
            i += 2;
        }
        cout << ans << endl;
    }
    
    return 0;
} 