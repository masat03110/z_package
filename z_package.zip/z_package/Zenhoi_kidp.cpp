#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}

// 全方位木DP
// https://atcoder.jp/contests/abc222/tasks/abc222_f

// how to use
// 1. merge関数、それに関するtanniを変える
// 2. dfs_resの部分を変える
// 3. root0の場合を計算し、それぞれの辺に対応する値を計算する

// 変えるべきところは、以下の部分
ll merge(ll a, ll b) {
    return max(a,b);
}
ll tanni = 0;
// ここまでと、dfs_resの部分

vector<ll> D;

struct Zenhoi_TreeDP{
    ll root = 0;
    vector<vector<array<ll,2>>> G;
    vector<ll> first_value, res_value;
    vector<ll> other_value;
    vector<ll> ans_value;

    Zenhoi_TreeDP(vector<vector<array<ll,2>>> &_G, vector<ll> &_dp) {
        ll N = _G.size();
        G = _G;
        first_value = _dp;
        res_value.resize(N, tanni);
        other_value.resize(N, tanni);
        dfs_ruiseki(root,-1);
        dfs_res(root,-1);
        ans_value.resize(N, tanni);
        // outvec(first_value);
        // outvec(res_value);
        dfs_ans(root,-1);
    }

    vector<ll> get_ans() {
        return ans_value;
    }

    void dfs_ruiseki(ll v, ll p) {
        vector<ll> ruiseki1,ruiseki2;
        ruiseki2.push_back(tanni);
        repd(i,G[v].size()-1,0) {
            if (G[v][i][0] == p) continue;
            ruiseki2.push_back(merge(ruiseki2.back(),first_value[G[v][i][0]]));
        }
        reverse(ruiseki2.begin(),ruiseki2.end());
        ruiseki1.push_back(tanni);
        rep(i,G[v].size()) {
            if (G[v][i][0] == p) continue;
            other_value[G[v][i][0]] = merge(ruiseki1.back(),ruiseki2[ruiseki1.size()]);
            ruiseki1.push_back(merge(ruiseki1.back(),first_value[G[v][i][0]]));
        }
        rep(i,G[v].size()) {
            if (G[v][i][0] == p) continue;
            dfs_ruiseki(G[v][i][0],v);
        }
    }

    // ここから
    void dfs_res(ll v, ll p){
        for (auto [to,c] : G[v]) {
            if (to == p) continue;
            res_value[to] = merge(res_value[v],merge(other_value[to], D[v])) + c;
        }

        for (auto [to,c] : G[v]) {
            if (to == p) continue;
            dfs_res(to,v);
        }
    }
    // ここまで変える

    void dfs_ans(ll v, ll p){
        ll now = tanni;
        for (auto [to,c] : G[v]) {
            if (to == p) now = merge(now,res_value[v]);
            else now = merge(now,first_value[to]);
        }
        ans_value[v] = now;
        for (auto [to,c] : G[v]) {
            if (to == p) continue;
            dfs_ans(to,v);
        }
    }
};



int main() {
    cin(N);
    vector<vector<array<ll,2>>> G(N);
    rep(i,N-1) {
        cin2(a,b);
        a--; b--;
        cin(c);
        G[a].push_back({b,c});
        G[b].push_back({a,c});
    }
    cinvec(_D);
    D = _D;

    vector<ll> dp(N,0);
    auto dfs = [&](auto dfs, ll v, ll p) -> ll {
        ll maxv = D[v];
        for (auto [to,c] : G[v]) {
            if (to == p) continue;
            dp[to] = dfs(dfs,to,v) + c;
            maxv = max(maxv,dp[to]);
        }

        return maxv;
    };

    dfs(dfs,0,-1);

    Zenhoi_TreeDP Z(G,dp);
    vector<ll> ans = Z.get_ans();
    rep(i,N) cout << ans[i] << endl;
    
    return 0;
} 
