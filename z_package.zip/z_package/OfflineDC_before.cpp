#include <bits/stdc++.h>

using namespace std;

struct RollbackUnionFind {
  vector<int> data;
  vector<int> sum;
  int groups;
  RollbackUnionFind(int n) : data(n, -1), sum(n),  groups(n) {}
  vector<pair<int,int>> history;
  void add(int i, int val) { for (; i >= 0; i = data[i]) sum[i] += val; }
  int root(int i) { return data[i] < 0 ? i : root(data[i]); }
  bool same(int i, int j) { return root(i) == root(j); }

  bool unite(int i, int j) {
		i = root(i);
		j = root(j);
		if (data[i] > data[j]) std::swap(i, j);
		history.push_back({i, data[i]});
		history.push_back({j, data[j]});
		if (i == j) return false;
		data[i] += data[j];
		data[j] = i;
		sum[i] += sum[j];
    --groups;
		return true;
	}
  void rollback() {
		int index1 = history.back().first;
		int old_val1 = history.back().second;
		history.pop_back();
		int index0 = history.back().first;
		int old_val0 = history.back().second;
		history.pop_back();
		if (data[index0] != old_val0) {
      sum[index0] -= sum[index1]; // fix sum
      ++groups;
    }
		data[index0] = old_val0;
		data[index1] = old_val1;
	}
};

struct OfflineDynamicConnectivity {
  struct Hen {
    int a, b, l, r;
  };
  map<pair<int,int>,int> start;
  vector<Hen> info;
  int n, q_;
  RollbackUnionFind ruf;
  OfflineDynamicConnectivity(int n, int q_) : n(n), q_(q_), ruf(n) {}
  void link(int time, int a, int b) {
    if (a > b) std::swap(a, b);
    start[{a, b}] = time;
  }
  void cut(int time, int a, int b) {
    if (a > b) std::swap(a, b);
    info.push_back({a, b, start[{a, b}], time});
    start.erase({a, b});
  }
  vector<vector<pair<int,int>>> tree;
  int q;
  template<typename T>
  void dfs(int i, const T& func) {
    for (auto j : tree[i]) ruf.unite(j.first, j.second);
    if (i < q) {
      dfs(i << 1, func);
      dfs(i << 1 | 1, func);
    }
    else if (i < q + q_) func(i - q, ruf);
    for (auto j : tree[i]) ruf.rollback();
  }
  template<typename T>
  void run(const T& func) {
    for (auto i : start) info.push_back({i.first.first, i.first.second, i.second, q_});
    for (q = 1; q < q_; q <<= 1);
    tree.resize(q << 1);
    for (auto i : info) {
      for (i.l += q, i.r += q; i.l < i.r; i.l >>= 1, i.r >>= 1) {
        if (i.r & 1) tree[--i.r].push_back({i.a, i.b});
        if (i.l & 1) tree[i.l++].push_back({i.a, i.b});
      }
    }
    dfs(1, func);
  }
};