#include <bits/stdc++.h>
using namespace std;
#define rep(i,n) for (int i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (int i=(a),__siz=(b);i<__siz;i++)

vector<vector<vector<int>>> Bunkatsu;

const int ppp = 24; // 25が限界かなぁ

void make_Bunkatsu(){
    Bunkatsu.push_back(vector<vector<int>>()); // Bunkatsu[0] = {{}}
    rep2(i,1,ppp){
        Bunkatsu.push_back(vector<vector<int>>(1,vector<int>(1,i))); // Bunkatsu[i] = {{i}}
        rep2(j,1,i){
            for (auto v: Bunkatsu[i-j]){
                vector<int> tmp = v;
                if (tmp.back() < j) continue; // 末尾がjより小さい場合はスキップ
                tmp.push_back(j);
                Bunkatsu[i].push_back(tmp);
            }
        }
    }
}