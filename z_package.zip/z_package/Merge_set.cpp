#include <bits/stdc++.h>

using namespace std;
using ll=long long;

// O(N(logN)^2)
// a, b をマージする．a に全要素が入り，b が空になる．
void merge_set(set<ll> &a, set<ll> &b) {
  // b のほうが a よりサイズが小さいようにして
  if (a.size() < b.size()) swap(a, b);
  // a に b の中身を全部入れるだけ
  a.insert(b.begin(), b.end());
  b.clear();
}