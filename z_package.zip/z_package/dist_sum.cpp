#include <bits/stdc++.h>
using namespace std; using ll=long long; using ld=long double;
ll dist_sum(vector<ll> &v){
    vector<ll> b = v;
    if (b.size()==0) return 0;
    sort(b.begin(),b.end());
    ll sum=0; 
    ll cnt=-b.size()+1;
    for(int i=0;i<b.size();i++){
        sum += cnt*b[i];
        cnt += 2;
    }
    return sum;
}