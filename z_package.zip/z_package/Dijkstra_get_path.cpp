#include <bits/stdc++.h>

using namespace std;
using ll=long long;

// struct edge {
//     ll to, cost;
// };
// typedef vector<vector<edge> > AdjList;
// AdjList graph;

typedef pair<ll, ll> Ps;
typedef array<ll,2> P;

const ll INF = 1e18;

vector<ll> dist; 
vector<ll> prever;

void dijkstra(vector<vector<P>> &graph, ll n, ll s){
    dist = vector<ll>(n,INF);
    prever = vector<ll>(n,-1);
    dist[s] = 0;

    priority_queue<Ps, vector<Ps>, greater<Ps> > que;
    que.push(Ps(0,s));

    while(!que.empty()){
        Ps p = que.top();
        que.pop();
        ll v = p.second;
        if(dist[v] < p.first){
            continue;
        }
        for(ll i=0;i<graph[v].size();i++){
            P e = graph[v][i];
            if(dist[e[0]] > dist[v] + e[1]){
                dist[e[0]] = dist[v] + e[1];
                prever[e[0]] = v;
                que.push(Ps(dist[e[0]],e[0]));
            }
        }
    }
}

vector<ll> get_path(ll t){ //頂点tへの最短路
    vector<ll> path;
    for(; t != -1;t=prever[t]){
        path.push_back(t);
    }

    reverse(path.begin(), path.end());
    return path;
}