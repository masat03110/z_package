// https://atcoder.jp/contests/arc039/tasks/arc039_d

#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}

//https://atcoder.jp/contests/abc075/tasks/abc075_c

struct LowLink{
    private:
    int n;
    vector<vector<int>> G;
    vector<bool> re;
    vector<int> ord;
    vector<int> low;
    
    public:
    vector<int> articulation; // 関節点
    vector<pair<int, int>> bridge; // 橋

    LowLink(const vector<vector<int>> &G): G(G), n(G.size()){
        re.assign(n, 0);
        ord.assign(n, 0);
        low.assign(n, 0);
    }

    void build(){
        int cnt = 0;
        for(int i = 0; i < n; ++i){
            if(!re[i]){
                dfs(i, -1, cnt);
            }
        }
    }

    private:
    void dfs(int cur, int par, int &cnt){
        re[cur] = true;
        ord[cur] = cnt;
        low[cur] = ord[cur];
        ++cnt;
        bool is_art = false;
        int son_cnt = 0;
        for(auto nxt: G[cur]){
            if(!re[nxt]){
                ++son_cnt;
                dfs(nxt, cur, cnt);
                if(nxt != par) low[cur] = min(low[cur], low[nxt]);
                if(par != -1 && ord[cur] <= low[nxt]) is_art = true;
                if(ord[cur] < low[nxt]) bridge.push_back(make_pair(min(cur, nxt), max(cur, nxt)));
            }else{
                if(nxt != par) low[cur] = min(low[cur], ord[nxt]);
            }
        }
        if(par == -1 && son_cnt >= 2) is_art = true;
        if(is_art) articulation.push_back(cur);
    }
};

/// @tparam Type 重みの表現に使う型
/// @note 1.2 省メモリ化
/// @see https://zenn.dev/reputeless/books/standard-cpp-for-competitive-programming/viewer/weighted-union-find

// O(α(N))
template <class Type>
class WeightedUnionFind
{
public:

	WeightedUnionFind() = default;

	ll num_parts;
    std::unordered_set<ll> roots;

	/// @brief 重み付き Union-Find 木を構築します。
	/// @param n 要素数
	explicit WeightedUnionFind(size_t n)
		: m_parentsOrSize(n, -1), num_parts(n)
		, m_diffWeights(n) {
            for (int i = 0; i < n; i++) roots.insert(i);
        }

	/// @brief 頂点 i の root のインデックスを返します。
	/// @param i 調べる頂点のインデックス
	/// @return 頂点 i の root のインデックス
	ll find(ll i)
	{
		if (m_parentsOrSize[i] < 0)
		{
			return i;
		}

		const ll root = find(m_parentsOrSize[i]);

		m_diffWeights[i] += m_diffWeights[m_parentsOrSize[i]];

		// 経路圧縮
		return (m_parentsOrSize[i] = root);
	}

	/// @brief a のグループと b のグループを統合します。
	/// @param a 一方のインデックス
	/// @param b 他方のインデックス
	/// @param w (b の重み) - (a の重み)
	ll merge(ll a, ll b, Type w)
	{
		w += weight(a);
		w -= weight(b);

		a = find(a);
		b = find(b);

		if (a != b)
		{
			// union by size (小さいほうが子になる）
			if (-m_parentsOrSize[a] < -m_parentsOrSize[b])
			{
				std::swap(a, b);
				w = -w;
			}

			m_parentsOrSize[a] += m_parentsOrSize[b];
			m_parentsOrSize[b] = a;
			m_diffWeights[b] = w;
			num_parts--;
            roots.erase(b);
            return b;
		}else{
            return -1;
        }
	}

	/// @brief (b の重み) - (a の重み) を返します。
	/// @param a 一方のインデックス
	/// @param b 他方のインデックス
	/// @remark a と b が同じグループに属さない場合の結果は不定です。
	/// @return (b の重み) - (a の重み)
	Type diff(ll a, ll b)
	{
		return (weight(b) - weight(a));
	}

	/// @brief a と b が同じグループに属すかを返します。
	/// @param a 一方のインデックス
	/// @param b 他方のインデックス
	/// @return a と b が同じグループに属す場合 true, それ以外の場合は false
	bool connected(ll a, ll b)
	{
		return (find(a) == find(b));
	}

	/// @brief i が属するグループの要素数を返します。
	/// @param i インデックス
	/// @return i が属するグループの要素数
	ll size(ll i)
	{
		return -m_parentsOrSize[find(i)];
	}

	/// @brief グループの数を返します。
	/// @return グループの数
	ll num()
	{
		return num_parts;
	}

private:

	// m_parentsOrSize[i] は i の 親,
	// ただし root の場合は (-1 * そのグループに属する要素数)
	std::vector<ll> m_parentsOrSize;

	// 重み
	std::vector<Type> m_diffWeights;

	Type weight(ll i)
	{
		find(i); // 経路圧縮
		return m_diffWeights[i];
	}
};

struct Tree_NonWeight{
    public: 
    vector<vector<int>> G;
    int N;
    vector<int> EulerTour_d;
    vector<int> EulerTour;
    vector<int> EulerTour_id;
    vector<int> depth;
    vector<int> median_point;
    array<int,3> diameter;
    atcoder::segtree<array<int,2>, [](array<int,2> a, array<int,2> b){return a[0] < b[0] ? a:b;}, [](){return array<int,2>{(int)1e9,-1};} > seg;
    vector<vector<int>> path_decomposition;
    vector<vector<int>> g; // 根付き木の隣接リスト
    vector<int> sub;    // i を根とする部分木のサイズ

    vector<int> parent;

    int dfs_hld(int c, int p = -1) {
        parent[c] = p;
        sub[c] = 1;
        if (g[c].size() && g[c][0] == p) swap(g[c][0], g[c].back());
        for(auto& d : g[c]) {
            if(d == p) continue;
            sub[c] += dfs_hld(d, c);
            // 今見ている部分木が g[c][0] を根とする部分木より大きい場合 swap
            if(sub[d] > sub[g[c][0]]) swap(d, g[c][0]);
        }
        return sub[c];
    }

    vector<int> order; // i が行きがけ順で何番目に来るか
    vector<int> head;  // i を含む heavy path の端点
    void dfs2(int c, int &i, int p = -1) {
        order[c] = i++;
        for(auto& d : g[c]) {
            if(d == p) continue;
            //outvec({c,d,g[c][0]});
            head[d] = (g[c][0] == d ? head[c] : d);
            dfs2(d, i, c);
        }
    }

    void dfs_hld_path(int c, int p = -1) {
        path_decomposition.back().push_back(c);
        for(auto d : g[c]) {
            if(d == p) continue;
            dfs_hld_path(d, c);
            if (path_decomposition.back().size() > 0) path_decomposition.push_back(vector<int>());
        }
    }

    void dfs_e(int now, int par, int d){
        EulerTour.push_back(now);
        EulerTour_d.push_back(now);
        depth[now] = d;
        for(auto next: G[now]){
            if(next == par) continue;
            dfs_e(next, now, d+1);
            EulerTour_d.push_back(now);
        }
        return;
    }

    int dfs_mp(int v, int p){
        int child = 0;
        int tree_size = 0;
        for (auto nv: G[v]){
            if (nv == p) continue;
            int c = dfs_mp(nv,v);
            child += c;
            tree_size = max(tree_size,c);
        }
        tree_size = max(tree_size, N - child - 1);
        if (tree_size <= N/2) median_point.push_back(v);
        return child + 1;
    };

    void dfs_dis(int v, int p, int nowdis, int &maxdis, int &maxnode){
        if (nowdis > maxdis){
            maxdis = nowdis;
            maxnode = v;
        }
        for (auto nv: G[v]){
            if (nv == p) continue;
            dfs_dis(nv,v,nowdis+1,maxdis,maxnode);
        }
    }

    vector<vector<int>> doubling_parent;

    void doubling_init(){
        doubling_parent.resize(32,vector<int>(N,-1));
        doubling_parent[0] = parent;

        for (ll i=0; i < doubling_parent.size()-1;i++){
            rep(j,N){
                doubling_parent[i+1][j] = doubling_parent[i][doubling_parent[i][j]];
            }
        }
    }

    // xとroot(0)とのpathのうち、根からindex番目(0はroot)を返す
    int get_root_path_index(int x, int index){
        if (index > depth[x]) return -1;
        int times = depth[x]-index;
        int now = x;
        rep(i,doubling_parent.size()){
            if ((times >> i) & 1){
                now = doubling_parent[i][now];
            }
        }
        return now;
    }

    Tree_NonWeight(){};

    Tree_NonWeight(vector<vector<int>> _G): seg(_G.size()*2), G(_G), depth(_G.size(),1e9) , EulerTour_id(_G.size(),-1), EulerTour_d(), diameter({0,0,0}), g(_G), sub(_G.size()), order(_G.size()), head(_G.size()){
        parent.resize(_G.size());
        N = _G.size();
        dfs_e(0, -1, 0);
        dfs_mp(0,-1);
        dfs_dis(0,-1,0,diameter[0], diameter[1]);
        dfs_dis(diameter[1],-1,0,diameter[0],diameter[2]);

        dfs_hld(0);
        parent[0] = 0;
        int i = 0;
        dfs2(0, i);
        path_decomposition.push_back(vector<int>());
        dfs_hld_path(0);
        path_decomposition.pop_back();

        for(int i=0; i<EulerTour_d.size(); i++){
            if (EulerTour_id[EulerTour_d[i]] == -1) EulerTour_id[EulerTour_d[i]] = i;
            seg.set(i, {depth[EulerTour_d[i]],i});
            assert(depth[EulerTour_d[i]] != 1e9);
        }

        doubling_init();
    }

    int get_LCA(int u, int v){
        int l = EulerTour_id[u];
        int r = EulerTour_id[v];
        if(l > r) swap(l,r);
        return EulerTour_d[seg.prod(l,r+1)[1]];
    }

    int get_dist(int u, int v){
        return depth[u] + depth[v] - 2*depth[get_LCA(u,v)];
    }

    // uからvへのpathのうち、uからk番目を返す(0番目はuである)
    int get_uvpath_kth(int u, int v, int k){
        assert(k >= 0);
        int lca = get_LCA(u,v);
        int path_length_u = depth[u]-depth[lca];
        int path_length_v = depth[v]-depth[lca];
        if (k <= path_length_u) return get_root_path_index(u,depth[u]-k);
        else if (k <= path_length_u+path_length_v) return get_root_path_index(v, depth[v]-(path_length_u+path_length_v-k));
        else return -1;
    }

    // iを根とする部分木の頂点数を返す
    int get_subtree_size(int i){
        return sub[i];
    }
};

// 二重辺連結成分分解
struct NijuRenketsuBunkai{
    vector<vector<int>> G;
    vector<int> Tree_id;
    vector<vector<int>> Tree;
    WeightedUnionFind<int> uf_nobridge;
    WeightedUnionFind<int> uf_all;
    unordered_set<ll> bridge_set;
    Tree_NonWeight _Tree_NonWeight;
    int N;

    ll edge_id(int a, int b){
        if (a > b) swap(a,b);
        return a*N + b;
    }

    bool is_bridge(int a, int b){
        if (a > b) swap(a,b);
        return bridge_set.count(a*N + b) > 0;
    }

    NijuRenketsuBunkai(const vector<vector<int>> &_G): G(_G){
        N = G.size();
        LowLink LL(G);
        LL.build();
        for (auto p : LL.bridge){
            bridge_set.insert(edge_id(p.first, p.second));
        }
        uf_nobridge = WeightedUnionFind<int>(N);
        for (int i = 0; i < N; i++){
            for (auto j : G[i]){
                if (i < j && bridge_set.count(edge_id(i,j)) == 0){
                    uf_nobridge.merge(i,j,0);
                }
            }
        }
        unordered_map<int,int> root_id;
        for (int i = 0; i < N; i++){
            if (root_id.count(uf_nobridge.find(i)) == 0){
                root_id[uf_nobridge.find(i)] = root_id.size()+N;
            }
        }
        Tree_id.resize(N);
        for (int i = 0; i < N; i++){
            Tree_id[i] = root_id[uf_nobridge.find(i)];
        }

        Tree.resize(root_id.size()+N+1);
        for (int i = 0; i < N; i++){
            Tree[Tree_id[i]+1].push_back(i+1);
            Tree[i+1].push_back(Tree_id[i]+1);
        }

        uf_all = WeightedUnionFind<int>(N);
        for (int i = 0; i < N; i++){
            for (auto j : G[i]){
                if (i < j){
                    uf_all.merge(i,j,0);
                }
            }
        }
        for (auto p : LL.bridge){
            Tree[Tree_id[p.first]+1].push_back(Tree_id[p.second]+1);
            Tree[Tree_id[p.second]+1].push_back(Tree_id[p.first]+1);
        }
        unordered_map<int,int> root_id2;
        for (int i=0; i<N; i++){
            if (root_id2.count(uf_all.find(i)) == 0){
                root_id2[uf_all.find(i)] = root_id2.size()+N+root_id.size();
            }
        }
        for (auto [a,_] : root_id2){
            int b = Tree_id[a];
            Tree[b+1].push_back(0);
            Tree[0].push_back(b+1);
        }
        _Tree_NonWeight = Tree_NonWeight(Tree);
    }

    bool is_same(int a, int b){
        return uf_all.connected(a,b);
    }

    bool needs_bridge(int a, int b){
        return !uf_nobridge.connected(a,b);
    }

    int same_size(int a){
        return uf_nobridge.size(a);
    }

    int daihyouten(int a){
        return Tree_id[a]+1;
    }
};



int main2() {
    cin2(N,M);
    vector<vector<int>> G(N);
    rep(i,M){
        cin2(a,b);
        --a,--b;
        G[a].push_back(b);
        G[b].push_back(a);
    }
    NijuRenketsuBunkai NRG(G);
    Tree_NonWeight TNW = NRG._Tree_NonWeight;

    cin(Q);
    rep(i,Q){
        cin3(a,b,c);
        a--;b--;c--;
        a = NRG.daihyouten(a);
        b = NRG.daihyouten(b);
        c = NRG.daihyouten(c);
        if (TNW.get_dist(a,c) == TNW.get_dist(a,b) + TNW.get_dist(b,c)){
            cout << "OK" << endl;
        }else{
            cout << "NG" << endl;
        }
    }
    
    return 0;
} 
