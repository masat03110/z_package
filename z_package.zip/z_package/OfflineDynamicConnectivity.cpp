#include <bits/stdc++.h>

using namespace std;

struct UnionFindUndo
{
private:
  vector<int> parent;
  int comp_size;

  stack<tuple<int, int, int>> snap;

public:
  UnionFindUndo(int n)
  {
    parent.assign(n, -1);
    comp_size = n;
  }

  int leader(int x) const
  {
    assert(0 <= x && x < (int)parent.size());
    if (parent[x] < 0)
      return x;
    int res = leader(parent[x]);
    return res;
  }

  int size(int x) const { return -parent[leader(x)]; }
  int count_comps() const { return comp_size; }

  bool same(int x, int y) const { return leader(x) == leader(y); }

  bool merge(int x, int y)
  {
    int lx = leader(x), ly = leader(y);

    snap.emplace(make_tuple(lx, parent[lx], comp_size));
    snap.emplace(make_tuple(ly, parent[ly], comp_size));

    if (lx == ly)
      return false;
    
    if (-parent[lx] < -parent[ly]) 
      swap(lx, ly);

    parent[lx] += parent[ly];
    parent[ly] = lx;
    comp_size--;
    return true;
  }

  void undo(int times = 1)
  {
    for (int t = 0; t < 2 * times; t++)
    {
      assert(!snap.empty());
      auto [i, p, c] = snap.top();
      snap.pop();
      parent[i] = p;
      comp_size = c;
    }
  }
};

// https://ei1333.github.io/luzhiled/snippets/other/offline-dynamic-connectivity.html
// https://ei1333.hateblo.jp/entry/2017/12/14/000000
struct OfflineDynamicConnectivity
{
private:
  int Q, q;
  vector<vector<pair<int, int>>> nodes;
  map<pair<int, int>, vector<pair<int, bool>>> mp;
  void dfs(const function<void(int)> &f, int k)
  {
    for (auto [u, v] : nodes[k])
      uf.merge(u, v);
    if (k < q)
    {
      dfs(f, 2 * k);
      dfs(f, 2 * k + 1);
    }
    else if (k - q < Q)
      f(k - q);
    uf.undo(nodes[k].size());
  }

public:
  UnionFindUndo uf;
  OfflineDynamicConnectivity(int N, int Q) : uf(N), Q(Q)
  { q = __bit_ceil(Q), nodes.resize(2 * q); }

  // 生存期間が [l, r) の辺 e を追加
  void add(int l, int r, const pair<int, int> &e)
  {
    l += q, r += q;
    while (l < r)
    {
      if (l & 1)
        nodes[l++].emplace_back(e);
      if (r & 1)
        nodes[--r].emplace_back(e);
      l >>= 1, r >>= 1;
    }
  }
  // 時刻 t に辺 u-v を追加
  void insert(int t, int u, int v) { mp[minmax(u, v)].emplace_back(make_pair(t, true)); }
  // 時刻 t に辺 u-v を削除
  void erase(int t, int u, int v) { mp[minmax(u, v)].emplace_back(make_pair(t, false)); }

  // insert, erase を与えた場合、クエリをすべて与えた後に呼ぶ
  void build()
  {
    for (auto &[e, vec] : mp)
    {
      sort(vec.begin(), vec.end());
      vec.emplace_back(make_pair(q, false));
      int l = -1;
      for (auto &[t, isl] : vec)
      {
        if (isl && l == -1)
          l = t;
        else if (!isl && l != -1)
          add(l, t, e), l = -1;
      }
    }
  }

  // build の後に呼ぶ。各時刻 0 <= t < Q について f(t) を実行 (時刻順)
  void run(const function<void(int)> &f) { dfs(f, 1); }
};