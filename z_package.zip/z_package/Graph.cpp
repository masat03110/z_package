#include <bits/stdc++.h>

using namespace std;
using ll=long long;

vector<vector<array<ll,2>>> G;

ll dfs(ll u, ll p, ll d){
    ll res = d;
    for(auto [v, w]: G[u]){
        if(v == p) continue;
        res = max(res, dfs(v, u, d+w));
    }
    return res;
}

ll bfs(ll u){
    ll res = 0;
    queue<array<ll,2>> q;
    q.push({u, 0});
    while(!q.empty()){
        auto [u, d] = q.front(); q.pop();
        res = max(res, d);
        for(auto [v, w]: G[u]){
            q.push({v, d+w});
        }
    }
    return res;
}

ll Dijkstra(vector<vector<array<ll,2>>> &G, ll s,ll g){
    vector<ll> dist(G.size(), 2e18+2);
    priority_queue<array<ll,2>, vector<array<ll,2>>, greater<array<ll,2>>> pq;
    pq.push({0, s});
    dist[s] = 0;
    while(!pq.empty()){
        auto [d, u] = pq.top(); pq.pop();
        if(dist[u] < d) continue;
        for(auto [v, w]: G[u]){
            if(dist[v] > dist[u] + w){
                dist[v] = dist[u] + w;
                pq.push({dist[v], v});
            }
        }
    }
    return dist[g];
}

// O(ElogV)
vector<ll> Dijkstra_dist(vector<vector<array<ll,2>>> &G, ll from){
	vector<ll> dist(G.size(), 1e18);
	priority_queue<array<ll,2>, vector<array<ll,2>>, greater<array<ll,2>>> pq;
	pq.push({0, from});
	dist[from] = 0;
	while(!pq.empty()){
		auto [d, u] = pq.top(); pq.pop();
		if(dist[u] < d) continue;
		for(auto [v, w]: G[u]){
			if(dist[v] > dist[u] + w){
				dist[v] = dist[u] + w;
				pq.push({dist[v], v});
			}
		}
	}
	return dist;
}


constexpr long long INF = (1LL << 60);

// ワーシャルフロイド法 (1.1 基本実装)
// O(V^3)
// 負閉路が存在する場合 true を返す
bool FloydWarshall(std::vector<std::vector<long long>>& distances)
{
	const size_t v = distances.size();

	for (size_t i = 0; i < v; ++i)
	{
		for (size_t from = 0; from < v; ++from)
		{
			for (size_t to = 0; to < v; ++to)
			{
				if ((distances[from][i] < INF) && (distances[i][to] < INF))
				{
					distances[from][to] = std::min(distances[from][to], (distances[from][i] + distances[i][to]));
				}
			}
		}
	}

	for (size_t i = 0; i < v; ++i)
	{
		// 負閉路が含まれている場合, distances[i][i] が負になるような i が存在する
		if (distances[i][i] < 0)
		{
			return true;
		}
	}

	return false;
}

// ワーシャルフロイド法 (1.1 基本実装)
// O(V^3)
// 負閉路が存在する場合 true を返す
std::vector<std::vector<long long>> FloydWarshall2(std::vector<std::vector<array<ll,2>>> G)
{
    int N = G.size();

    std::vector<std::vector<long long>> distances(N, std::vector<long long>(N, INF));

	for (int i = 0; i < N; i++) {
        for (auto [to, cost] : G[i]) {
            distances[i][to] = cost;
        }
        distances[i][i] = 0; // 自分自身への距離は0
    }

	const size_t v = distances.size();

	for (size_t i = 0; i < v; ++i)
	{
		for (size_t from = 0; from < v; ++from)
		{
			for (size_t to = 0; to < v; ++to)
			{
				if ((distances[from][i] < INF) && (distances[i][to] < INF))
				{
					distances[from][to] = std::min(distances[from][to], (distances[from][i] + distances[i][to]));
				}
			}
		}
	}

	for (size_t i = 0; i < v; ++i)
	{
		// 負閉路が含まれている場合, distances[i][i] が負になるような i が存在する
		if (distances[i][i] < 0)
		{
			return vector<std::vector<long long>>(); // 負閉路あり
		}
	}

	return distances; // 負閉路なし
}

// O(VE)
// たどり着くまでに負閉路がある場合は-1e18を返す
// 最長距離も行ける(ただし、同じ辺を使えるとする)
const ll INF = 1e18;
vector<ll> BellmanFord(vector<vector<array<ll,2>>> &G, ll s) {
    ll N = G.size();
    vector<array<ll, 3>> edges;
    for (int i = 0; i < G.size(); i ++) {
        for (auto [v, w] : G[i]) {
            edges.push_back({i, v, w});
        }
    }
    vector<ll> dist(N, INF); 
    dist[s] = 0;
    for (int t2 = 0; t2 < N; t2++) {
        for (auto [u, v, w] : edges) {
            if (dist[u] != INF && dist[u] + w < dist[v]) {
                dist[v] = max(-INF, dist[u] + w);
            }
        }
    }
  /// This step is to make sure that the one can be decreased is minimal 
  /// So all its neighbor is guaranteed to be decreased next time
    for (auto [u, v, w] : edges) {
        if (dist[u] != INF && dist[u] + w < dist[v]) {
            dist[v] = -INF;
        }
    }

    for (int t = 1; t < N; t ++) {
        for (auto [u, v, w] : edges) {
            if (dist[u] != INF && dist[u] + w < dist[v]) {
                dist[v] = -INF;
            }
        }
    }

    return dist;
}

struct Edge
{
	int to;
	int cost;
};

using Graph = std::vector<std::vector<Edge>>;

// O(VE)
// ベルマンフォード法 (1.5 SPFA + 最短経路の再構築)
// 負閉路が存在する場合 true を返す
// 負閉路が存在しない場合, 頂点 startIndex から頂点 targetIndex の最短経路を path に格納する
// distances は頂点数と同じサイズ, 全要素 INF で初期化しておく
bool SPFA(const Graph& graph, std::vector<long long>& distances, int startIndex, int targetIndex, std::vector<int>& path)
{
	const size_t N = distances.size();
	std::vector<int> counts(N);
	std::vector<bool> inqueue(N);
	std::queue<int> q;

	// 直前の頂点を記録する配列
	std::vector<int> p(N, -1);

	distances[startIndex] = 0;
	q.push(startIndex);
	inqueue[startIndex] = true;

	while (!q.empty())
	{
		const int from = q.front(); q.pop();
		inqueue[from] = false;

		for (const auto& edge : graph[from])
		{
			// to までの新しい距離
			const long long d = (distances[from] + edge.cost);

			// d が現在の記録より小さければ更新
			if (d < distances[edge.to])
			{
				distances[edge.to] = d;
				p[edge.to] = from;
			
				if (!inqueue[edge.to])
				{
					q.push(edge.to);
					inqueue[edge.to] = true;
					++counts[edge.to];
					
					if (N < counts[edge.to])
					{
						return true; // 負閉路あり
					}
				}
			}
		}
	}

	if (distances[targetIndex] != INF) // 頂点 targetIndex に到達不可の場合は最短経路無し
	{
		// 経路を再構築
		for (int i = targetIndex; i != -1; i = p[i])
		{
			path.push_back(i);
		}

		std::reverse(path.begin(), path.end());
	}

	return false;
}