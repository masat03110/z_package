#include <bits/stdc++.h>
using namespace std;
using ll=long long;

// typical90 016

// O(logN)
long long extGCD(long long a, long long b, long long &x, long long &y) {
    if (b == 0) {
        x = 1;
        y = 0;
        return a;
    }
    long long d = extGCD(b, a%b, y, x);
    y -= a/b * x;
    return d;
}

// solve ax + by = c
// return true if solution exists
// x and y, where x is a non-negative integer and has the minimum value
bool extGCD2(ll a,ll b, ll &x, ll &y, ll c){
    ll g = extGCD(a,b,x,y);
    if (c % g != 0) return false;
    ll l = c / g;
    x *= l;
    y *= l;
    ll a2 = a / g;
    ll b2 = b / g;

    if (x < 0) {
        ll k = ((-x) / b2) + 1;
        x += k * b2;
        y -= k * a2;
        return true;
    }

    if (x - b2 >= 0){
        ll k = ((x - b2) / b2) + 1;
        x -= k * b2;
        y += k * a2;
        return true;
    }

    return true;
}