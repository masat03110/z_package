// ABC330 F
// count the times you need to move the elements in vector X so that the distance between any two elements is less than K
// ある整数列に対し、最大と最小の差がK以下になるように要素を移動させる回数を求める

// ABC393 D

#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}

// 重なりあり
ll check_interval(vector<ll> &X, ll K){
    vector<ll> X3(X.begin(),X.end());
    rep(i,X.size()){
        X3.push_back(X3[i]-K);
    }
    
    sort(X3.begin(),X3.end());

    ll l = X3[X.size()-1];
    ll r = X3[X.size()-1]+K;

    ll cnt = 0;
    rep(i,X.size()){
        if (X[i] >= l && X[i] <= r) continue;
        
        if (X[i] < l) cnt += l-X[i];
        else cnt += X[i]-r;
    }

    return cnt;
}

// 重なりなし
ll check_interval2(vector<ll> &X, ll K){
    K = K-X.size()+1;
    if (K < 0) return -1;
    vector<ll> X3(X.begin(),X.end());
    rep(i,X.size()){
        X3[i] = X3[i]-i;
        X3.push_back(X3[i]-K);
    }

    sort(X3.begin(),X3.end());

    ll l = X3[X.size()-1];
    ll r = X3[X.size()-1]+K;

    ll cnt = 0;
    rep(i,X.size()){
        ll val = X[i]-i;
        if (val >= l && val <= r) continue;
        
        if (val < l) cnt += l-val;
        else cnt += val-r;
    }

    return cnt;
}

int main2() {
    cin(N); cins(S);
    vector<ll> indexes;
    vector<ll> sum;
    rep(i,N){
        if (S[i] == '1') indexes.push_back(i);
    }

    cout << check_interval2(indexes, indexes.size()-1) << endl;
    
    return 0;
} 
