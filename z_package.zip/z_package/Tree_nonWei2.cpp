#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,__siz=(n);i<__siz;i++)
#define rep2(i,a,b) for (ll i=(a),__siz=(b);i<__siz;i++)
#define repd(i,a,b) for (ll i=(a),__siz=(b);i>=__siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cin4(a,b,c,d) ll a,b,c,d; cin >> a >> b >> c >> d;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RmaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},array<ll,2>,[&](array<ll,2> m, ll n){ return m[0]*n+m[1];}, [&](array<ll,2> a, array<ll,2> b){return array<ll,2>{a[0]*b[0], b[1]*a[0]+a[1]};},[&](){return array<ll,2>{1,0};}> 
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const T &vec) { bool first = true; for (const auto elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { l--; while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
bool chmax(ll &a, ll b) { if (a < b) { a = b; return true; } return false; }
bool chmin(ll &a, ll b) { if (a > b) { a = b; return true; } return false; }
ll mpow(ll a, ll n, ll mod) { ll ret = 1; while (n) { if (n & 1) ret = ret * a % mod; a = a * a % mod; n >>= 1;} return ret; }
bool is_prime(ll N){ if (N == 1) return false; for (ll i=2;i*i<=N;i++) if (N%i == 0) return false; return true;}
vector<array<ll,2>> RLE(string S){vector<array<ll,2>> cnt2; ll N = S.size(); rep(i,N){ ll j = i; while (j < N && S[j] == S[i]) j++; cnt2.push_back({S[i],j-i}); i = j-1;} return cnt2;}
ll okane(ll m, ll e){ if (m <= 0) return 0; return (m-1)/e + 1; }
bool is_palindrome(string S){ll N = S.size(); rep(i,N/2) if (S[i] != S[N-i-1]) return false; return true;}

struct Tree_NonWeight{
    public: 
    vector<vector<int>> G;
    int N;
    vector<int> EulerTour_d;
    vector<int> EulerTour;
    vector<int> EulerTour_id;
    vector<int> depth;
    vector<int> median_point;
    array<int,3> diameter; // {diameter_length, diameter_start, diameter_end}
    atcoder::segtree<array<int,2>, [](array<int,2> a, array<int,2> b){return a[0] < b[0] ? a:b;}, [](){return array<int,2>{(int)1e9,-1};} > seg;
    vector<vector<int>> path_decomposition;
    vector<vector<int>> g; // 根付き木の隣接リスト
    vector<int> sub;    // i を根とする部分木のサイズ

    vector<int> parent;

    int dfs_hld(int c, int p = -1) {
        parent[c] = p;
        sub[c] = 1;
        if (g[c].size() && g[c][0] == p) swap(g[c][0], g[c].back());
        for(auto& d : g[c]) {
            if(d == p) continue;
            sub[c] += dfs_hld(d, c);
            // 今見ている部分木が g[c][0] を根とする部分木より大きい場合 swap
            if(sub[d] > sub[g[c][0]]) swap(d, g[c][0]);
        }
        return sub[c];
    }

    vector<int> order; // i が行きがけ順で何番目に来るか
    vector<int> head;  // i を含む heavy path の端点
    void dfs2(int c, int &i, int p = -1) {
        order[c] = i++;
        for(auto& d : g[c]) {
            if(d == p) continue;
            //outvec({c,d,g[c][0]});
            head[d] = (g[c][0] == d ? head[c] : d);
            dfs2(d, i, c);
        }
    }

    void dfs_hld_path(int c, int p = -1) {
        path_decomposition.back().push_back(c);
        for(auto d : g[c]) {
            if(d == p) continue;
            dfs_hld_path(d, c);
            if (path_decomposition.back().size() > 0) path_decomposition.push_back(vector<int>());
        }
    }

    void dfs_e(int now, int par, int d){
        EulerTour.push_back(now);
        EulerTour_d.push_back(now);
        depth[now] = d;
        for(auto next: G[now]){
            if(next == par) continue;
            dfs_e(next, now, d+1);
            EulerTour_d.push_back(now);
        }
        return;
    }

    int dfs_mp(int v, int p){
        int child = 0;
        int tree_size = 0;
        for (auto nv: G[v]){
            if (nv == p) continue;
            int c = dfs_mp(nv,v);
            child += c;
            tree_size = max(tree_size,c);
        }
        tree_size = max(tree_size, N - child - 1);
        if (tree_size <= N/2) median_point.push_back(v);
        return child + 1;
    };

    void dfs_dis(int v, int p, int nowdis, int &maxdis, int &maxnode){
        if (nowdis > maxdis){
            maxdis = nowdis;
            maxnode = v;
        }
        for (auto nv: G[v]){
            if (nv == p) continue;
            dfs_dis(nv,v,nowdis+1,maxdis,maxnode);
        }
    }

    vector<vector<int>> doubling_parent;

    void doubling_init(){
        doubling_parent.resize(32,vector<int>(N,-1));
        doubling_parent[0] = parent;

        for (ll i=0; i < doubling_parent.size()-1;i++){
            rep(j,N){
                doubling_parent[i+1][j] = doubling_parent[i][doubling_parent[i][j]];
            }
        }
    }

    // xとroot(0)とのpathのうち、根からindex番目(0はroot)を返す
    int get_root_path_index(int x, int index){
        if (index > depth[x]) return -1;
        int times = depth[x]-index;
        int now = x;
        rep(i,doubling_parent.size()){
            if ((times >> i) & 1){
                now = doubling_parent[i][now];
            }
        }
        return now;
    }

    Tree_NonWeight(){};

    Tree_NonWeight(vector<vector<int>> _G): seg(_G.size()*2), G(_G), depth(_G.size(),1e9) , EulerTour_id(_G.size(),-1), EulerTour_d(), diameter({0,0,0}), g(_G), sub(_G.size()), order(_G.size()), head(_G.size()){
        parent.resize(_G.size());
        N = _G.size();
        dfs_e(0, -1, 0);
        dfs_mp(0,-1);
        dfs_dis(0,-1,0,diameter[0], diameter[1]);
        dfs_dis(diameter[1],-1,0,diameter[0],diameter[2]);

        dfs_hld(0);
        parent[0] = 0;
        int i = 0;
        dfs2(0, i);
        path_decomposition.push_back(vector<int>());
        dfs_hld_path(0);
        path_decomposition.pop_back();

        for(int i=0; i<EulerTour_d.size(); i++){
            if (EulerTour_id[EulerTour_d[i]] == -1) EulerTour_id[EulerTour_d[i]] = i;
            seg.set(i, {depth[EulerTour_d[i]],i});
            assert(depth[EulerTour_d[i]] != 1e9);
        }

        doubling_init();
    }

    int get_LCA(int u, int v){
        int l = EulerTour_id[u];
        int r = EulerTour_id[v];
        if(l > r) swap(l,r);
        return EulerTour_d[seg.prod(l,r+1)[1]];
    }

    int get_dist(int u, int v){
        return depth[u] + depth[v] - 2*depth[get_LCA(u,v)];
    }

    // uからvへのpathのうち、uからk番目を返す(0番目はuである)
    int get_uvpath_kth(int u, int v, int k){
        assert(k >= 0);
        int lca = get_LCA(u,v);
        int path_length_u = depth[u]-depth[lca];
        int path_length_v = depth[v]-depth[lca];
        if (k <= path_length_u) return get_root_path_index(u,depth[u]-k);
        else if (k <= path_length_u+path_length_v) return get_root_path_index(v, depth[v]-(path_length_u+path_length_v-k));
        else return -1;
    }

    // iを根とする部分木の頂点数を返す
    int get_subtree_size(int i){
        return sub[i];
    }
};

int main2(){
	int N; cin >> N;
	vector<vector<int>> G(N);
	for (int i=0;i<N-1;i++){
		int a,b;
        cin >> a >> b;
		a--;b--;
		G[a].push_back(b);
		G[b].push_back(a);
	}
	Tree_NonWeight T(G);
    vector<int> a = T.median_point;
    //outvec(a);
    vector<int> b = T.EulerTour;
    if (N & 1){
        b.erase(find(b.begin(),b.end(),a[0]));
        rep(i,N/2){
            cout << b[i]+1 << " " << b[N/2+i]+1 << endl;
        }
    }else{
        rep(i,N/2){
            cout << b[i]+1 << " " << b[N/2+i]+1 << endl;
        }
    }
}