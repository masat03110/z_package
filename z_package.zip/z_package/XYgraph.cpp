#include <bits/stdc++.h>
#include <atcoder/all>

#pragma GCC target("avx2")
#pragma GCC optimize("O3")
#pragma GCC optimize("unroll-loops")

using std::cout; using namespace std; using ll=long long; using ld=long double;
#define rep(i,n) for (ll i=0,siz=(n);i<siz;i++)
#define rep2(i,a,b) for (ll i=(a),siz=(b);i<siz;i++)
#define repd(i,a,b) for (ll i=(a),siz=(b);i>=siz;i--)
#define popcount __builtin_popcountll
#define cin(a) ll a; cin >> a;
#define cin2(a,b) ll a,b; cin >> a >> b;
#define cin3(a,b,c) ll a,b,c; cin >> a >> b >> c;
#define cinvec(v) vector<ll> v(N); rep(i,N) cin >> v[i];
#define cinvec2(v,n) vector<ll> v(n); rep(i,n) cin >> v[i];
#define cins(s) string s; cin >> s;
#define cinc(c) char c; cin >> c;
#define seg_PaRsum atcoder::segtree<ll, [&](ll a, ll b){ return a+b;},[](){return 0ll;}>
#define seg_PaRmax atcoder::segtree<ll, [&](ll a, ll b){ return max(a,b);},[](){return 0ll;}>
#define seg_RaRmax atcoder::lazy_segtree<ll, [&](ll a, ll b){ return max(a,b);},[&](){return 0;},ll,[&](ll m, ll n){ return m+n;}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
#define seg_RaRsum atcoder::lazy_segtree<array<ll,2>, [&](array<ll,2> a, array<ll,2> b){ return array<ll,2>{a[0]+b[0],a[1]+b[1]};},[&](){return array<ll,2>{0,0};},ll,[&](ll m, array<ll,2> n){ return array<ll,2>{n[0]+m*n[1],n[1]};}, [&](ll a, ll b){return a+b;},[&](){return 0ll;}>
vector<ll> dx = {0,-1,0,1},dy = {1,0,-1,0}, ddx = {0,-1,-1,-1,0,1,1,1}, ddy = {1,1,0,-1,-1,-1,0,1};
void yesno(bool b) {cout << (b?"Yes":"No") << endl;}
template<class T> void sortunique(vector<T> &V) {sort(V.begin(), V.end()); V.erase(unique(V.begin(), V.end()), V.end());}
template<typename T> void outvec(const std::initializer_list<T>& list) { bool first = true; for (const auto& elem : list) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T> void outvec(const std::vector<T>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; std::cout << elem; first = false; } std::cout << std::endl; }
template<typename T, size_t N> void outvecp(const std::vector<std::array<T,N>>& vec) { bool first = true; for (const auto& elem : vec) 
{ if (!first) std::cout << " "; for (int i = 0; i < N; i++) std::cout << elem[i] << " "; first = false; } std::cout << std::endl; }
vector<ll> compress(vector<ll> &A){vector<ll> B = A; sortunique(B); rep(i,A.size()) A[i] = lower_bound(B.begin(),B.end(),A[i]) - B.begin(); return B;}
ll bs(ll l, ll r, function<bool(ll)> f) { while (r-l > 1) { ll m = (l+r)/2; if (f(m)) r = m; else l = m; } return r; }
ll msb(ll N) { assert(N>0); return 63 - __builtin_clzll(N); }
int loop_index[32] = {0};
#define loop(n) for (loop_index[0]++, loop_index[loop_index[0]] = -1;(loop_index[loop_index[0]] == -1)&&(loop_index[loop_index[0]] = 0, true);loop_index[0]--) for (; loop_index[loop_index[0]] < n ; loop_index[loop_index[0]]++)

struct makeXYdag{
    vector<vector<array<int,2>>> dag;
	vector<vector<int>> dag_inv;
	vector<int> topo;
    vector<array<int,2>> XY;
    vector<array<int,2>> resXY;
    // xy座標の点を受け取り、X座標でソートしたのち、以下を繰り返す。
    // 1. 二分割できるX座標xを選び、そのX=xの直線と、右と左の点のそれぞれのy座標についてのY=yとの交点を設置
    // 2. それぞれの交点について、つなぐ

	/// @brief トポロジカルソート
	/// @param graph グラフ
	/// @return トポロジカルソートの結果で辞書順最小のもの。グラフが閉路を含む場合は空の配列
	/// @note 1.3 トポロジカルソートの結果で辞書順最小のもの
	/// @see https://zenn.dev/reputeless/books/standard-cpp-for-competitive-programming/viewer/topological-sort

	// O(|V|+|E|)
	std::vector<int> TopologicalSort(const std::vector<std::vector<array<int,2>>>& graph)
	{
		std::vector<int> indegrees(graph.size());

		for (const auto& v : graph)
		{
			for (const auto [to,_] : v)
			{
				++indegrees[to];
			}
		}

		std::priority_queue<int, std::vector<int>, std::greater<int>> pq;

		for (int i = 0; i < (int)graph.size(); ++i)
		{
			if (indegrees[i] == 0)
			{
				pq.push(i);
			}
		}

		std::vector<int> result;

		while (!pq.empty())
		{
			const int from = pq.top(); pq.pop();

			result.push_back(from);

			for (const auto [to,_] : graph[from])
			{
				if (--indegrees[to] == 0)
				{
					pq.push(to);
				}
			}
		}

		if (result.size() != graph.size())
		{
			return{};
		}

		return result;
	};

	int get_index(int val, vector<array<int,2>> &v, int last_adds_size){
		int index = lower_bound(v.begin(),v.begin()+last_adds_size,array<int,2>{val,-1}) - v.begin();
		if (index == v.size() || v[index][0] != val) return -1;
		return index;
	}


    void addPoints(int left, int right, vector<array<int,5>> &mp){
		//cout << left << " " << right << endl;
		if (left >= right) return;
        else if (left+1 == right) {
			mp.push_back({resXY[left][1],resXY[left][0],resXY[left][0],left,left});
			return;
		}
        int mid = (left+right)/2;
		int midx = resXY[mid][0];
        int leftx = lower_bound(XY.begin(),XY.end(),array<int,2>{midx,-1}) - XY.begin();
		int rightx = lower_bound(XY.begin(),XY.end(),array<int,2>{midx+1,-1}) - XY.begin();
		vector<array<int,5>> leftmp,rightmp;
		if (leftx == left && rightx == right){
			for(int i=left;i<right;i++){
				mp.push_back({resXY[i][1],midx,midx,i,i});
				if (i < right-1){
					dag[i].push_back({i+1,(resXY[i+1][1]-resXY[i][1])});
				}
			}
			return;
		}
		addPoints(left,leftx,leftmp);
		addPoints(rightx,right,rightmp);
		vector<array<int,2>> last_adds;
		for(int i=leftx;i<rightx;i++){
			mp.push_back({resXY[i][1],midx,midx,i,i});
			last_adds.push_back({resXY[i][1],i});
		}
		int last_adds_size = last_adds.size();
		for (auto [y,xl,xr,il,ir] : leftmp){
			int index = get_index(y,last_adds,last_adds_size);
			if (index != -1){
				int from = ir, to = mp[index][3];
				dag[from].push_back({to,midx-xr});
				mp[index][1] = xl; mp[index][3] = il;
			}else{
				dag.push_back({});
				last_adds.push_back({y,(int)resXY.size()});
				//mp.push_back({y,midx,midx, (int)resXY.size(), (int)resXY.size()});
				resXY.push_back({midx,y});
				int from = ir, to = resXY.size()-1;
				dag[from].push_back({to,midx-xr});
				mp.push_back({y,xl,midx,il,(int)resXY.size()-1});
			}
		}
		sort(last_adds.begin(),last_adds.end());
		sort(mp.begin(),mp.end());
		last_adds_size = last_adds.size();

		for (auto [y,xl,xr,il,ir] : rightmp){
			int index = get_index(y,last_adds,last_adds_size);
			if (index != -1){
				int from = mp[index][4], to = il;
				dag[from].push_back({to,xl-midx});
				mp[index][2] = xr; mp[index][4] = ir;
			}else{
				dag.push_back({});
				last_adds.push_back({y,(int)resXY.size()});
				resXY.push_back({midx,y});
				int from = resXY.size()-1, to = il;
				dag[from].push_back({to,xl-midx});
				mp.push_back({y,midx,xr,(int)resXY.size()-1,ir});
			}
		}
		sort(last_adds.begin(),last_adds.end());
		int ex = -1;
		for (auto [y,index]: last_adds){
			if (ex != -1){
				int from = ex, to = index;
				dag[from].push_back({to,resXY[to][1]-resXY[from][1]});
				ex = index;
			}else{
				ex = index;
			}
		}
		return;
    }

    makeXYdag(vector<array<int,2>> XY_):XY(XY_){
        sort(XY.begin(),XY.end());
        rep(i,XY.size()){
            resXY.push_back(XY[i]);
        }
		dag.resize(XY.size());
		vector<array<int,5>> mp;
		addPoints(0,XY.size(),mp);

		topo = TopologicalSort(dag);
    }
};

int main() {
    cin3(H,W,N);
    vector<int> A(N),B(N);
    rep(i,N) cin >> A[i] >> B[i];
	A.push_back(1); B.push_back(1);
	A.push_back(H); B.push_back(W);
	vector<array<int,2>> XY;
	rep(i,N+2) XY.push_back({A[i],B[i]});
	makeXYdag mXY(XY);
	auto dag = mXY.dag;
	XY = mXY.resXY;

	vector<array<int,2>> dp(XY.size(),{-1,-1});
	dp[0] = {0,-1};

	// auto dfs = [&](auto self, int now) -> array<int,2>{
	// 	if (dp[now][0] != -1) return dp[now];
	// 	int score = 0;
	// 	if (now > 0 && now <= N){
	// 		score = 1;
	// 	}
	// 	for (auto u : mXY.dag_inv[now]){
	// 		dp[now] = max(dp[now],{self(self,u)[0]+score,u});
	// 	}
	// 	return dp[now];
	// };

	for (auto i : mXY.topo){
		for (auto [to,cost] : dag[i]){
			int now = 0;
			if (to <= N && 0 < to) now = 1;
			dp[to] = max(dp[to],{dp[i][0]+now,i});
		}
	}

	cout << dp[N+1][0] << endl;

	vector<int> keiro;
	int now = N+1;
	while (now != -1){
		keiro.push_back(now);
		now = dp[now][1];
	}

	reverse(keiro.begin(),keiro.end());
	string ans;
	rep(i,keiro.size()){
		if (i == 0) continue;
		int x = XY[keiro[i]][0], y = XY[keiro[i]][1];
		int nx = XY[keiro[i-1]][0], ny = XY[keiro[i-1]][1];
		if (x == nx){
			ans += string(abs(y-ny),'R');
		}else{
			ans += string(abs(x-nx),'D');
		}
	}

	cout << ans << endl;

	
	return 0;
}