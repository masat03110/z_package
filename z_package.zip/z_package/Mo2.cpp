//https://drken1215.hatenablog.com/entry/2019/01/01/234400

#include <iostream>
#include <vector>
#include <numeric>
#include <algorithm>
#include <cmath>
using namespace std;

//https://drken1215.hatenablog.com/entry/2019/01/01/234400

struct Mo {
    vector<int> left, right, index; // the interval's left, right, index
    vector<bool> v;
    int window;
    int nl, nr, ptr;

    Mo(int n) : window((int)sqrt(n)), nl(0), nr(0), ptr(0), v(n, false){
    }
    
    /* push */
    void push(int l, int r) { left.emplace_back(l), right.emplace_back(r); }
    
    /* sort intervals */
    void build() {
        index.resize(left.size());
        iota(index.begin(), index.end(), 0);
		sort(index.begin(), index.end(), [&](const int a, const int b){
            const int c = left[a] / window, d = left[b] / window;
            return (c == d) ? ((c & 1) ? (right[b] < right[a]) : (right[a] < right[b])) : (c < d);
        });
        
        
        // sort(index.begin(), index.end(), [&](int a, int b) {
        //     if (left[a] / window != right[b] / window) return left[a] < left[b];
        //     else return right[a] < right[b];
        // });
    }
    
    /* extend-shorten */
    void extend_shorten(int id) {
        v[id].flip();
        if (v[id]) insert(id);
        else erase(id);
    }
    
    /* next id of interval */
    int next() {
        if (ptr == index.size()) return -1;
        int id = index[ptr];
        while (nl > left[id]) extend_shorten(--nl);
        while (nr < right[id]) extend_shorten(nr++);
        while (nl < left[id]) extend_shorten(nl++);
        while (nr > right[id]) extend_shorten(--nr);
        return index[ptr++];
    }
    
    /* insert, erase (to be set appropriately) */
    void insert(int id);
    void erase(int id);
};

int N, Q;
int A[300001];
int res[200001];
int cnt[1000001];
int num_kind = 0;

void Mo::insert(int id) {
    int val = A[id];
    if (cnt[val] == 0) ++num_kind;
    ++cnt[val];
}

void Mo::erase(int id) {
    int val = A[id];
    --cnt[val];
    if (cnt[val] == 0) --num_kind;
}

int main2() {
    scanf("%d", &N);
    for(int i = 0; i < N; i++) scanf("%d", &A[i]);
    scanf("%d", &Q);
    Mo mo(N);
    for(int i = 0; i < Q; i++) {
        int l, r; scanf("%d %d", &l, &r);
        mo.push(--l, r);
    }
    mo.build();
    for (int i = 0; i < Q; i++){
        int idx = mo.next();
        res[idx] = num_kind;
    }
    for(int i = 0; i < Q; i++) printf("%d\n", res[i]);
}